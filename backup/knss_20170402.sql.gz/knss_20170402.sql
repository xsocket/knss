-- MySQL dump 10.16  Distrib 10.1.21-MariaDB, for osx10.6 (i386)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.1.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pro_ak_profiles`
--

DROP TABLE IF EXISTS `pro_ak_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_ak_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configuration` longtext COLLATE utf8mb4_unicode_ci,
  `filters` longtext COLLATE utf8mb4_unicode_ci,
  `quickicon` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_ak_profiles`
--

LOCK TABLES `pro_ak_profiles` WRITE;
/*!40000 ALTER TABLE `pro_ak_profiles` DISABLE KEYS */;
INSERT INTO `pro_ak_profiles` VALUES (1,'Default Backup Profile','###AES128###J1iGK/5SjYSdDQMRXOiZwaIjMa1WFE+uzcG2a7h91UDiMIVz+XXmfREM5AfwpjfzNvc9g7fTHOvYmZeLtSf+jFa8ccRKzL0eJZ9BoVi+drw8RPw2WXgvhS6Yr31uy4ewga4EOp4qUsD45k8susawwkDsOw350sF+fD1GPKDOifI0KwoLOrrHVMAlRB3myyoKYq7xcQOroYjhGUbCK7gKWDVt+etxCrehnYaQ1kBBOtwwSVMxSKR9GkwkSjcL6BNU/7qVNfbdjRoqGXroJiwlXbOIZkBU7nilalK01aqhE4mQ1zrs3RWm8tH2j+k2FmPF3T8Cx9lo3OHy8F78ekTvksEH/jKRLJ/LeDNYaRSCIaJV6DmxVKFzbVG/n0m8lIDGofrkgptBLeXnJzWIEnz2knjQ+mVsX4inJu+pnkak/fG9fewCF0+gBa2YCKHFi1dWGTGvBehOEbSJHCRKMJvndwxtGqMVkRdC8SZRC52YYbqXpctn9YESVXW6lNQyV1GW12OF/qHJwkAykzv2VuJx5z/APXi5O8iFSBN6fNuJuwjP/KZexalTeuf4Cyx6JrBsFF3ZxoGheGyFXHiFCxuY9xZhVYbuqA0BPITXF0Uyaqt3c4z8n1KlxT6AAcPe7Q1nXsQciVQgRY0g/7uxNR8AkOrvkDeVDRDsmJZKlA7ve8xIyp8f1kUvY3es8ci/torBKM/VtTFOAGZnhq8j8gVgIYp+EY7w7K5ARvKMTnVcCBbudjbHQ8FYp/rgw+wB3YEoHD2ilL+5LpUDbE6nBGNOwvyKbse817KqewAUnNXx2W4P8STDYm6hTR7u513QF+X4LNSY5qd53HIsgv5mc+jwzdWYl5F+ubgtZsE1tqugbLZqXAmDpOtewP3W2pmQ18udaYTCFSisyLnkUzJVvooKFe92SAiChLgvyxDgVIvp4Jjf7wH+INQf+SkTQaBIxXNnEQJ7hZdOLKaZCrKCCkEUqNF2iMlKtcHbw3BeZX8Zl5GhzHAL2j90R2T8p1I86dl3O14OF6x7w44qP5gy5fw5VIbqMdVUK+7GqOKrAnvohMUz4kaVu2KWXhSQV8IoSC51z3RMSuOCDC11PixMzU4kX88UlDcqHS9AyWUMUDN9eaiOJeZECCHFkVOVDdw2DrAbWfjtHY6gsvcQ0CG7N+mEWRuSF+pa13q2a/HODoDSzxPKDdiy1TaTqKe7QYfG49Kbsz3VrnK5HNswJKfI1Ui1lGWF2L3/TNXY1Xp6+qF47lHzFW9LfqK/sQwTgiLXwDBbCka57U0cPmUtg63//J1u0/J6HgGFGdUXdfFd09DpgpxD41AVwbbgR9AbHRG4A4vNq69hC8NiR9YEQzTOz+SvQVUiicA+QDXIjd92hXx9aC+199my81MIhsU3DEztR20zCIywzeGBVH4XvBXQjP9ttM/7QDXLgP1EfxeXoxbkXDGgVlmbGhS54otKVzGzV54V1PEKYTa3hd2Vn2htCpPz8J8qczQPEhdJoxq3GeueWc0iT+bNbN38LGdbl84PEzW0JjMmiIjhy+IyB7Eq6iQoTWz0+aK0Lnpl2OFMPc3KCAzod2sj0CMsXgq68oTHga7QtO4IC2r5l3ThWs+k36hLJNDVnNc5c6Te+fo3tg7p/mqpYlJgh88igt969Gt2Nl07qRtujUz+xDxR2a/vl7A6DxHniXwjXLc+eX4n34fqhsQlZCEy01uI3QL6C9SHwL87UWRcjk2eOCBL5B7Rq2bhxDFCXvoOwa2Xf5qpm91zUa8NQAZbWm/c66o+Vgylcse9rW5Xt7XFrwnepyqVJEnStt69ZCNI4q/w8a+0Jt7fuISQKcFSgW1LtP8RX20OMTpzFcEnWSOIHc5x+8nV6nxBS+6meg1AB38Gv2YuwlwgXxO/Na97iQq15ojw9CQ5GfOuR8+zBgM9TGL93g+IVtz4PRo9E920KqzxspdudArDStpqONH3jel5ZBtRnPJbyE8bFMbFjoyJlPseos1yVbWAn1HatchDQV0VM1mBOKGnywWCOmw7lLDsfFV1N9OdKBXah80c3z0BoyxDn1yd1W78sXvMnmJT9LMa/Umc8Tu7RME14//jddCW5SQYjo2UYw6RmORUJFn7Njuot8PPWFPe/DJZ5jnxZllZKDL2MLkuqeY0CwT0bLooYM94NAEEZFQ4oXlDXjD3ecx7a/1S5mdTyJ1dkENJOrlFMpMG2UnXj+6RwOVrc4MrMVbeXT5K7ZEnN5Q0f06uxC+XgGfP3dm6sNqXN1adhtO3wr+KryBw/uQ3MCAv+f+WGVRY+a6NgkFuFHVBqYJdMioAtGLTrpXU9wl7gvTVOnD0BTGVIPy2fncBRfiKZKDNmPuxIxXfIdLiIoR8Ne5XSxR7mOov5bIJxrjZPrU36+goxrj9yDphX5eqpEG9FNZ4Hbv6u2OJcogaR35VHEphrYah2WD4nJQJy0pQU1QdeHpWwTGxORFqo7T3Frakio5ACyiaiFGG8uWAVhJgXuT7K8zZwiv9id3soy6Jf9fFt+wpZ85GkKYT1kBEuq7JSlBJVgG2LHUbqGU2PcCxGfL4WnIlBwAA','',1);
/*!40000 ALTER TABLE `pro_ak_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_ak_stats`
--

DROP TABLE IF EXISTS `pro_ak_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_ak_stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` longtext COLLATE utf8mb4_unicode_ci,
  `backupstart` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `backupend` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('run','fail','complete') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'run',
  `origin` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'backend',
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full',
  `profile_id` bigint(20) NOT NULL DEFAULT '1',
  `archivename` longtext COLLATE utf8mb4_unicode_ci,
  `absolute_path` longtext COLLATE utf8mb4_unicode_ci,
  `multipart` int(11) NOT NULL DEFAULT '0',
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `backupid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filesexist` tinyint(3) NOT NULL DEFAULT '1',
  `remote_filename` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_size` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fullstatus` (`filesexist`,`status`),
  KEY `idx_stale` (`status`,`origin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_ak_stats`
--

LOCK TABLES `pro_ak_stats` WRITE;
/*!40000 ALTER TABLE `pro_ak_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_ak_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_ak_storage`
--

DROP TABLE IF EXISTS `pro_ak_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_ak_storage` (
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`tag`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_ak_storage`
--

LOCK TABLES `pro_ak_storage` WRITE;
/*!40000 ALTER TABLE `pro_ak_storage` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_ak_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_akeeba_common`
--

DROP TABLE IF EXISTS `pro_akeeba_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_akeeba_common` (
  `key` varchar(192) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_akeeba_common`
--

LOCK TABLES `pro_akeeba_common` WRITE;
/*!40000 ALTER TABLE `pro_akeeba_common` DISABLE KEYS */;
INSERT INTO `pro_akeeba_common` VALUES ('fof30','[\"com_akeeba\"]'),('stats_lastrun','1491106352'),('stats_siteid','1d491d175ab4ade32b3859da5cadf52bf28ec6fd'),('stats_siteurl','1731e640b89a2c906bb17f5f43676af4');
/*!40000 ALTER TABLE `pro_akeeba_common` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_assets`
--

DROP TABLE IF EXISTS `pro_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=688 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_assets`
--

LOCK TABLES `pro_assets` WRITE;
/*!40000 ALTER TABLE `pro_assets` DISABLE KEYS */;
INSERT INTO `pro_assets` VALUES (1,0,1,1094,0,'root.1','Root Asset','{\"core.login.site\":{\"6\":1,\"2\":1},\"core.login.admin\":{\"6\":1},\"core.login.offline\":[],\"core.admin\":{\"8\":1},\"core.manage\":{\"7\":1},\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(2,1,2,3,1,'com_admin','com_admin','{}'),(3,1,4,11,1,'com_banners','com_banners','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(4,1,12,13,1,'com_cache','com_cache','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(5,1,14,15,1,'com_checkin','com_checkin','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(6,1,16,17,1,'com_config','com_config','{}'),(7,1,18,87,1,'com_contact','com_contact','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(8,1,88,571,1,'com_content','com_content','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(9,1,572,573,1,'com_cpanel','com_cpanel','{}'),(10,1,574,575,1,'com_installer','com_installer','{\"core.admin\":[],\"core.manage\":{\"7\":0},\"core.delete\":{\"7\":0},\"core.edit.state\":{\"7\":0}}'),(11,1,576,577,1,'com_languages','com_languages','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(12,1,578,579,1,'com_login','com_login','{}'),(13,1,580,581,1,'com_mailto','com_mailto','{}'),(14,1,582,583,1,'com_massmail','com_massmail','{}'),(15,1,584,585,1,'com_media','com_media','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":{\"5\":1},\"core.edit\":[],\"core.edit.state\":[]}'),(16,1,586,589,1,'com_menus','com_menus','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(17,1,37,38,1,'com_messages','com_messages','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(18,1,592,957,1,'com_modules','com_modules','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(19,1,958,965,1,'com_newsfeeds','com_newsfeeds','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(20,1,966,967,1,'com_plugins','com_plugins','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(21,1,968,969,1,'com_redirect','com_redirect','{\"core.admin\":{\"7\":1},\"core.manage\":[]}'),(22,1,970,971,1,'com_search','com_search','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),(23,1,972,973,1,'com_templates','com_templates','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(24,1,974,977,1,'com_users','com_users','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(26,1,978,979,1,'com_wrapper','com_wrapper','{}'),(33,1,1040,1041,1,'com_finder','com_finder','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),(34,8,105,134,2,'com_content.category.9','Pages','{\"core.create\":{\"10\":0,\"12\":0},\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(35,3,7,8,2,'com_banners.category.10','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(36,7,23,24,2,'com_contact.category.11','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(37,19,961,962,2,'com_newsfeeds.category.12','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(40,3,9,10,2,'com_banners.category.15','Sample Data-Banners','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(41,7,25,86,2,'com_contact.category.16','Sample Data-Contact','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(42,19,963,964,2,'com_newsfeeds.category.17','Sample Data-Newsfeeds','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(59,41,26,27,3,'com_contact.category.34','Park Site','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(60,41,28,85,3,'com_contact.category.35','Shop Site','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(61,60,29,30,4,'com_contact.category.36','Staff','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(62,60,31,84,4,'com_contact.category.37','Fruit Encyclopedia','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(63,62,32,33,5,'com_contact.category.38','A','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(64,62,34,35,5,'com_contact.category.39','B','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(65,62,36,37,5,'com_contact.category.40','C','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(66,62,38,39,5,'com_contact.category.41','D','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(67,62,40,41,5,'com_contact.category.42','E','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(68,62,42,43,5,'com_contact.category.43','F','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(69,62,44,45,5,'com_contact.category.44','G','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(70,62,46,47,5,'com_contact.category.45','H','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(71,62,48,49,5,'com_contact.category.46','I','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(72,62,50,51,5,'com_contact.category.47','J','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(73,62,52,53,5,'com_contact.category.48','K','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(74,62,54,55,5,'com_contact.category.49','L','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(75,62,56,57,5,'com_contact.category.50','M','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(76,62,58,59,5,'com_contact.category.51','N','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(77,62,60,61,5,'com_contact.category.52','O','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(78,62,62,63,5,'com_contact.category.53','P','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(79,62,64,65,5,'com_contact.category.54','Q','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(80,62,66,67,5,'com_contact.category.55','R','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(81,62,68,69,5,'com_contact.category.56','S','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(82,62,70,71,5,'com_contact.category.57','T','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(83,62,72,73,5,'com_contact.category.58','U','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(84,62,74,75,5,'com_contact.category.59','V','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(85,62,76,77,5,'com_contact.category.60','W','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(86,62,78,79,5,'com_contact.category.61','X','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(87,62,80,81,5,'com_contact.category.62','Y','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(88,62,82,83,5,'com_contact.category.63','Z','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(100,8,137,138,2,'com_content.category.71','Milky Way','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(168,34,106,107,3,'com_content.article.67','What\'s New in 1.5?','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(169,24,975,976,2,'com_users.category.77','Uncategorised',''),(173,1,1042,1043,1,'com_joomlaupdate','com_joomlaupdate','{\"core.admin\":[],\"core.manage\":[],\"core.delete\":[],\"core.edit.state\":[]}'),(174,1,1044,1045,1,'com_tags','com_tags','{\"core.admin\":{\"8\":1},\"core.manage\":{\"7\":1},\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(176,203,142,153,3,'com_content.category.78','Layouts','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(177,176,143,144,4,'com_content.article.72','How to create the 3 columns layout?','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(178,176,145,146,4,'com_content.article.73','How to create the 2 columns layout: Sidebar + Content?','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(179,176,147,148,4,'com_content.article.74','How to create the 2 columns layout: Content + Sidebar','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(180,176,149,150,4,'com_content.article.75','Full width layout','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(181,176,151,152,4,'com_content.article.76','Main content','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(182,184,155,156,4,'com_content.article.77','Page break','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(184,203,154,177,3,'com_content.category.79','Compatibilities','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(185,184,157,158,4,'com_content.article.79',' Free Joomla Multilingual Extension','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(187,184,159,160,4,'com_content.article.81','Demo Articles 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(189,184,161,162,4,'com_content.article.83','Demo Article 5','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(190,184,163,164,4,'com_content.article.84','Demo Article 6','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(191,184,165,166,4,'com_content.article.85','Demo Article 7','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(192,184,167,168,4,'com_content.article.86','Demo Article 8','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(193,184,169,170,4,'com_content.article.87','Demo Article 9','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(194,184,171,172,4,'com_content.article.88','Demo Article 10','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(195,196,181,182,4,'com_content.article.89','JA Social on T3 Framework','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(196,203,178,189,3,'com_content.category.80','T3 Framework','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(197,196,179,180,4,'com_content.article.90','JA Teline IV for T3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(198,196,183,184,4,'com_content.article.91','T3 Framework 2.0.2 released','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(199,196,185,186,4,'com_content.article.92','Bootstrap 2.1.0 released','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(200,196,187,188,4,'com_content.article.93','T3 Framework 2.0.1 release ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(201,184,173,174,4,'com_content.article.94','Demo Article 2','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(202,184,175,176,4,'com_content.article.95','Demo Article 4','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(203,8,141,564,2,'com_content.category.81','Joomla Articles','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(204,1,1046,1047,1,'com_contenthistory','com_contenthistory','{}'),(205,1,1048,1049,1,'com_ajax','com_ajax','{}'),(206,1,1050,1051,1,'com_postinstall','com_postinstall','{}'),(207,18,593,594,2,'com_modules.module.114','Main Menu','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(208,18,595,596,2,'com_modules.module.1','Main Menu','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(213,18,597,598,2,'com_modules.module.96','T3 Masthead 1','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(214,18,599,600,2,'com_modules.module.97','T3 Introduction','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(216,203,244,263,3,'com_content.category.83','Portfolio','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(217,203,264,269,3,'com_content.category.84','Corporate','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(218,203,270,357,3,'com_content.category.85','Magazine','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(219,203,358,359,3,'com_content.category.86','Shop','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(220,18,601,602,2,'com_modules.module.119','Product intro','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(221,18,603,604,2,'com_modules.module.120','Fully Reponsive','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(222,18,605,606,2,'com_modules.module.121','HTML5, Bootstrap and LESS','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(223,1,1052,1053,1,'com_kunena','com_kunena','{}'),(227,18,607,608,2,'com_modules.module.124','Community - Events Module',''),(228,18,609,610,2,'com_modules.module.125','Community - Groups Module',''),(229,18,611,612,2,'com_modules.module.126','Community - Members Module',''),(230,18,613,614,2,'com_modules.module.127','Community - Photos Module',''),(231,18,615,616,2,'com_modules.module.128','Community - Quick Search Module',''),(232,18,617,618,2,'com_modules.module.129','Community - Videos Module',''),(233,18,619,620,2,'com_modules.module.130','Community - Whos Online',''),(247,18,621,622,2,'com_modules.module.39','Who\'s Online','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(249,18,623,624,2,'com_modules.module.16','Login Form','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(250,18,625,626,2,'com_modules.module.141','2 starter themes','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(251,18,627,628,2,'com_modules.module.142','Flat design','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(252,18,629,630,2,'com_modules.module.143','Megamenu and Off-canvas','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(256,18,631,632,2,'com_modules.module.147','Recent Blog Posts (EasyBlog)','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(267,18,633,634,2,'com_modules.module.158','Online Users',''),(268,18,635,636,2,'com_modules.module.159','Recent Users',''),(269,18,637,638,2,'com_modules.module.160','Recent Albums',''),(270,18,639,640,2,'com_modules.module.161','Leaderboard',''),(271,203,190,243,3,'com_content.category.87','Blog','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(272,18,641,642,2,'com_modules.module.27','Archived Articles','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(273,308,224,225,5,'com_content.article.96','Responsive Joomla template bundle - JA Wall released with 3 more styles','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(274,308,222,223,5,'com_content.article.97','Review: Responsive Joomla template for portfolio - JA Appolio','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(276,218,293,308,4,'com_content.category.89','Blog ','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(277,218,271,292,4,'com_content.category.90','T3 Framework and Bootstrap 3','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(278,218,309,324,4,'com_content.category.91','Joomla deals','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(279,218,325,340,4,'com_content.category.92','News and updates','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(280,218,341,356,4,'com_content.category.93','Tutorials','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(281,276,294,295,5,'com_content.article.98','Choosing your Joomla template framework','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(282,276,296,297,5,'com_content.article.99','The best free Joomla templates in 2013','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(283,276,298,299,5,'com_content.article.100','Top 10 responsive Joomla templates from JoomlArt','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(284,276,300,301,5,'com_content.article.101','Responsive Joomla template bundle - JA Wall in 3 new styles','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(285,276,302,303,5,'com_content.article.102',' Responsive Joomla template for ecommerce - JA Bookshop','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(286,276,304,305,5,'com_content.article.103','1st Batch of Joomla 3.2 compatibility upgrade','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(287,277,272,273,5,'com_content.article.104','Chossing your Joomla version: Joomla 2.5 or Joomla 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(288,277,274,275,5,'com_content.article.105','Best Joomla template featuring EasyBlog','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(289,277,276,277,5,'com_content.article.106','HTC One Max review: An old phone in a new body','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(290,277,278,279,5,'com_content.article.107','Fingers-on: Snapkeys Q4 is a QWERTY keyboard ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(291,278,310,311,5,'com_content.article.108','Shopping for last-minute tech gifts? Here\'s our one stop guide','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(292,278,312,313,5,'com_content.article.109','The best photo printers you can buy today','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(293,278,314,315,5,'com_content.article.110','JA Magz - Responsive Joomla magazine template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(294,278,316,317,5,'com_content.article.111','Bootstrap 3.0 and the T3 Framework for Joomla template ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(295,279,326,327,5,'com_content.article.112','IObit Uninstaller 3 review: Free utility competes with a built-in','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(296,279,328,329,5,'com_content.article.113','Lucidpress review: Free beta makes typesetting simple','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(297,279,330,331,5,'com_content.article.114','Responsive Joomla template - JA Teline IV now on T3 Framework','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(298,279,332,333,5,'com_content.article.115','Free Joomla templates built on the robust T3 Framework','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(299,279,334,335,5,'com_content.article.116','Purity III - Best free responsive Joomla template for 2014','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(300,280,342,343,5,'com_content.article.117','What is new in Joomla 3.2 ?','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(301,280,344,345,5,'com_content.article.118','One Year Later: Must-Have Windows 7 Downloads','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(302,280,346,347,5,'com_content.article.119','Security software showdown! 9 antivirus suites empirically tested','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(303,280,348,349,5,'com_content.article.120','Responsive Joomla template for Joomla 2.5 & Joomla 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(304,280,350,351,5,'com_content.article.121','FREE Responsive Joomla extensions for Joomla 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(305,280,352,353,5,'com_content.article.122','Joomla 3 templates supporting Bootstrap 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(306,271,191,202,4,'com_content.category.94','News & Update','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(307,271,203,214,4,'com_content.category.95','Tips & Tutorials','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(308,271,215,226,4,'com_content.category.96','Reviews','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(309,271,227,242,4,'com_content.category.97','Joomla Extensions','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(310,308,216,217,5,'com_content.article.123','The year 2013 in review : A look back','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(311,306,192,193,5,'com_content.article.124','Purity III - The best free responsive Joomla template for 2014','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(312,306,194,195,5,'com_content.article.125','T3 Framework video – Introducing Megamenu ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(313,1,1060,1061,1,'#__ucm_content.1','#__ucm_content.1','[]'),(314,306,196,197,5,'com_content.article.126','Added K2 style for 4 Joomla templates: JA Ironis, JA Minisite, JA Graphite, and JA Bistro','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(315,306,198,199,5,'com_content.article.127','JA Business is compatible with Joomla 2.5 & 3.0','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(316,1,1062,1063,1,'#__ucm_content.2','#__ucm_content.2','[]'),(317,203,360,383,3,'com_content.category.98','Featured projects','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(318,307,204,205,5,'com_content.article.128','The Biggest Web Design Trends Coming Next Year','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(319,18,643,644,2,'com_modules.module.113','Demo Content','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(320,18,645,646,2,'com_modules.module.26','About Joomla','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(321,317,361,362,4,'com_content.article.129','Fully responsive','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(322,307,206,207,5,'com_content.article.130','Why Every Small Business Owner or Startup Entrepreneur Should Consider Using a Template for Their We','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(323,307,208,209,5,'com_content.article.131','Best responsive Joomla templates from JoomlArt in the year 2013','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(324,308,218,219,5,'com_content.article.132','10 Copywriting Errors That Can Ruin a Company’s Website','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(325,306,200,201,5,'com_content.article.133','Sneakpeek - JoomlArt\'s New Demo Toolbar','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(326,1,1064,1065,1,'#__ucm_content.3','#__ucm_content.3','[]'),(327,307,210,211,5,'com_content.article.134','Review: Responsive Joomla template for book stores- JA Bookshop','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(328,1,1066,1067,1,'#__ucm_content.4','#__ucm_content.4','[]'),(329,308,220,221,5,'com_content.article.135','Responsive Joomla template for movie - JA Obelisk','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(331,307,212,213,5,'com_content.article.136','How to style modules in Joomla - OSTraining Video Tutorial','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(332,1,1068,1069,1,'#__ucm_content.6','#__ucm_content.6','[]'),(333,309,228,229,5,'com_content.article.137','Easy to use Google translate or Bing translator for your Joomla','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(334,1,1070,1071,1,'#__ucm_content.7','#__ucm_content.7','[]'),(335,309,230,231,5,'com_content.article.138','Introducing JA Multilingual extension for Joomla 2.5 & Joomla 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(336,1,1072,1073,1,'#__ucm_content.8','#__ucm_content.8','[]'),(337,309,232,233,5,'com_content.article.139','Tips to Extend Your Content Types Using CCK For Joomla','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(338,309,234,235,5,'com_content.article.140','JA Extensions Manager - Upgrades / Rollbacks Made easy - Free for all...','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(339,309,236,237,5,'com_content.article.141','Meet JA Magz - The Joomla magazine template in 41 languages','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(340,1,1074,1075,1,'#__ucm_content.9','#__ucm_content.9','[]'),(341,309,238,239,5,'com_content.article.142','Joomla extension - JA Multilingual extension for Joomla 2.5 & Joomla 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(342,1,1076,1077,1,'#__ucm_content.10','#__ucm_content.10','[]'),(343,309,240,241,5,'com_content.article.143','3 FREE responsive Joomla extensions for Joomla 2.5 & Joomla 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(345,18,647,648,2,'com_modules.module.163','Blog Categories','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(347,317,363,364,4,'com_content.article.144','Built on the robust T3 Framework','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(348,18,649,650,2,'com_modules.module.165','Blog Tags','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(349,18,651,652,2,'com_modules.module.166','Important Articles ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(350,1,1078,1079,1,'#__ucm_content.11','#__ucm_content.11','[]'),(351,317,365,366,4,'com_content.article.145','A perfect starting point','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(352,317,367,368,4,'com_content.article.146','Support Bootstrap 3 at core','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(354,18,653,654,2,'com_modules.module.167','Magazine - Articles','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(355,317,369,370,4,'com_content.article.148','Easy to customize','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(356,317,371,372,4,'com_content.article.149','Multiple layouts supported','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(357,317,373,374,4,'com_content.article.150','A free Joomla 3 template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(358,317,375,376,4,'com_content.article.151','Highly compatible','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(359,317,377,378,4,'com_content.article.152','Stunning typography pages','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(360,1,1080,1081,1,'#__ucm_content.12','#__ucm_content.12','[]'),(362,18,655,656,2,'com_modules.module.168','Magazine - Other articles','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(363,18,657,658,2,'com_modules.module.169','EasyBlog Calendar','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(364,18,659,660,2,'com_modules.module.170','EasyBlog Archive','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(365,18,661,662,2,'com_modules.module.171','Blog Categories','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(366,18,663,664,2,'com_modules.module.172','EasyBlog Tag Cloud','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(367,18,665,666,2,'com_modules.module.173','EasyBlog New Post Module',''),(368,34,108,109,3,'com_content.article.153','Welcome to JA Purity III','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(373,18,667,668,2,'com_modules.module.177','How we work','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(374,18,669,670,2,'com_modules.module.178','Success Stories','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(375,18,671,672,2,'com_modules.module.179','Let\'s connect','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(377,18,673,674,2,'com_modules.module.181','Slideshow','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(378,216,245,246,4,'com_content.article.154','JA Bookshop','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(379,216,247,248,4,'com_content.article.155','JA Appolio','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(380,216,249,250,4,'com_content.article.156','JA Obelisk','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(381,216,251,252,4,'com_content.article.157','JA Magz','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(382,216,253,254,4,'com_content.article.158','JA Muzic','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(383,216,255,256,4,'com_content.article.159','JA Fixel','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(384,216,257,258,4,'com_content.article.160',' JA Beranis','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(385,216,259,260,4,'com_content.article.161',' JA Smashboard','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(386,216,261,262,4,'com_content.article.162',' JA Hawkstore','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(387,18,675,676,2,'com_modules.module.182','Testimonials','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(388,18,677,678,2,'com_modules.module.183','Business Joomla template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(389,18,679,680,2,'com_modules.module.184','Blog Joomla template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(390,18,681,682,2,'com_modules.module.185','News Joomla template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(391,18,683,684,2,'com_modules.module.90','About us','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(393,18,685,686,2,'com_modules.module.92','Follow us','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(397,18,687,688,2,'com_modules.module.189','Why we do it','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(398,18,689,690,2,'com_modules.module.190','Portfolio Joomla template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(399,18,691,692,2,'com_modules.module.93','Contact us','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(400,18,693,694,2,'com_modules.module.191','Blog post','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(403,18,695,696,2,'com_modules.module.192','Popular post','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(404,18,697,698,2,'com_modules.module.193','Sample Banner 1','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(405,18,699,700,2,'com_modules.module.194','Custom tabs','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(406,18,701,702,2,'com_modules.module.101','Built on T3 Framework','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(407,18,703,704,2,'com_modules.module.102','Joomla 3 & Bootstrap 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(408,18,705,706,2,'com_modules.module.103','A Free Joomla template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(409,18,707,708,2,'com_modules.module.104','Flat Design & Stunning Typo','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(410,203,384,385,3,'com_content.article.163','Typography','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(411,18,709,710,2,'com_modules.module.195','Most read','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(413,18,711,712,2,'com_modules.module.45','Menu Example','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(414,18,713,714,2,'com_modules.module.196','Joomla','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(415,18,715,716,2,'com_modules.module.197','Bootstrap 3','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(416,18,717,718,2,'com_modules.module.198','Framework','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(417,18,719,720,2,'com_modules.module.199','Typography','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(418,277,280,281,5,'com_content.article.164','T-Mobile will pay you to break up with your carrier','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(419,277,282,283,5,'com_content.article.165','Best Android Phones for Business','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(420,277,284,285,5,'com_content.article.166','Responsive Joomla template - JA Nex on T3v3 Framework','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(421,277,286,287,5,'com_content.article.167','The best Joomla templates using Bootstrap 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(422,18,721,722,2,'com_modules.module.200','Masthead','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(423,277,288,289,5,'com_content.article.168','Responsive Joomla template for Portfolio - JA Appolio','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(424,277,290,291,5,'com_content.article.169','Joomla template framework: T3 Framework 2.0.1 release','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(425,278,318,319,5,'com_content.article.170','Best deals for responsive Joomla templates 2013','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(426,278,320,321,5,'com_content.article.171','Best Joomla deals on Black Friday 2013 ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(427,278,322,323,5,'com_content.article.172','Best Joomla deals coupon code for Christmas 2013','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(428,276,306,307,5,'com_content.article.173','Responsive Joomla template for book stores - JA Bookshop','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(429,18,723,724,2,'com_modules.module.94','T3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(430,18,725,726,2,'com_modules.module.95','JoomlArt','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(431,280,354,355,5,'com_content.article.174','Best Joomla practices for beginners','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(432,279,336,337,5,'com_content.article.175','Free Joomla template for magazine','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(433,279,338,339,5,'com_content.article.176','Joomla 3 templates - Best practices for high conversion','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(434,34,110,111,3,'com_content.article.177','Compatible','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(435,34,112,113,3,'com_content.article.178','Offline page','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(436,1,1082,1083,1,'com_jaextmanager','com_jaextmanager','{}'),(438,34,114,115,3,'com_content.article.179','Features Intro 2','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(443,18,727,728,2,'com_modules.module.202','Feature 1','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(444,18,729,730,2,'com_modules.module.203','Supports multiple layouts','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(445,18,731,732,2,'com_modules.module.204','Why Purity III?','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(446,18,733,734,2,'com_modules.module.205','Want to be the first to try our Purity III','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(447,217,265,266,4,'com_content.article.183','Wanna get your beloved extensions in?','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(448,217,267,268,4,'com_content.article.184','Let\'s get to know Purity III','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(449,18,735,736,2,'com_modules.module.206','Team members','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(450,18,737,738,2,'com_modules.module.207','Our partners','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(452,34,116,117,3,'com_content.article.185','Pricing table','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(453,34,118,119,3,'com_content.article.186','Support policy','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(454,203,386,559,3,'com_content.category.101','Glossary','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(463,203,560,563,3,'com_content.category.102','Compatible extensions','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(464,454,387,388,4,'com_content.article.193','Access level','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(465,463,561,562,4,'com_content.article.194','Compatible Extensions','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(466,454,389,390,4,'com_content.article.195','Anchor','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(467,454,391,392,4,'com_content.article.196','Access Control List','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(468,454,393,394,4,'com_content.article.197','Language Pack','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(469,454,395,396,4,'com_content.article.198','Administrator','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(470,454,397,398,4,'com_content.article.199','Admin template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(471,454,399,400,4,'com_content.article.200','Language Key','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(472,454,401,402,4,'com_content.article.201','Alias','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(473,454,403,404,4,'com_content.article.202','Alternative Menu item','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(474,454,405,406,4,'com_content.article.203','Apache','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(475,454,407,408,4,'com_content.article.204','Language Override','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(476,454,409,410,4,'com_content.article.205','API','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(477,454,411,412,4,'com_content.article.206','Layout Override','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(478,454,413,414,4,'com_content.article.207','Article','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(479,454,415,416,4,'com_content.article.208','LDAP','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(480,454,417,418,4,'com_content.article.209','Author','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(481,454,419,420,4,'com_content.article.210','Backend','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(482,454,421,422,4,'com_content.article.211','Banner','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(483,454,423,424,4,'com_content.article.212','Blog','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(484,454,425,426,4,'com_content.article.213','Breadcrumbs','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(485,454,427,428,4,'com_content.article.214','Manager','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(486,454,429,430,4,'com_content.article.215','Cache','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(487,454,431,432,4,'com_content.article.216','Menu','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(488,454,433,434,4,'com_content.article.217','Model','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(489,454,435,436,4,'com_content.article.218','Category','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(490,454,437,438,4,'com_content.article.219','Category Manager','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(491,454,439,440,4,'com_content.article.220','Model-View-Controller (MVC)','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(492,454,441,442,4,'com_content.article.221','Module','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(493,454,443,444,4,'com_content.article.222','Chrome','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(494,454,445,446,4,'com_content.article.223','Component','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(495,454,447,448,4,'com_content.article.224','Configuration.php','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(496,454,449,450,4,'com_content.article.225','Content Management System','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(497,454,451,452,4,'com_content.article.226','Controller','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(498,454,453,454,4,'com_content.article.227','CSS','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(499,454,455,456,4,'com_content.article.228','Module Class Suffix','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(501,454,457,458,4,'com_content.article.230','Core','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(502,454,459,460,4,'com_content.article.231','Module Position','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(504,454,461,462,4,'com_content.article.233','Administration Control Panel','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(505,454,463,464,4,'com_content.article.234','Database prefix','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(506,454,465,466,4,'com_content.article.235','Editor','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(507,454,467,468,4,'com_content.article.236','MySQL','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(508,454,469,470,4,'com_content.article.237','Object Oriented Programming (OOP) ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(509,454,471,472,4,'com_content.article.238','Options (Parameters) ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(510,34,120,121,3,'com_content.article.239','Override','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(511,454,473,474,4,'com_content.article.240','Extension','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(512,454,475,476,4,'com_content.article.241','FOSS','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(513,454,477,478,4,'com_content.article.242','Front-end','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(514,454,479,480,4,'com_content.article.243','Function','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(515,454,481,482,4,'com_content.article.244','Global Configuration','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(516,454,483,484,4,'com_content.article.245','GPL','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(517,454,485,486,4,'com_content.article.246','Page Class Suffix','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(518,454,487,488,4,'com_content.article.247','Override','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(519,454,489,490,4,'com_content.article.248','Hack (Core Hack)','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(520,454,491,492,4,'com_content.article.249','Hit','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(521,454,493,494,4,'com_content.article.250','HTML5','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(522,454,497,498,4,'com_content.article.251','Patch','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(523,454,495,496,4,'com_content.article.252','JavaScript ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(524,454,499,500,4,'com_content.article.253','JDOC','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(525,454,501,502,4,'com_content.article.254','JED (Joomla Extensions Directory)','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(526,454,503,504,4,'com_content.article.255','Plugin','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(527,454,505,506,4,'com_content.article.256','Poll','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(528,454,507,508,4,'com_content.article.257','Publisher','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(529,454,509,510,4,'com_content.article.258','Register users','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(530,454,511,512,4,'com_content.article.259','Router','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(531,454,513,514,4,'com_content.article.260','JoomlaDay','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(532,454,515,516,4,'com_content.article.261','RSS (Really Simple Syndication)','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(533,454,517,518,4,'com_content.article.262','LAMPP ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(534,454,519,520,4,'com_content.article.263','Language','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(535,454,521,522,4,'com_content.article.264','Search engine friendly (SEF)','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(536,454,523,524,4,'com_content.article.265','Search engine optimization (SEO)','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(537,454,525,526,4,'com_content.article.266','Split Menu','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(538,454,527,528,4,'com_content.article.267','SQL','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(539,454,529,530,4,'com_content.article.268','Sub category','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(540,454,531,532,4,'com_content.article.269','Super user','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(541,454,533,534,4,'com_content.article.270','Template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(542,454,535,536,4,'com_content.article.271','Template Style','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(543,454,537,538,4,'com_content.article.272','Template override','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(544,454,539,540,4,'com_content.article.273','Uncategorize article','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(545,454,541,542,4,'com_content.article.274','User groups','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(546,454,543,544,4,'com_content.article.275','View site','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(547,454,545,546,4,'com_content.article.276','View (MVC)','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(548,454,547,548,4,'com_content.article.277','Web server','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(549,454,549,550,4,'com_content.article.278','Wrapper','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(550,454,551,552,4,'com_content.article.279','WYSIWYG editor','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(551,454,553,554,4,'com_content.article.280','XHTML','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(552,454,555,556,4,'com_content.article.281','XML','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(553,454,557,558,4,'com_content.article.282','Module Chrome','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(554,18,739,740,2,'com_modules.module.98','T3 Features','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(555,18,741,742,2,'com_modules.module.210','Compatible Extensions','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(556,34,122,123,3,'com_content.article.283','Our team','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(559,34,124,125,3,'com_content.article.285','Single Article','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(560,18,743,744,2,'com_modules.module.31','News Flash','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(562,317,379,380,4,'com_content.article.287','Support RTL language layout','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(563,18,745,746,2,'com_modules.module.61','Articles Categories','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(564,18,747,748,2,'com_modules.module.211','Sidebar 1','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(565,18,749,750,2,'com_modules.module.212','Sidebar 2','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(566,18,751,752,2,'com_modules.module.213','After content','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(567,18,753,754,2,'com_modules.module.214','Footer 1','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(568,18,755,756,2,'com_modules.module.215','Footer 2','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(569,18,757,758,2,'com_modules.module.216','Footer 5','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(570,18,759,760,2,'com_modules.module.217','Footer 3','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(571,18,761,762,2,'com_modules.module.218','Footer 4','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(572,18,763,764,2,'com_modules.module.219','Footer 6','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(573,34,126,127,3,'com_content.article.288','Support policy - style 2','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(575,317,381,382,4,'com_content.article.289','Downloads','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(576,18,765,766,2,'com_modules.module.221','Purity III and its stunning typography','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(578,18,767,768,2,'com_modules.module.112','Purity III - The best free Joomla Template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(580,18,769,770,2,'com_modules.module.224','T3 Framework','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(581,18,771,772,2,'com_modules.module.225','Purity III Template','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(582,34,128,129,3,'com_content.article.290','404','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(583,34,130,131,3,'com_content.article.291','Purity III  layouts','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(584,34,132,133,3,'com_content.article.292','Request to be compatible','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(585,18,773,774,2,'com_modules.module.226','Purity III video','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(586,18,775,776,2,'com_modules.module.19','User Menu','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(588,8,565,570,2,'com_content.category.104','Test','{\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(589,588,566,567,3,'com_content.article.293','SOME TITLE','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(590,588,568,569,3,'com_content.article.294','Another submitted',''),(591,18,777,778,2,'com_modules.module.228','Portfolio Articles ','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1}}'),(593,18,779,780,2,'com_modules.module.229','Sample Profiles','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(594,18,781,782,2,'com_modules.module.230','EasySocial Dating Search',''),(595,18,783,784,2,'com_modules.module.231','EasySocial Event Menu',''),(596,18,785,786,2,'com_modules.module.232','EasySocial Events',''),(597,18,787,788,2,'com_modules.module.233','EasySocial Event Categories',''),(598,18,789,790,2,'com_modules.module.234','EasySocial Group Menu',''),(599,18,791,792,2,'com_modules.module.235','EasySocial Groups',''),(600,18,793,794,2,'com_modules.module.236','EasySocial Group Categories',''),(601,18,795,796,2,'com_modules.module.237','EasySocial Recent Photos',''),(602,18,797,798,2,'com_modules.module.238','EasySocial Profile Completeness',''),(603,18,799,800,2,'com_modules.module.239','EasySocial Quick Registration',''),(604,18,801,802,2,'com_modules.module.240','EasySocial Registration Requester',''),(607,18,803,804,2,'com_modules.module.241','JS Nearby Events Search',''),(608,18,805,806,2,'com_modules.module.242','EasySocial Followers',''),(609,18,807,808,2,'com_modules.module.243','EasySocial Friends',''),(610,18,809,810,2,'com_modules.module.244','JS Activity Stream','{}'),(611,18,811,812,2,'com_modules.module.245','JS Discussions','{}'),(612,18,813,814,2,'com_modules.module.246','JS Events Calendar','{}'),(613,18,815,816,2,'com_modules.module.247','JS Hello Me','{}'),(614,18,817,818,2,'com_modules.module.248','JS Members Search','{}'),(615,18,819,820,2,'com_modules.module.249','JS Nearby Events Search','{}'),(616,18,821,822,2,'com_modules.module.250','JS Notifications','{}'),(617,18,823,824,2,'com_modules.module.251','JS Photo Comments','{}'),(618,18,825,826,2,'com_modules.module.252','JS Statistics','{}'),(619,18,827,828,2,'com_modules.module.253','JS Top Members','{}'),(620,18,829,830,2,'com_modules.module.254','JS Video Comments','{}'),(621,18,831,832,2,'com_modules.module.255','EasySocial Calendar','{}'),(622,18,833,834,2,'com_modules.module.256','EasySocial Quick Post','{}'),(623,18,835,836,2,'com_modules.module.257','EasySocial Recent Polls','{}'),(624,18,837,838,2,'com_modules.module.258','EasySocial Videos Module','{}'),(625,18,839,840,2,'com_modules.module.259','EasyBlog - Biography Module','{}'),(626,18,841,842,2,'com_modules.module.260','EasyBlog - Image Wall Module','{}'),(627,18,843,844,2,'com_modules.module.261','EasyBlog - Latest Bloggers Module','{}'),(628,18,845,846,2,'com_modules.module.262','EasyBlog - Latest Blogs Module','{}'),(629,18,847,848,2,'com_modules.module.263','EasyBlog - Latest Comments Module','{}'),(630,18,849,850,2,'com_modules.module.264','EasyBlog - Posts List','{}'),(631,18,851,852,2,'com_modules.module.265','EasyBlog - Most Commented Post Module','{}'),(632,18,853,854,2,'com_modules.module.266','EasyBlog - Most Popular Post Module','{}'),(633,18,855,856,2,'com_modules.module.267','EasyBlog - Post Map Module','{}'),(634,18,857,858,2,'com_modules.module.268','EasyBlog - Post Meta Module','{}'),(635,18,859,860,2,'com_modules.module.269','EasyBlog - Quick Post Module','{}'),(636,18,861,862,2,'com_modules.module.270','EasyBlog - Random Post Module','{}'),(637,18,863,864,2,'com_modules.module.271','EasyBlog - Related Posts Module','{}'),(638,18,865,866,2,'com_modules.module.272','EasyBlog - Search Blogs Module','{}'),(639,18,867,868,2,'com_modules.module.273','EasyBlog - Showcase Module','{}'),(640,18,869,870,2,'com_modules.module.274','EasyBlog - Subscribe Module','{}'),(641,18,871,872,2,'com_modules.module.275','EasyBlog - Subscribers Listing Module','{}'),(642,18,873,874,2,'com_modules.module.276','EasyBlog - Team Blogs Module','{}'),(643,18,875,876,2,'com_modules.module.277','EasyBlog - Ticker Module','{}'),(644,18,877,878,2,'com_modules.module.278','EasyBlog - Top Blogs Module','{}'),(645,18,879,880,2,'com_modules.module.279','EasyBlog - Welcome Module','{}'),(647,18,881,882,2,'com_modules.module.280','MijoShop - All-in-One','{}'),(648,18,883,884,2,'com_modules.module.281','MijoShop Orders','{}'),(649,18,885,886,2,'com_modules.module.282','MijoShop - Quick Icons','{}'),(650,18,887,888,2,'com_modules.module.283','MJ Category','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(651,18,889,890,2,'com_modules.module.284','MJ Account','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(652,18,891,892,2,'com_modules.module.285','MJ Affliate','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(653,18,893,894,2,'com_modules.module.286','MJ Featured Product','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(654,18,895,896,2,'com_modules.module.287','MJ Latest Product','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(655,18,897,898,2,'com_modules.module.288','MJ Latest Product 2','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(656,18,899,900,2,'com_modules.module.289','EasyDiscuss - Ask Module','{}'),(657,18,901,902,2,'com_modules.module.290','EasyDiscuss - Board Statistic','{}'),(658,18,903,904,2,'com_modules.module.291','EasyDiscuss - Categories','{}'),(659,18,905,906,2,'com_modules.module.292','EasyDiscuss - Latest Replies','{}'),(660,18,907,908,2,'com_modules.module.293','EasyDiscuss - Leaderboard','{}'),(661,18,909,910,2,'com_modules.module.294','EasyDiscuss - Most Hit Discussions','{}'),(662,18,911,912,2,'com_modules.module.295','EasyDiscuss - Most Likes Discussions','{}'),(663,18,913,914,2,'com_modules.module.296','EasyDiscuss - Most Replies Discussion','{}'),(664,18,915,916,2,'com_modules.module.297','EasyDiscuss - Most Voted Discussions','{}'),(665,18,917,918,2,'com_modules.module.298','EasyDiscuss - Navigation','{}'),(666,18,919,920,2,'com_modules.module.299','EasyDiscuss - Notifications','{}'),(667,18,921,922,2,'com_modules.module.300','EasyDiscuss - Post Info','{}'),(668,18,923,924,2,'com_modules.module.301','EasyDiscuss - Quick Question Module','{}'),(669,18,925,926,2,'com_modules.module.302','EasyDiscuss - Recent Discussions','{}'),(670,18,927,928,2,'com_modules.module.303','EasyDiscuss - Recent Replies','{}'),(671,18,929,930,2,'com_modules.module.304','EasyDiscuss - Search Discussion Module','{}'),(672,18,931,932,2,'com_modules.module.305','EasyDiscuss - Similar Discussions Module','{}'),(673,18,933,934,2,'com_modules.module.306','EasyDiscuss - Tag Cloud','{}'),(674,18,935,936,2,'com_modules.module.307','EasyDiscuss - Toolbar','{}'),(675,18,937,938,2,'com_modules.module.308','EasyDiscuss - Top Members','{}'),(676,18,939,940,2,'com_modules.module.309','EasyDiscuss - Welcome','{}'),(677,18,941,942,2,'com_modules.module.310','EasyDiscuss - Who Is Online','{}'),(678,18,943,944,2,'com_modules.module.311','EasyDiscuss - Who Is Viewing','{}'),(679,18,945,946,2,'com_modules.module.312','EasyDiscuss - Your Discussions','{}'),(680,18,947,948,2,'com_modules.module.313','EasySocial Page Menu','{}'),(681,18,949,950,2,'com_modules.module.314','EasySocial Pages','{}'),(682,18,951,952,2,'com_modules.module.315','EasySocial Page Categories','{}'),(683,18,953,954,2,'com_modules.module.316','EasySocial Profile Statistics','{}'),(684,18,955,956,2,'com_modules.module.317','EasySocial Info (Admin)','{}'),(685,16,587,588,2,'com_menus.menu.12','Kunena Menu','{}'),(686,1,1090,1091,1,'com_jce','COM_JCE','{}'),(687,1,1092,1093,1,'com_akeeba','Akeeba','{}');
/*!40000 ALTER TABLE `pro_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_associations`
--

DROP TABLE IF EXISTS `pro_associations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_associations`
--

LOCK TABLES `pro_associations` WRITE;
/*!40000 ALTER TABLE `pro_associations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_banner_clients`
--

DROP TABLE IF EXISTS `pro_banner_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extrainfo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_banner_clients`
--

LOCK TABLES `pro_banner_clients` WRITE;
/*!40000 ALTER TABLE `pro_banner_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_banner_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_banner_tracks`
--

DROP TABLE IF EXISTS `pro_banner_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_banner_tracks`
--

LOCK TABLES `pro_banner_tracks` WRITE;
/*!40000 ALTER TABLE `pro_banner_tracks` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_banner_tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_banners`
--

DROP TABLE IF EXISTS `pro_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `custombannercode` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_metakey_prefix` (`metakey_prefix`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_banners`
--

LOCK TABLES `pro_banners` WRITE;
/*!40000 ALTER TABLE `pro_banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_categories`
--

DROP TABLE IF EXISTS `pro_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_language` (`language`),
  KEY `idx_path` (`path`(100)),
  KEY `idx_alias` (`alias`(100))
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_categories`
--

LOCK TABLES `pro_categories` WRITE;
/*!40000 ALTER TABLE `pro_categories` DISABLE KEYS */;
INSERT INTO `pro_categories` VALUES (1,0,0,0,131,0,'','system','ROOT','root','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',42,'2011-01-01 00:00:01',42,'0000-00-00 00:00:00',0,'*',1),(10,35,1,81,82,1,'uncategorised','com_banners','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\",\"foobar\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',42,'0000-00-00 00:00:00',0,'*',1),(11,36,1,77,78,1,'uncategorised','com_contact','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',42,'0000-00-00 00:00:00',0,'*',1),(12,37,1,13,14,1,'uncategorised','com_newsfeeds','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',42,'0000-00-00 00:00:00',0,'*',1),(77,169,1,85,86,1,'uncategorised','com_users','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',42,'0000-00-00 00:00:00',0,'*',1);
/*!40000 ALTER TABLE `pro_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_activities`
--

DROP TABLE IF EXISTS `pro_community_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `actor` int(10) unsigned NOT NULL,
  `target` int(10) unsigned NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `app` varchar(200) NOT NULL,
  `verb` varchar(200) NOT NULL,
  `cid` int(10) NOT NULL,
  `groupid` int(10) DEFAULT NULL,
  `eventid` int(10) DEFAULT NULL,
  `group_access` tinyint(4) NOT NULL DEFAULT '0',
  `event_access` tinyint(4) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `access` tinyint(3) unsigned NOT NULL,
  `params` text NOT NULL,
  `points` int(4) NOT NULL DEFAULT '1',
  `archived` tinyint(3) NOT NULL,
  `location` text NOT NULL,
  `latitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `longitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `comment_id` int(10) NOT NULL,
  `comment_type` varchar(200) NOT NULL,
  `like_id` int(10) NOT NULL,
  `like_type` varchar(200) NOT NULL,
  `actors` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actor` (`actor`),
  KEY `target` (`target`),
  KEY `app` (`app`),
  KEY `created` (`created`),
  KEY `archived` (`archived`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_activities`
--

LOCK TABLES `pro_community_activities` WRITE;
/*!40000 ALTER TABLE `pro_community_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_activities_hide`
--

DROP TABLE IF EXISTS `pro_community_activities_hide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_activities_hide` (
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_activities_hide`
--

LOCK TABLES `pro_community_activities_hide` WRITE;
/*!40000 ALTER TABLE `pro_community_activities_hide` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_activities_hide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_apps`
--

DROP TABLE IF EXISTS `pro_community_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_apps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `apps` varchar(200) NOT NULL,
  `ordering` int(10) unsigned NOT NULL,
  `position` varchar(50) NOT NULL DEFAULT 'content',
  `params` text NOT NULL,
  `privacy` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_userid` (`userid`),
  KEY `idx_user_apps` (`userid`,`apps`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_apps`
--

LOCK TABLES `pro_community_apps` WRITE;
/*!40000 ALTER TABLE `pro_community_apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_avatar`
--

DROP TABLE IF EXISTS `pro_community_avatar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_avatar` (
  `id` int(10) unsigned NOT NULL,
  `apptype` varchar(255) NOT NULL,
  `path` text NOT NULL,
  `type` tinyint(3) unsigned NOT NULL COMMENT '0 = small, 1 = medium, 2=large',
  UNIQUE KEY `id` (`id`,`apptype`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_avatar`
--

LOCK TABLES `pro_community_avatar` WRITE;
/*!40000 ALTER TABLE `pro_community_avatar` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_avatar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_badges`
--

DROP TABLE IF EXISTS `pro_community_badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `image` varchar(256) NOT NULL,
  `published` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `points` (`points`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_badges`
--

LOCK TABLES `pro_community_badges` WRITE;
/*!40000 ALTER TABLE `pro_community_badges` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_badges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_blocklist`
--

DROP TABLE IF EXISTS `pro_community_blocklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_blocklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `blocked_userid` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `blocked_userid` (`blocked_userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_blocklist`
--

LOCK TABLES `pro_community_blocklist` WRITE;
/*!40000 ALTER TABLE `pro_community_blocklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_blocklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_config`
--

DROP TABLE IF EXISTS `pro_community_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_config` (
  `name` varchar(64) NOT NULL,
  `params` longtext NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_config`
--

LOCK TABLES `pro_community_config` WRITE;
/*!40000 ALTER TABLE `pro_community_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_connect_users`
--

DROP TABLE IF EXISTS `pro_community_connect_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_connect_users` (
  `connectid` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL,
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_connect_users`
--

LOCK TABLES `pro_community_connect_users` WRITE;
/*!40000 ALTER TABLE `pro_community_connect_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_connect_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_connection`
--

DROP TABLE IF EXISTS `pro_community_connection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_connection` (
  `connection_id` int(11) NOT NULL AUTO_INCREMENT,
  `connect_from` int(11) NOT NULL,
  `connect_to` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `group` int(11) NOT NULL,
  `msg` text NOT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`connection_id`),
  KEY `connect_from` (`connect_from`,`connect_to`,`status`,`group`),
  KEY `idx_connect_to` (`connect_to`),
  KEY `idx_connect_from` (`connect_from`),
  KEY `idx_connect_tofrom` (`connect_to`,`connect_from`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_connection`
--

LOCK TABLES `pro_community_connection` WRITE;
/*!40000 ALTER TABLE `pro_community_connection` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_connection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_digest_email`
--

DROP TABLE IF EXISTS `pro_community_digest_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_digest_email` (
  `user_id` int(11) NOT NULL,
  `total_sent` int(11) NOT NULL,
  `last_sent` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_digest_email`
--

LOCK TABLES `pro_community_digest_email` WRITE;
/*!40000 ALTER TABLE `pro_community_digest_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_digest_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_engagement`
--

DROP TABLE IF EXISTS `pro_community_engagement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_engagement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `week` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_engagement`
--

LOCK TABLES `pro_community_engagement` WRITE;
/*!40000 ALTER TABLE `pro_community_engagement` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_engagement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_event_stats`
--

DROP TABLE IF EXISTS `pro_community_event_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_event_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `date` date NOT NULL,
  `params` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_event_stats`
--

LOCK TABLES `pro_community_event_stats` WRITE;
/*!40000 ALTER TABLE `pro_community_event_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_event_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_events`
--

DROP TABLE IF EXISTS `pro_community_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_events` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL COMMENT 'parent for recurring event',
  `catid` int(11) unsigned NOT NULL,
  `contentid` int(11) unsigned DEFAULT '0' COMMENT '0 - if type == profile, else it hold the group id',
  `type` varchar(255) NOT NULL DEFAULT 'profile' COMMENT 'profile, group',
  `title` varchar(255) NOT NULL,
  `location` text NOT NULL,
  `summary` text NOT NULL,
  `description` text,
  `creator` int(11) unsigned NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `permission` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '0 - Open (Anyone can mark attendence), 1 - Private (Only invited can mark attendence)',
  `avatar` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `cover` text NOT NULL,
  `invitedcount` int(11) unsigned DEFAULT '0',
  `confirmedcount` int(11) unsigned DEFAULT '0' COMMENT 'treat this as member count as well',
  `declinedcount` int(11) unsigned DEFAULT '0',
  `maybecount` int(11) unsigned DEFAULT '0',
  `wallcount` int(11) unsigned DEFAULT '0',
  `ticket` int(11) unsigned DEFAULT '0' COMMENT 'Represent how many guest can be joined or invited.',
  `allowinvite` tinyint(1) unsigned DEFAULT '1' COMMENT '0 - guest member cannot invite thier friends to join. 1 - yes, guest member can invite any of thier friends to join.',
  `created` datetime DEFAULT NULL,
  `hits` int(11) unsigned DEFAULT '0',
  `published` int(11) unsigned DEFAULT '1',
  `latitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `longitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `offset` varchar(5) DEFAULT NULL,
  `allday` tinyint(11) NOT NULL DEFAULT '0',
  `repeat` varchar(50) DEFAULT NULL COMMENT 'null,daily,weekly,monthly',
  `repeatend` date NOT NULL,
  `params` text NOT NULL,
  `storage` varchar(64) NOT NULL DEFAULT 'file',
  `unlisted` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_creator` (`creator`),
  KEY `idx_period` (`startdate`,`enddate`),
  KEY `idx_type` (`type`),
  KEY `idx_catid` (`catid`),
  KEY `idx_published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_events`
--

LOCK TABLES `pro_community_events` WRITE;
/*!40000 ALTER TABLE `pro_community_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_events_category`
--

DROP TABLE IF EXISTS `pro_community_events_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_events_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_events_category`
--

LOCK TABLES `pro_community_events_category` WRITE;
/*!40000 ALTER TABLE `pro_community_events_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_events_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_events_members`
--

DROP TABLE IF EXISTS `pro_community_events_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_events_members` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `eventid` int(11) unsigned NOT NULL,
  `memberid` int(11) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '[Join / Invite]: 0 - [pending approval/pending invite], 1 - [approved/confirmed], 2 - [rejected/declined], 3 - [maybe/maybe], 4 - [blocked/blocked]',
  `permission` tinyint(1) unsigned NOT NULL DEFAULT '3' COMMENT '1 - creator, 2 - admin, 3 - member',
  `invited_by` int(11) unsigned DEFAULT '0',
  `approval` tinyint(1) unsigned DEFAULT '0' COMMENT '0 - no approval required, 1 - required admin approval',
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_eventid` (`eventid`),
  KEY `idx_status` (`status`),
  KEY `idx_invitedby` (`invited_by`),
  KEY `idx_permission` (`eventid`,`permission`),
  KEY `idx_member_event` (`eventid`,`memberid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_events_members`
--

LOCK TABLES `pro_community_events_members` WRITE;
/*!40000 ALTER TABLE `pro_community_events_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_events_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_featured`
--

DROP TABLE IF EXISTS `pro_community_featured`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_featured` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_featured`
--

LOCK TABLES `pro_community_featured` WRITE;
/*!40000 ALTER TABLE `pro_community_featured` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_featured` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_fields`
--

DROP TABLE IF EXISTS `pro_community_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `ordering` int(11) DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `min` int(5) NOT NULL,
  `max` int(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `tips` text NOT NULL,
  `visible` tinyint(1) DEFAULT '0',
  `required` tinyint(1) DEFAULT '0',
  `searchable` tinyint(1) DEFAULT '1',
  `registration` tinyint(1) DEFAULT '1',
  `options` text,
  `fieldcode` varchar(255) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fieldcode` (`fieldcode`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_fields`
--

LOCK TABLES `pro_community_fields` WRITE;
/*!40000 ALTER TABLE `pro_community_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_fields_values`
--

DROP TABLE IF EXISTS `pro_community_fields_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_fields_values` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `field_id` int(10) NOT NULL,
  `value` text NOT NULL,
  `access` tinyint(3) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `user_id` (`user_id`),
  KEY `idx_user_fieldid` (`user_id`,`field_id`),
  KEY `access` (`access`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_fields_values`
--

LOCK TABLES `pro_community_fields_values` WRITE;
/*!40000 ALTER TABLE `pro_community_fields_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_fields_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_files`
--

DROP TABLE IF EXISTS `pro_community_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `groupid` int(11) NOT NULL,
  `discussionid` int(11) NOT NULL,
  `bulletinid` int(11) NOT NULL,
  `eventid` int(11) NOT NULL,
  `profileid` int(11) NOT NULL,
  `messageid` int(11) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL,
  `hits` int(11) NOT NULL,
  `storage` varchar(64) NOT NULL,
  `creator` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discussionid` (`discussionid`),
  KEY `groupid` (`groupid`),
  KEY `creator` (`creator`),
  KEY `bulletinid` (`bulletinid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_files`
--

LOCK TABLES `pro_community_files` WRITE;
/*!40000 ALTER TABLE `pro_community_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_group_stats`
--

DROP TABLE IF EXISTS `pro_community_group_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_group_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `date` date NOT NULL,
  `params` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_group_stats`
--

LOCK TABLES `pro_community_group_stats` WRITE;
/*!40000 ALTER TABLE `pro_community_group_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_group_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_groups`
--

DROP TABLE IF EXISTS `pro_community_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `published` tinyint(1) NOT NULL,
  `ownerid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `approvals` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `avatar` text NOT NULL,
  `thumb` text NOT NULL,
  `cover` text NOT NULL,
  `discusscount` int(11) NOT NULL DEFAULT '0',
  `wallcount` int(11) NOT NULL DEFAULT '0',
  `membercount` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `hits` int(11) NOT NULL,
  `storage` varchar(64) NOT NULL DEFAULT 'file',
  `summary` text NOT NULL,
  `unlisted` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_groups`
--

LOCK TABLES `pro_community_groups` WRITE;
/*!40000 ALTER TABLE `pro_community_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_groups_bulletins`
--

DROP TABLE IF EXISTS `pro_community_groups_bulletins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_groups_bulletins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_groups_bulletins`
--

LOCK TABLES `pro_community_groups_bulletins` WRITE;
/*!40000 ALTER TABLE `pro_community_groups_bulletins` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_groups_bulletins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_groups_category`
--

DROP TABLE IF EXISTS `pro_community_groups_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_groups_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_groups_category`
--

LOCK TABLES `pro_community_groups_category` WRITE;
/*!40000 ALTER TABLE `pro_community_groups_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_groups_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_groups_discuss`
--

DROP TABLE IF EXISTS `pro_community_groups_discuss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_groups_discuss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) NOT NULL DEFAULT '0',
  `groupid` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `title` text NOT NULL,
  `message` text NOT NULL,
  `lastreplied` datetime NOT NULL,
  `lock` tinyint(1) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_groups_discuss`
--

LOCK TABLES `pro_community_groups_discuss` WRITE;
/*!40000 ALTER TABLE `pro_community_groups_discuss` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_groups_discuss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_groups_invite`
--

DROP TABLE IF EXISTS `pro_community_groups_invite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_groups_invite` (
  `groupid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `creator` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_groups_invite`
--

LOCK TABLES `pro_community_groups_invite` WRITE;
/*!40000 ALTER TABLE `pro_community_groups_invite` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_groups_invite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_groups_members`
--

DROP TABLE IF EXISTS `pro_community_groups_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_groups_members` (
  `groupid` int(11) NOT NULL,
  `memberid` int(11) NOT NULL,
  `approved` int(11) NOT NULL,
  `permissions` int(1) NOT NULL,
  KEY `groupid` (`groupid`),
  KEY `idx_memberid` (`memberid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_groups_members`
--

LOCK TABLES `pro_community_groups_members` WRITE;
/*!40000 ALTER TABLE `pro_community_groups_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_groups_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_hashtag`
--

DROP TABLE IF EXISTS `pro_community_hashtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_hashtag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(128) NOT NULL,
  `params` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_hashtag`
--

LOCK TABLES `pro_community_hashtag` WRITE;
/*!40000 ALTER TABLE `pro_community_hashtag` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_hashtag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_invitations`
--

DROP TABLE IF EXISTS `pro_community_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_invitations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `callback` varchar(255) NOT NULL,
  `cid` int(11) NOT NULL,
  `users` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_invitations`
--

LOCK TABLES `pro_community_invitations` WRITE;
/*!40000 ALTER TABLE `pro_community_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_likes`
--

DROP TABLE IF EXISTS `pro_community_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `element` varchar(200) NOT NULL,
  `uid` int(10) NOT NULL,
  `like` text NOT NULL,
  `dislike` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `element` (`element`,`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_likes`
--

LOCK TABLES `pro_community_likes` WRITE;
/*!40000 ALTER TABLE `pro_community_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_location_cache`
--

DROP TABLE IF EXISTS `pro_community_location_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_location_cache` (
  `address` varchar(255) NOT NULL,
  `latitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `longitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `data` text NOT NULL,
  `status` varchar(2) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_location_cache`
--

LOCK TABLES `pro_community_location_cache` WRITE;
/*!40000 ALTER TABLE `pro_community_location_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_location_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_mailq`
--

DROP TABLE IF EXISTS `pro_community_mailq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_mailq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient` text NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `template` varchar(64) NOT NULL,
  `email_type` text,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_mailq`
--

LOCK TABLES `pro_community_mailq` WRITE;
/*!40000 ALTER TABLE `pro_community_mailq` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_mailq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_memberlist`
--

DROP TABLE IF EXISTS `pro_community_memberlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_memberlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `condition` varchar(255) NOT NULL,
  `avataronly` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_memberlist`
--

LOCK TABLES `pro_community_memberlist` WRITE;
/*!40000 ALTER TABLE `pro_community_memberlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_memberlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_memberlist_criteria`
--

DROP TABLE IF EXISTS `pro_community_memberlist_criteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_memberlist_criteria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `field` varchar(255) NOT NULL,
  `condition` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `listid` (`listid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_memberlist_criteria`
--

LOCK TABLES `pro_community_memberlist_criteria` WRITE;
/*!40000 ALTER TABLE `pro_community_memberlist_criteria` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_memberlist_criteria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_moods`
--

DROP TABLE IF EXISTS `pro_community_moods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_moods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `description` varchar(128) NOT NULL,
  `image` varchar(256) DEFAULT NULL,
  `custom` tinyint(4) NOT NULL,
  `published` tinyint(4) NOT NULL DEFAULT '1',
  `allowcustomtext` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_moods`
--

LOCK TABLES `pro_community_moods` WRITE;
/*!40000 ALTER TABLE `pro_community_moods` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_moods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_msg`
--

DROP TABLE IF EXISTS `pro_community_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_msg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  `deleted` tinyint(3) unsigned DEFAULT '0',
  `from_name` varchar(45) NOT NULL,
  `posted_on` datetime DEFAULT NULL,
  `subject` tinytext NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_msg`
--

LOCK TABLES `pro_community_msg` WRITE;
/*!40000 ALTER TABLE `pro_community_msg` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_msg_recepient`
--

DROP TABLE IF EXISTS `pro_community_msg_recepient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_msg_recepient` (
  `msg_id` int(10) unsigned NOT NULL,
  `msg_parent` int(10) unsigned NOT NULL DEFAULT '0',
  `msg_from` int(10) unsigned NOT NULL,
  `to` int(10) unsigned NOT NULL,
  `bcc` tinyint(3) unsigned DEFAULT '0',
  `is_read` tinyint(3) unsigned DEFAULT '0',
  `deleted` tinyint(3) unsigned DEFAULT '0',
  UNIQUE KEY `un` (`msg_id`,`to`),
  KEY `msg_id` (`msg_id`),
  KEY `to` (`to`),
  KEY `idx_isread_to_deleted` (`is_read`,`to`,`deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_msg_recepient`
--

LOCK TABLES `pro_community_msg_recepient` WRITE;
/*!40000 ALTER TABLE `pro_community_msg_recepient` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_msg_recepient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_notifications`
--

DROP TABLE IF EXISTS `pro_community_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actor` int(11) NOT NULL,
  `target` int(11) NOT NULL,
  `content` text NOT NULL,
  `type` varchar(200) NOT NULL,
  `cmd_type` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `status` (`status`),
  KEY `type` (`type`),
  KEY `target` (`target`),
  KEY `actor` (`actor`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_notifications`
--

LOCK TABLES `pro_community_notifications` WRITE;
/*!40000 ALTER TABLE `pro_community_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_oauth`
--

DROP TABLE IF EXISTS `pro_community_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_oauth` (
  `userid` int(11) NOT NULL,
  `requesttoken` text NOT NULL,
  `accesstoken` text NOT NULL,
  `app` varchar(255) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_oauth`
--

LOCK TABLES `pro_community_oauth` WRITE;
/*!40000 ALTER TABLE `pro_community_oauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_oauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_photo_stats`
--

DROP TABLE IF EXISTS `pro_community_photo_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_photo_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `date` date NOT NULL,
  `params` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_photo_stats`
--

LOCK TABLES `pro_community_photo_stats` WRITE;
/*!40000 ALTER TABLE `pro_community_photo_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_photo_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_photos`
--

DROP TABLE IF EXISTS `pro_community_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `albumid` int(11) NOT NULL,
  `caption` text NOT NULL,
  `published` tinyint(1) NOT NULL,
  `creator` int(11) NOT NULL,
  `permissions` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `original` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL DEFAULT '0',
  `storage` varchar(64) NOT NULL DEFAULT 'file',
  `created` datetime NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `status` varchar(200) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `albumid` (`albumid`),
  KEY `idx_storage` (`storage`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_photos`
--

LOCK TABLES `pro_community_photos` WRITE;
/*!40000 ALTER TABLE `pro_community_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_photos_albums`
--

DROP TABLE IF EXISTS `pro_community_photos_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_photos_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photoid` int(11) NOT NULL,
  `creator` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `permissions` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `path` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `groupid` int(11) NOT NULL DEFAULT '0',
  `eventid` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `location` text NOT NULL,
  `latitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `longitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `creator` (`creator`),
  KEY `idx_type` (`type`),
  KEY `idx_albumtype` (`id`,`type`),
  KEY `idx_creatortype` (`creator`,`type`),
  KEY `idx_groupid` (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_photos_albums`
--

LOCK TABLES `pro_community_photos_albums` WRITE;
/*!40000 ALTER TABLE `pro_community_photos_albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_photos_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_photos_tag`
--

DROP TABLE IF EXISTS `pro_community_photos_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_photos_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_photoid` (`photoid`),
  KEY `idx_userid` (`userid`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_photo_user` (`photoid`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_photos_tag`
--

LOCK TABLES `pro_community_photos_tag` WRITE;
/*!40000 ALTER TABLE `pro_community_photos_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_photos_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_photos_tokens`
--

DROP TABLE IF EXISTS `pro_community_photos_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_photos_tokens` (
  `userid` int(11) NOT NULL,
  `token` varchar(200) NOT NULL,
  `datetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_photos_tokens`
--

LOCK TABLES `pro_community_photos_tokens` WRITE;
/*!40000 ALTER TABLE `pro_community_photos_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_photos_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_profile_stats`
--

DROP TABLE IF EXISTS `pro_community_profile_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_profile_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `date` date NOT NULL,
  `params` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_profile_stats`
--

LOCK TABLES `pro_community_profile_stats` WRITE;
/*!40000 ALTER TABLE `pro_community_profile_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_profile_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_profiles`
--

DROP TABLE IF EXISTS `pro_community_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `approvals` tinyint(3) NOT NULL,
  `published` tinyint(3) NOT NULL,
  `avatar` text NOT NULL,
  `watermark` text NOT NULL,
  `watermark_hash` varchar(255) NOT NULL,
  `watermark_location` text NOT NULL,
  `thumb` text NOT NULL,
  `created` datetime NOT NULL,
  `create_groups` tinyint(1) DEFAULT '1',
  `create_events` int(11) DEFAULT '1',
  `profile_lock` tinyint(1) DEFAULT '0',
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `approvals` (`approvals`,`published`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_profiles`
--

LOCK TABLES `pro_community_profiles` WRITE;
/*!40000 ALTER TABLE `pro_community_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_profiles_fields`
--

DROP TABLE IF EXISTS `pro_community_profiles_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `multiprofile_id` (`parent`),
  KEY `field_id` (`field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_profiles_fields`
--

LOCK TABLES `pro_community_profiles_fields` WRITE;
/*!40000 ALTER TABLE `pro_community_profiles_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_profiles_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_register`
--

DROP TABLE IF EXISTS `pro_community_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_register` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(200) NOT NULL,
  `name` varchar(255) NOT NULL,
  `firstname` varchar(180) NOT NULL,
  `lastname` varchar(180) NOT NULL,
  `username` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `ip` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_register`
--

LOCK TABLES `pro_community_register` WRITE;
/*!40000 ALTER TABLE `pro_community_register` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_register_auth_token`
--

DROP TABLE IF EXISTS `pro_community_register_auth_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_register_auth_token` (
  `token` varchar(200) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `auth_key` varchar(200) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`token`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_register_auth_token`
--

LOCK TABLES `pro_community_register_auth_token` WRITE;
/*!40000 ALTER TABLE `pro_community_register_auth_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_register_auth_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_reports`
--

DROP TABLE IF EXISTS `pro_community_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniquestring` varchar(200) NOT NULL,
  `link` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_reports`
--

LOCK TABLES `pro_community_reports` WRITE;
/*!40000 ALTER TABLE `pro_community_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_reports_actions`
--

DROP TABLE IF EXISTS `pro_community_reports_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_reports_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reportid` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL,
  `parameters` varchar(255) NOT NULL,
  `defaultaction` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_reports_actions`
--

LOCK TABLES `pro_community_reports_actions` WRITE;
/*!40000 ALTER TABLE `pro_community_reports_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_reports_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_reports_reporter`
--

DROP TABLE IF EXISTS `pro_community_reports_reporter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_reports_reporter` (
  `reportid` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `ip` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_reports_reporter`
--

LOCK TABLES `pro_community_reports_reporter` WRITE;
/*!40000 ALTER TABLE `pro_community_reports_reporter` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_reports_reporter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_storage_s3`
--

DROP TABLE IF EXISTS `pro_community_storage_s3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_storage_s3` (
  `storageid` varchar(255) NOT NULL,
  `resource_path` varchar(255) NOT NULL,
  UNIQUE KEY `storageid` (`storageid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_storage_s3`
--

LOCK TABLES `pro_community_storage_s3` WRITE;
/*!40000 ALTER TABLE `pro_community_storage_s3` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_storage_s3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_tags`
--

DROP TABLE IF EXISTS `pro_community_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `element` varchar(200) NOT NULL,
  `userid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `tag` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_tags`
--

LOCK TABLES `pro_community_tags` WRITE;
/*!40000 ALTER TABLE `pro_community_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_tags_words`
--

DROP TABLE IF EXISTS `pro_community_tags_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_tags_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(200) NOT NULL,
  `count` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_tags_words`
--

LOCK TABLES `pro_community_tags_words` WRITE;
/*!40000 ALTER TABLE `pro_community_tags_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_tags_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_theme`
--

DROP TABLE IF EXISTS `pro_community_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(32) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_theme`
--

LOCK TABLES `pro_community_theme` WRITE;
/*!40000 ALTER TABLE `pro_community_theme` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_user_status`
--

DROP TABLE IF EXISTS `pro_community_user_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_user_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `status` text NOT NULL,
  `posted_on` int(11) NOT NULL,
  `location` text NOT NULL,
  `latitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `longitude` float(10,6) NOT NULL DEFAULT '255.000000',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_user_status`
--

LOCK TABLES `pro_community_user_status` WRITE;
/*!40000 ALTER TABLE `pro_community_user_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_user_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_userpoints`
--

DROP TABLE IF EXISTS `pro_community_userpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_userpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(255) NOT NULL DEFAULT '',
  `rule_description` text NOT NULL,
  `rule_plugin` varchar(255) NOT NULL DEFAULT '',
  `action_string` varchar(255) NOT NULL DEFAULT '',
  `component` varchar(255) NOT NULL DEFAULT '',
  `access` tinyint(1) NOT NULL DEFAULT '1',
  `points` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `system` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_userpoints`
--

LOCK TABLES `pro_community_userpoints` WRITE;
/*!40000 ALTER TABLE `pro_community_userpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_userpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_users`
--

DROP TABLE IF EXISTS `pro_community_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_users` (
  `userid` int(11) NOT NULL,
  `status` text NOT NULL,
  `status_access` int(11) NOT NULL DEFAULT '0',
  `points` int(11) NOT NULL,
  `posted_on` datetime NOT NULL,
  `avatar` text NOT NULL,
  `thumb` text NOT NULL,
  `cover` text NOT NULL,
  `invite` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `view` int(11) NOT NULL DEFAULT '0',
  `friends` text NOT NULL,
  `groups` text NOT NULL,
  `events` text NOT NULL,
  `friendcount` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL,
  `latitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `longitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `storage` varchar(64) NOT NULL DEFAULT 'file',
  `watermark_hash` varchar(255) NOT NULL,
  `search_email` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`userid`),
  KEY `alias` (`alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_users`
--

LOCK TABLES `pro_community_users` WRITE;
/*!40000 ALTER TABLE `pro_community_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_video_stats`
--

DROP TABLE IF EXISTS `pro_community_video_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_video_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `date` date NOT NULL,
  `params` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_video_stats`
--

LOCK TABLES `pro_community_video_stats` WRITE;
/*!40000 ALTER TABLE `pro_community_video_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_video_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_videos`
--

DROP TABLE IF EXISTS `pro_community_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_videos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL DEFAULT 'file',
  `video_id` varchar(200) DEFAULT NULL,
  `description` text NOT NULL,
  `creator` int(11) unsigned NOT NULL,
  `creator_type` varchar(200) NOT NULL DEFAULT 'user',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `permissions` varchar(255) NOT NULL DEFAULT '0',
  `category_id` int(11) unsigned NOT NULL,
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '1',
  `featured` tinyint(3) NOT NULL DEFAULT '0',
  `duration` float unsigned DEFAULT '0',
  `status` varchar(200) NOT NULL DEFAULT 'pending',
  `thumb` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `groupid` int(11) unsigned NOT NULL DEFAULT '0',
  `eventid` int(11) NOT NULL,
  `filesize` int(11) NOT NULL DEFAULT '0',
  `storage` varchar(64) NOT NULL DEFAULT 'file',
  `location` text NOT NULL,
  `latitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `longitude` float(10,6) NOT NULL DEFAULT '255.000000',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `creator` (`creator`),
  KEY `idx_groupid` (`groupid`),
  KEY `idx_storage` (`storage`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_videos`
--

LOCK TABLES `pro_community_videos` WRITE;
/*!40000 ALTER TABLE `pro_community_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_videos_category`
--

DROP TABLE IF EXISTS `pro_community_videos_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_videos_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `published` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_videos_category`
--

LOCK TABLES `pro_community_videos_category` WRITE;
/*!40000 ALTER TABLE `pro_community_videos_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_videos_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_videos_tag`
--

DROP TABLE IF EXISTS `pro_community_videos_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_videos_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `videoid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `position` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_videos_tag`
--

LOCK TABLES `pro_community_videos_tag` WRITE;
/*!40000 ALTER TABLE `pro_community_videos_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_videos_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_community_wall`
--

DROP TABLE IF EXISTS `pro_community_wall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_community_wall` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contentid` int(10) unsigned NOT NULL DEFAULT '0',
  `post_by` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(45) NOT NULL,
  `comment` text NOT NULL,
  `date` varchar(45) NOT NULL,
  `published` tinyint(1) unsigned NOT NULL,
  `type` varchar(200) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `contentid` (`contentid`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_community_wall`
--

LOCK TABLES `pro_community_wall` WRITE;
/*!40000 ALTER TABLE `pro_community_wall` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_community_wall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_contact_details`
--

DROP TABLE IF EXISTS `pro_contact_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` longtext COLLATE utf8mb4_unicode_ci,
  `suburb` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `misc` longtext COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `webpage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortname1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortname2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortname3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_contact_details`
--

LOCK TABLES `pro_contact_details` WRITE;
/*!40000 ALTER TABLE `pro_contact_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_contact_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_content`
--

DROP TABLE IF EXISTS `pro_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `introtext` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fulltext` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `urls` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribs` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_content`
--

LOCK TABLES `pro_content` WRITE;
/*!40000 ALTER TABLE `pro_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_content_frontpage`
--

DROP TABLE IF EXISTS `pro_content_frontpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_content_frontpage`
--

LOCK TABLES `pro_content_frontpage` WRITE;
/*!40000 ALTER TABLE `pro_content_frontpage` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_content_frontpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_content_rating`
--

DROP TABLE IF EXISTS `pro_content_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_content_rating`
--

LOCK TABLES `pro_content_rating` WRITE;
/*!40000 ALTER TABLE `pro_content_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_content_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_content_types`
--

DROP TABLE IF EXISTS `pro_content_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_content_types` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type_alias` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `rules` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_mappings` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `router` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON string for com_contenthistory options',
  PRIMARY KEY (`type_id`),
  KEY `idx_alias` (`type_alias`(100))
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_content_types`
--

LOCK TABLES `pro_content_types` WRITE;
/*!40000 ALTER TABLE `pro_content_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_content_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_contentitem_tag_map`
--

DROP TABLE IF EXISTS `pro_contentitem_tag_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_contentitem_tag_map` (
  `type_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table',
  UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  KEY `idx_tag_type` (`tag_id`,`type_id`),
  KEY `idx_date_id` (`tag_date`,`tag_id`),
  KEY `idx_core_content_id` (`core_content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Maps items from content tables to tags';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_contentitem_tag_map`
--

LOCK TABLES `pro_contentitem_tag_map` WRITE;
/*!40000 ALTER TABLE `pro_contentitem_tag_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_contentitem_tag_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_core_log_searches`
--

DROP TABLE IF EXISTS `pro_core_log_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_core_log_searches` (
  `search_term` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_core_log_searches`
--

LOCK TABLES `pro_core_log_searches` WRITE;
/*!40000 ALTER TABLE `pro_core_log_searches` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_core_log_searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_acl`
--

DROP TABLE IF EXISTS `pro_discuss_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_acl` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '1',
  `description` text NOT NULL,
  `published` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `public` tinyint(1) unsigned DEFAULT '0',
  `group` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_post_acl_action` (`action`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_acl`
--

LOCK TABLES `pro_discuss_acl` WRITE;
/*!40000 ALTER TABLE `pro_discuss_acl` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_acl_group`
--

DROP TABLE IF EXISTS `pro_discuss_acl_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_acl_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` bigint(20) unsigned NOT NULL,
  `acl_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_post_acl_content_type` (`content_id`,`type`),
  KEY `discuss_post_acl` (`acl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=265 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_acl_group`
--

LOCK TABLES `pro_discuss_acl_group` WRITE;
/*!40000 ALTER TABLE `pro_discuss_acl_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_acl_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_assignment_map`
--

DROP TABLE IF EXISTS `pro_discuss_assignment_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_assignment_map` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `assignee_id` bigint(20) unsigned NOT NULL,
  `assigner_id` bigint(20) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_assignment_map`
--

LOCK TABLES `pro_discuss_assignment_map` WRITE;
/*!40000 ALTER TABLE `pro_discuss_assignment_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_assignment_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_attachments`
--

DROP TABLE IF EXISTS `pro_discuss_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `title` text NOT NULL,
  `type` varchar(200) NOT NULL,
  `path` text NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(3) NOT NULL,
  `mime` text NOT NULL,
  `size` text NOT NULL,
  `storage` varchar(255) NOT NULL DEFAULT 'joomla',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_attachments`
--

LOCK TABLES `pro_discuss_attachments` WRITE;
/*!40000 ALTER TABLE `pro_discuss_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_badges`
--

DROP TABLE IF EXISTS `pro_discuss_badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_badges` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rule_id` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `avatar` text NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(3) NOT NULL,
  `rule_limit` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_badges_alias` (`alias`),
  KEY `discuss_badges_published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_badges`
--

LOCK TABLES `pro_discuss_badges` WRITE;
/*!40000 ALTER TABLE `pro_discuss_badges` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_badges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_badges_history`
--

DROP TABLE IF EXISTS `pro_discuss_badges_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_badges_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `command` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_badges_history`
--

LOCK TABLES `pro_discuss_badges_history` WRITE;
/*!40000 ALTER TABLE `pro_discuss_badges_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_badges_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_badges_rules`
--

DROP TABLE IF EXISTS `pro_discuss_badges_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_badges_rules` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `command` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `callback` text NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_badges_rules`
--

LOCK TABLES `pro_discuss_badges_rules` WRITE;
/*!40000 ALTER TABLE `pro_discuss_badges_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_badges_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_badges_users`
--

DROP TABLE IF EXISTS `pro_discuss_badges_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_badges_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `badge_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(3) NOT NULL,
  `custom` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `badge_id` (`badge_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_badges_users`
--

LOCK TABLES `pro_discuss_badges_users` WRITE;
/*!40000 ALTER TABLE `pro_discuss_badges_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_badges_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_captcha`
--

DROP TABLE IF EXISTS `pro_discuss_captcha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_captcha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `response` varchar(5) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_captcha`
--

LOCK TABLES `pro_discuss_captcha` WRITE;
/*!40000 ALTER TABLE `pro_discuss_captcha` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_captcha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_category`
--

DROP TABLE IF EXISTS `pro_discuss_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_by` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `private` int(11) unsigned NOT NULL DEFAULT '0',
  `default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `level` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `params` text NOT NULL,
  `container` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_cat_published` (`published`),
  KEY `discuss_cat_parentid` (`parent_id`),
  KEY `discuss_cat_mod_categories1` (`published`,`private`,`id`),
  KEY `discuss_cat_mod_categories2` (`published`,`private`,`ordering`),
  KEY `discuss_cat_acl` (`parent_id`,`published`,`ordering`),
  KEY `idx_cat_childs` (`parent_id`,`published`,`lft`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_rgt_lft` (`rgt`,`lft`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_category`
--

LOCK TABLES `pro_discuss_category` WRITE;
/*!40000 ALTER TABLE `pro_discuss_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_category_acl_item`
--

DROP TABLE IF EXISTS `pro_discuss_category_acl_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_category_acl_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `description` text,
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `default` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_category_acl_item`
--

LOCK TABLES `pro_discuss_category_acl_item` WRITE;
/*!40000 ALTER TABLE `pro_discuss_category_acl_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_category_acl_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_category_acl_map`
--

DROP TABLE IF EXISTS `pro_discuss_category_acl_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_category_acl_map` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) NOT NULL,
  `acl_id` bigint(20) NOT NULL,
  `type` varchar(25) NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `discuss_category_acl` (`category_id`),
  KEY `discuss_category_acl_id` (`acl_id`),
  KEY `discuss_content_type` (`content_id`,`type`),
  KEY `discuss_category_content_type` (`category_id`,`content_id`,`type`),
  KEY `discuss_category_acl_content_type` (`category_id`,`acl_id`,`content_id`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_category_acl_map`
--

LOCK TABLES `pro_discuss_category_acl_map` WRITE;
/*!40000 ALTER TABLE `pro_discuss_category_acl_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_category_acl_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_comments`
--

DROP TABLE IF EXISTS `pro_discuss_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment` text,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `ip` varchar(255) DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) unsigned DEFAULT '0',
  `ordering` tinyint(1) unsigned DEFAULT '0',
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `discuss_comment_postid` (`post_id`),
  KEY `discuss_comment_post_created` (`post_id`,`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_comments`
--

LOCK TABLES `pro_discuss_comments` WRITE;
/*!40000 ALTER TABLE `pro_discuss_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_configs`
--

DROP TABLE IF EXISTS `pro_discuss_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_configs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_configs`
--

LOCK TABLES `pro_discuss_configs` WRITE;
/*!40000 ALTER TABLE `pro_discuss_configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_conversations`
--

DROP TABLE IF EXISTS `pro_discuss_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_conversations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `lastreplied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_conversations`
--

LOCK TABLES `pro_discuss_conversations` WRITE;
/*!40000 ALTER TABLE `pro_discuss_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_conversations_message`
--

DROP TABLE IF EXISTS `pro_discuss_conversations_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_conversations_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `conversation_id` bigint(20) NOT NULL,
  `message` text,
  `created` datetime NOT NULL,
  `created_by` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conversation_id` (`conversation_id`),
  KEY `created_by` (`created_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_conversations_message`
--

LOCK TABLES `pro_discuss_conversations_message` WRITE;
/*!40000 ALTER TABLE `pro_discuss_conversations_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_conversations_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_conversations_message_maps`
--

DROP TABLE IF EXISTS `pro_discuss_conversations_message_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_conversations_message_maps` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `conversation_id` bigint(20) NOT NULL,
  `message_id` bigint(20) NOT NULL,
  `isread` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `node_id` (`user_id`),
  KEY `conversation_id` (`conversation_id`),
  KEY `message_id` (`message_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_conversations_message_maps`
--

LOCK TABLES `pro_discuss_conversations_message_maps` WRITE;
/*!40000 ALTER TABLE `pro_discuss_conversations_message_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_conversations_message_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_conversations_participants`
--

DROP TABLE IF EXISTS `pro_discuss_conversations_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_conversations_participants` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `conversation_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conversation_id` (`conversation_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_conversations_participants`
--

LOCK TABLES `pro_discuss_conversations_participants` WRITE;
/*!40000 ALTER TABLE `pro_discuss_conversations_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_conversations_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_customfields`
--

DROP TABLE IF EXISTS `pro_discuss_customfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_customfields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `tooltips` text NOT NULL,
  `params` text,
  `ordering` bigint(20) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `section` int(1) NOT NULL DEFAULT '1',
  `required` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_published_ordering` (`published`,`ordering`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_customfields`
--

LOCK TABLES `pro_discuss_customfields` WRITE;
/*!40000 ALTER TABLE `pro_discuss_customfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_customfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_customfields_acl`
--

DROP TABLE IF EXISTS `pro_discuss_customfields_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_customfields_acl` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `acl_published` tinyint(1) unsigned NOT NULL,
  `default` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_customfields_acl`
--

LOCK TABLES `pro_discuss_customfields_acl` WRITE;
/*!40000 ALTER TABLE `pro_discuss_customfields_acl` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_customfields_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_customfields_rule`
--

DROP TABLE IF EXISTS `pro_discuss_customfields_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_customfields_rule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` bigint(20) unsigned NOT NULL,
  `acl_id` bigint(20) NOT NULL,
  `content_id` int(10) NOT NULL,
  `content_type` varchar(25) NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cf_rule_field_id` (`field_id`),
  KEY `cf_rule_acl_types` (`content_type`,`acl_id`,`content_id`),
  KEY `idx_access` (`field_id`,`content_type`,`acl_id`,`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_customfields_rule`
--

LOCK TABLES `pro_discuss_customfields_rule` WRITE;
/*!40000 ALTER TABLE `pro_discuss_customfields_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_customfields_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_customfields_value`
--

DROP TABLE IF EXISTS `pro_discuss_customfields_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_customfields_value` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` bigint(20) unsigned NOT NULL,
  `value` text NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cf_value_field_id` (`field_id`),
  KEY `cf_value_field_post` (`field_id`,`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_customfields_value`
--

LOCK TABLES `pro_discuss_customfields_value` WRITE;
/*!40000 ALTER TABLE `pro_discuss_customfields_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_customfields_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_external_groups`
--

DROP TABLE IF EXISTS `pro_discuss_external_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_external_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `external_groups_post_id` (`post_id`),
  KEY `external_groups_group_id` (`group_id`),
  KEY `external_groups_posts` (`group_id`,`post_id`),
  KEY `external_groups` (`source`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_external_groups`
--

LOCK TABLES `pro_discuss_external_groups` WRITE;
/*!40000 ALTER TABLE `pro_discuss_external_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_external_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_favourites`
--

DROP TABLE IF EXISTS `pro_discuss_favourites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_favourites` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_by` bigint(20) NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fav_postid` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_favourites`
--

LOCK TABLES `pro_discuss_favourites` WRITE;
/*!40000 ALTER TABLE `pro_discuss_favourites` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_favourites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_hashkeys`
--

DROP TABLE IF EXISTS `pro_discuss_hashkeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_hashkeys` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `uid` bigint(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `key` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_hashkeys`
--

LOCK TABLES `pro_discuss_hashkeys` WRITE;
/*!40000 ALTER TABLE `pro_discuss_hashkeys` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_hashkeys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_holidays`
--

DROP TABLE IF EXISTS `pro_discuss_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_holidays` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `published` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `holiday_start_end` (`start`,`end`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_holidays`
--

LOCK TABLES `pro_discuss_holidays` WRITE;
/*!40000 ALTER TABLE `pro_discuss_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_languages`
--

DROP TABLE IF EXISTS `pro_discuss_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `updated` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `translator` varchar(255) NOT NULL,
  `progress` int(11) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_languages`
--

LOCK TABLES `pro_discuss_languages` WRITE;
/*!40000 ALTER TABLE `pro_discuss_languages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_likes`
--

DROP TABLE IF EXISTS `pro_discuss_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_likes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `content_id` int(11) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `discuss_content_type` (`type`,`content_id`),
  KEY `discuss_contentid` (`content_id`),
  KEY `discuss_createdby` (`created_by`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_likes`
--

LOCK TABLES `pro_discuss_likes` WRITE;
/*!40000 ALTER TABLE `pro_discuss_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_mailq`
--

DROP TABLE IF EXISTS `pro_discuss_mailq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_mailq` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mailfrom` varchar(255) DEFAULT NULL,
  `fromname` varchar(255) DEFAULT NULL,
  `recipient` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `created` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `ashtml` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_mailq_status` (`status`),
  KEY `idx_mailq_pending` (`status`,`created`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_mailq`
--

LOCK TABLES `pro_discuss_mailq` WRITE;
/*!40000 ALTER TABLE `pro_discuss_mailq` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_mailq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_migrators`
--

DROP TABLE IF EXISTS `pro_discuss_migrators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_migrators` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `internal_id` bigint(20) NOT NULL,
  `external_id` bigint(20) NOT NULL,
  `component` text NOT NULL,
  `type` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_external_id` (`external_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_migrators`
--

LOCK TABLES `pro_discuss_migrators` WRITE;
/*!40000 ALTER TABLE `pro_discuss_migrators` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_migrators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_notifications`
--

DROP TABLE IF EXISTS `pro_discuss_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `cid` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `target` bigint(20) NOT NULL,
  `author` bigint(20) NOT NULL,
  `permalink` text NOT NULL,
  `state` tinyint(4) NOT NULL,
  `favicon` text NOT NULL,
  `component` varchar(255) NOT NULL,
  `anonymous` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `discuss_notification_created` (`created`),
  KEY `discuss_notification` (`target`,`state`,`cid`,`created`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_notifications`
--

LOCK TABLES `pro_discuss_notifications` WRITE;
/*!40000 ALTER TABLE `pro_discuss_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_oauth`
--

DROP TABLE IF EXISTS `pro_discuss_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_oauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `request_token` text NOT NULL,
  `access_token` text NOT NULL,
  `message` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_oauth_type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_oauth`
--

LOCK TABLES `pro_discuss_oauth` WRITE;
/*!40000 ALTER TABLE `pro_discuss_oauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_oauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_oauth_posts`
--

DROP TABLE IF EXISTS `pro_discuss_oauth_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_oauth_posts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL,
  `oauth_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_oauth_posts`
--

LOCK TABLES `pro_discuss_oauth_posts` WRITE;
/*!40000 ALTER TABLE `pro_discuss_oauth_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_oauth_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_points`
--

DROP TABLE IF EXISTS `pro_discuss_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_points` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rule_id` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(3) NOT NULL,
  `rule_limit` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_points_rule` (`rule_id`),
  KEY `discuss_points_published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_points`
--

LOCK TABLES `pro_discuss_points` WRITE;
/*!40000 ALTER TABLE `pro_discuss_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_polls`
--

DROP TABLE IF EXISTS `pro_discuss_polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_polls` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL,
  `value` text NOT NULL,
  `count` bigint(20) NOT NULL DEFAULT '0',
  `multiple_polls` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `polls_posts` (`post_id`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_polls`
--

LOCK TABLES `pro_discuss_polls` WRITE;
/*!40000 ALTER TABLE `pro_discuss_polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_polls_question`
--

DROP TABLE IF EXISTS `pro_discuss_polls_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_polls_question` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `multiple` tinyint(1) DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_polls_question`
--

LOCK TABLES `pro_discuss_polls_question` WRITE;
/*!40000 ALTER TABLE `pro_discuss_polls_question` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_polls_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_polls_users`
--

DROP TABLE IF EXISTS `pro_discuss_polls_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_polls_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `poll_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `session_id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_polls_users`
--

LOCK TABLES `pro_discuss_polls_users` WRITE;
/*!40000 ALTER TABLE `pro_discuss_polls_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_polls_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_post_types`
--

DROP TABLE IF EXISTS `pro_discuss_post_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_post_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `suffix` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(3) NOT NULL,
  `alias` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_alias` (`alias`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_post_types`
--

LOCK TABLES `pro_discuss_post_types` WRITE;
/*!40000 ALTER TABLE `pro_discuss_post_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_post_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_posts`
--

DROP TABLE IF EXISTS `pro_discuss_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` text,
  `alias` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime DEFAULT '0000-00-00 00:00:00',
  `replied` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `content` longtext NOT NULL,
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vote` int(11) unsigned DEFAULT '0',
  `hits` int(11) unsigned DEFAULT '0',
  `islock` tinyint(1) unsigned DEFAULT '0',
  `lockdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `featured` tinyint(1) unsigned DEFAULT '0',
  `isresolve` tinyint(1) unsigned DEFAULT '0',
  `isreport` tinyint(1) unsigned DEFAULT '0',
  `answered` tinyint(1) unsigned DEFAULT '0',
  `user_id` bigint(20) unsigned DEFAULT '0',
  `parent_id` bigint(20) unsigned DEFAULT '0',
  `user_type` varchar(255) NOT NULL,
  `poster_name` varchar(255) NOT NULL,
  `poster_email` varchar(255) NOT NULL,
  `num_likes` int(11) DEFAULT '0',
  `num_negvote` int(11) DEFAULT '0',
  `sum_totalvote` int(11) DEFAULT '0',
  `category_id` bigint(20) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `password` text,
  `legacy` tinyint(1) DEFAULT '1',
  `address` text,
  `latitude` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `content_type` varchar(25) DEFAULT NULL,
  `post_status` tinyint(1) NOT NULL DEFAULT '0',
  `post_type` varchar(255) NOT NULL DEFAULT '0',
  `ip` varchar(255) NOT NULL,
  `private` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Determines if the discussion should be a private ticket or not.',
  `cluster_id` int(11) DEFAULT '0',
  `cluster_type` varchar(255) DEFAULT '0',
  `thread_id` bigint(20) unsigned DEFAULT '0',
  `preview` longtext,
  `priority` int(11) NOT NULL,
  `anonymous` tinyint(3) DEFAULT '0',
  `num_fav` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `discuss_post_published` (`published`),
  KEY `discuss_post_user_id` (`user_id`),
  KEY `discuss_post_vote` (`vote`),
  KEY `discuss_post_isreport` (`isreport`),
  KEY `discuss_post_answered` (`answered`),
  KEY `discuss_post_category` (`category_id`),
  KEY `discuss_post_query1` (`published`,`parent_id`,`answered`,`id`),
  KEY `discuss_post_query2` (`published`,`parent_id`,`answered`,`replied`),
  KEY `discuss_post_query3` (`published`,`parent_id`,`category_id`,`created`),
  KEY `discuss_post_query4` (`published`,`parent_id`,`category_id`,`id`),
  KEY `discuss_post_query5` (`published`,`parent_id`,`created`),
  KEY `discuss_post_query6` (`published`,`parent_id`,`id`),
  KEY `unread_category_posts` (`published`,`parent_id`,`legacy`,`category_id`,`id`),
  KEY `discuss_post_last_reply` (`parent_id`,`id`),
  KEY `idx_post_type` (`post_type`),
  KEY `private` (`private`),
  KEY `idx_post_replied` (`replied`),
  KEY `idx_post_created` (`created`),
  KEY `idx_post_private` (`private`),
  KEY `idx_post_search1` (`published`,`parent_id`,`private`,`replied`),
  KEY `idx_post_search2` (`published`,`private`,`created`),
  KEY `idx_post_search1a` (`published`,`parent_id`,`private`),
  KEY `idx_post_search2a` (`published`,`private`),
  KEY `discuss_post_parentid` (`published`,`parent_id`),
  KEY `idx_user_replies` (`user_id`,`published`,`parent_id`),
  KEY `idx_post_cat_published` (`category_id`,`published`),
  KEY `idx_threadid` (`thread_id`),
  FULLTEXT KEY `discuss_post_titlecontent` (`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_posts`
--

LOCK TABLES `pro_discuss_posts` WRITE;
/*!40000 ALTER TABLE `pro_discuss_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_posts_labels`
--

DROP TABLE IF EXISTS `pro_discuss_posts_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_posts_labels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` bigint(20) NOT NULL DEFAULT '0',
  `creator` bigint(20) unsigned NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_posts_labels`
--

LOCK TABLES `pro_discuss_posts_labels` WRITE;
/*!40000 ALTER TABLE `pro_discuss_posts_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_posts_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_posts_labels_map`
--

DROP TABLE IF EXISTS `pro_discuss_posts_labels_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_posts_labels_map` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `post_label_id` bigint(20) unsigned NOT NULL,
  `creator_id` bigint(20) unsigned NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_posts_labels_map`
--

LOCK TABLES `pro_discuss_posts_labels_map` WRITE;
/*!40000 ALTER TABLE `pro_discuss_posts_labels_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_posts_labels_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_posts_references`
--

DROP TABLE IF EXISTS `pro_discuss_posts_references`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_posts_references` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL,
  `reference_id` bigint(20) NOT NULL,
  `extension` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`,`reference_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_posts_references`
--

LOCK TABLES `pro_discuss_posts_references` WRITE;
/*!40000 ALTER TABLE `pro_discuss_posts_references` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_posts_references` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_posts_tags`
--

DROP TABLE IF EXISTS `pro_discuss_posts_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_posts_tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `tag_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_tag` (`post_id`,`tag_id`),
  KEY `discuss_posts_tags_tagid` (`tag_id`),
  KEY `discuss_posts_tags_postid` (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_posts_tags`
--

LOCK TABLES `pro_discuss_posts_tags` WRITE;
/*!40000 ALTER TABLE `pro_discuss_posts_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_posts_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_priorities`
--

DROP TABLE IF EXISTS `pro_discuss_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_priorities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_priorities`
--

LOCK TABLES `pro_discuss_priorities` WRITE;
/*!40000 ALTER TABLE `pro_discuss_priorities` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_priorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_ranks`
--

DROP TABLE IF EXISTS `pro_discuss_ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_ranks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `start` bigint(20) NOT NULL DEFAULT '0',
  `end` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `discuss_ranks_range` (`start`,`end`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_ranks`
--

LOCK TABLES `pro_discuss_ranks` WRITE;
/*!40000 ALTER TABLE `pro_discuss_ranks` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_ranks_users`
--

DROP TABLE IF EXISTS `pro_discuss_ranks_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_ranks_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rank_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ranks_users` (`rank_id`,`user_id`),
  KEY `ranks_id` (`rank_id`),
  KEY `ranks_userid` (`user_id`),
  KEY `idx_userrank` (`user_id`,`rank_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_ranks_users`
--

LOCK TABLES `pro_discuss_ranks_users` WRITE;
/*!40000 ALTER TABLE `pro_discuss_ranks_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_ranks_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_ratings`
--

DROP TABLE IF EXISTS `pro_discuss_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `sessionid` varchar(255) NOT NULL,
  `value` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `published` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ratings_uid_created_by` (`uid`,`created_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_ratings`
--

LOCK TABLES `pro_discuss_ratings` WRITE;
/*!40000 ALTER TABLE `pro_discuss_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_reports`
--

DROP TABLE IF EXISTS `pro_discuss_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `reason` text,
  `created_by` bigint(20) unsigned DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `discuss_reports_post` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_reports`
--

LOCK TABLES `pro_discuss_reports` WRITE;
/*!40000 ALTER TABLE `pro_discuss_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_roles`
--

DROP TABLE IF EXISTS `pro_discuss_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `usergroup_id` int(10) unsigned NOT NULL,
  `colorcode` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` bigint(20) NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_roles`
--

LOCK TABLES `pro_discuss_roles` WRITE;
/*!40000 ALTER TABLE `pro_discuss_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_rules`
--

DROP TABLE IF EXISTS `pro_discuss_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_rules` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `command` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `callback` text NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_rules_command` (`command`(255))
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_rules`
--

LOCK TABLES `pro_discuss_rules` WRITE;
/*!40000 ALTER TABLE `pro_discuss_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_subscription`
--

DROP TABLE IF EXISTS `pro_discuss_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_subscription` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) NOT NULL,
  `member` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(100) NOT NULL DEFAULT 'daily',
  `cid` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `interval` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `sent_out` datetime NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `sort` varchar(25) NOT NULL DEFAULT 'recent',
  `count` int(11) NOT NULL DEFAULT '10',
  PRIMARY KEY (`id`),
  KEY `idx_cron` (`state`,`type`,`interval`),
  KEY `idx_email_cron` (`state`,`type`(25),`interval`(25),`email`),
  KEY `idx_sentout` (`sent_out`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_subscription`
--

LOCK TABLES `pro_discuss_subscription` WRITE;
/*!40000 ALTER TABLE `pro_discuss_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_tags`
--

DROP TABLE IF EXISTS `pro_discuss_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(1) unsigned DEFAULT '0',
  `user_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_tags_alias` (`alias`),
  KEY `discuss_tags_user_id` (`user_id`),
  KEY `discuss_tags_published` (`published`),
  KEY `discuss_tags_query1` (`published`,`id`),
  FULLTEXT KEY `discuss_tags_title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_tags`
--

LOCK TABLES `pro_discuss_tags` WRITE;
/*!40000 ALTER TABLE `pro_discuss_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_thread`
--

DROP TABLE IF EXISTS `pro_discuss_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_thread` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` text,
  `alias` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime DEFAULT '0000-00-00 00:00:00',
  `replied` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` bigint(20) unsigned DEFAULT '0',
  `post_id` bigint(20) unsigned DEFAULT '0',
  `user_type` varchar(255) NOT NULL,
  `poster_name` varchar(255) NOT NULL,
  `poster_email` varchar(255) NOT NULL,
  `last_user_id` bigint(20) unsigned DEFAULT '0',
  `last_poster_name` varchar(255) NOT NULL,
  `last_poster_email` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `preview` longtext,
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `category_id` bigint(20) unsigned NOT NULL DEFAULT '1',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vote` int(11) unsigned DEFAULT '0',
  `sum_totalvote` int(11) DEFAULT '0',
  `hits` int(11) unsigned DEFAULT '0',
  `islock` tinyint(1) unsigned DEFAULT '0',
  `lockdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `featured` tinyint(1) unsigned DEFAULT '0',
  `isresolve` tinyint(1) unsigned DEFAULT '0',
  `isreport` tinyint(1) unsigned DEFAULT '0',
  `answered` tinyint(1) unsigned DEFAULT '0',
  `params` text NOT NULL,
  `password` text,
  `legacy` tinyint(1) DEFAULT '1',
  `address` text,
  `latitude` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `content_type` varchar(25) DEFAULT NULL,
  `post_status` tinyint(1) NOT NULL DEFAULT '0',
  `post_type` varchar(255) NOT NULL DEFAULT '0',
  `private` tinyint(3) NOT NULL DEFAULT '0',
  `num_likes` int(11) DEFAULT '0',
  `num_replies` int(11) DEFAULT '0',
  `num_negvote` int(11) DEFAULT '0',
  `num_fav` int(11) DEFAULT '0',
  `num_attachments` int(11) DEFAULT '0',
  `has_polls` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cluster_id` int(11) DEFAULT '0',
  `cluster_type` varchar(255) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_postid` (`post_id`),
  KEY `idx_published` (`published`),
  KEY `idx_userid` (`user_id`),
  KEY `idx_vote` (`vote`),
  KEY `idx_isreport` (`isreport`),
  KEY `idx_answered` (`answered`),
  KEY `idx_category` (`category_id`),
  KEY `unread_category_posts` (`published`,`legacy`,`category_id`,`id`),
  KEY `idx_post_type` (`post_type`),
  KEY `idx_post_replied` (`replied`),
  KEY `idx_post_created` (`created`),
  KEY `idx_post_search1` (`published`,`private`),
  KEY `idx_post_search2` (`published`,`private`,`replied`),
  KEY `idx_post_search3` (`published`,`private`,`created`),
  KEY `idx_user_replies` (`user_id`,`published`),
  KEY `idx_post_cat_published` (`category_id`,`published`),
  KEY `idx_featured` (`published`,`featured`,`private`,`cluster_id`,`replied`),
  KEY `idx_forums_featured_replied` (`published`,`private`,`cluster_id`,`category_id`,`featured`,`replied`),
  KEY `idx_forums` (`published`,`private`,`cluster_id`,`category_id`),
  KEY `idx_feature` (`featured`),
  KEY `idx_replied` (`replied`),
  FULLTEXT KEY `discuss_post_titlecontent` (`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_thread`
--

LOCK TABLES `pro_discuss_thread` WRITE;
/*!40000 ALTER TABLE `pro_discuss_thread` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_tnc`
--

DROP TABLE IF EXISTS `pro_discuss_tnc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_tnc` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT '0',
  `state` tinyint(2) NOT NULL,
  `ipaddress` varchar(15) NOT NULL,
  `session_id` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_tnc`
--

LOCK TABLES `pro_discuss_tnc` WRITE;
/*!40000 ALTER TABLE `pro_discuss_tnc` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_tnc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_users`
--

DROP TABLE IF EXISTS `pro_discuss_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_users` (
  `id` bigint(20) unsigned NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `description` text,
  `url` varchar(255) DEFAULT NULL,
  `params` text,
  `alias` varchar(255) DEFAULT NULL,
  `points` bigint(20) NOT NULL DEFAULT '0',
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `location` text NOT NULL,
  `signature` text NOT NULL,
  `edited` text NOT NULL,
  `posts_read` text,
  `site` text,
  `auth` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_users_alias` (`alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_users`
--

LOCK TABLES `pro_discuss_users` WRITE;
/*!40000 ALTER TABLE `pro_discuss_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_users_banned`
--

DROP TABLE IF EXISTS `pro_discuss_users_banned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_users_banned` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `banned_username` varchar(150) DEFAULT NULL,
  `userid` int(20) DEFAULT NULL,
  `ip` varchar(128) DEFAULT NULL,
  `blocked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created_by` int(20) NOT NULL,
  `start` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reason` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_users_banned`
--

LOCK TABLES `pro_discuss_users_banned` WRITE;
/*!40000 ALTER TABLE `pro_discuss_users_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_users_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_users_history`
--

DROP TABLE IF EXISTS `pro_discuss_users_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_users_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `command` text NOT NULL,
  `created` datetime NOT NULL,
  `content_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_users_history`
--

LOCK TABLES `pro_discuss_users_history` WRITE;
/*!40000 ALTER TABLE `pro_discuss_users_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_users_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_views`
--

DROP TABLE IF EXISTS `pro_discuss_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_views` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_views`
--

LOCK TABLES `pro_discuss_views` WRITE;
/*!40000 ALTER TABLE `pro_discuss_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_discuss_votes`
--

DROP TABLE IF EXISTS `pro_discuss_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_discuss_votes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `ipaddress` varchar(15) DEFAULT NULL,
  `value` tinyint(2) DEFAULT '0',
  `session_id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_user_post` (`user_id`,`post_id`),
  KEY `discuss_post_id` (`post_id`),
  KEY `discuss_user_id` (`user_id`),
  KEY `discuss_session_id` (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_discuss_votes`
--

LOCK TABLES `pro_discuss_votes` WRITE;
/*!40000 ALTER TABLE `pro_discuss_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_discuss_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_associations`
--

DROP TABLE IF EXISTS `pro_easyblog_associations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_postid` (`post_id`),
  KEY `idx_key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_associations`
--

LOCK TABLES `pro_easyblog_associations` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_associations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_category_fields_groups`
--

DROP TABLE IF EXISTS `pro_easyblog_category_fields_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_category_fields_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`,`group_id`),
  KEY `cat_id` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_category_fields_groups`
--

LOCK TABLES `pro_easyblog_category_fields_groups` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_category_fields_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_category_fields_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_composer_blocks`
--

DROP TABLE IF EXISTS `pro_easyblog_composer_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_composer_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` varchar(255) NOT NULL,
  `element` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` text NOT NULL,
  `published` tinyint(3) NOT NULL,
  `created` datetime DEFAULT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_published` (`published`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_composer_blocks`
--

LOCK TABLES `pro_easyblog_composer_blocks` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_composer_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_composer_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_fields`
--

DROP TABLE IF EXISTS `pro_easyblog_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `help` text NOT NULL,
  `state` tinyint(3) NOT NULL,
  `required` tinyint(3) NOT NULL,
  `type` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `created` datetime DEFAULT NULL,
  `options` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_fields`
--

LOCK TABLES `pro_easyblog_fields` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_fields_groups`
--

DROP TABLE IF EXISTS `pro_easyblog_fields_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_fields_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` datetime DEFAULT NULL,
  `state` tinyint(3) NOT NULL,
  `read` text NOT NULL,
  `write` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state` (`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_fields_groups`
--

LOCK TABLES `pro_easyblog_fields_groups` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_fields_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_fields_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_fields_values`
--

DROP TABLE IF EXISTS `pro_easyblog_fields_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_fields_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`),
  KEY `post_id` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_fields_values`
--

LOCK TABLES `pro_easyblog_fields_values` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_fields_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_fields_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_languages`
--

DROP TABLE IF EXISTS `pro_easyblog_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `updated` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `translator` varchar(255) NOT NULL,
  `progress` int(11) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_languages`
--

LOCK TABLES `pro_easyblog_languages` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_languages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_post_assets`
--

DROP TABLE IF EXISTS `pro_easyblog_post_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_post_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_post_assets`
--

LOCK TABLES `pro_easyblog_post_assets` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_post_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_post_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_post_category`
--

DROP TABLE IF EXISTS `pro_easyblog_post_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_post_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `primary` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `eb_post_category_postid` (`post_id`),
  KEY `eb_post_category_catid` (`category_id`),
  KEY `eb_post_category_post_cat` (`post_id`,`category_id`),
  KEY `eb_post_category_cat_post` (`category_id`,`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_post_category`
--

LOCK TABLES `pro_easyblog_post_category` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_post_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_post_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_post_templates`
--

DROP TABLE IF EXISTS `pro_easyblog_post_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_post_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` longtext,
  `created` datetime NOT NULL,
  `system` tinyint(1) NOT NULL,
  `core` tinyint(1) DEFAULT '0',
  `screenshot` text NOT NULL,
  `published` tinyint(3) DEFAULT '1',
  `datafix` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_post_templates`
--

LOCK TABLES `pro_easyblog_post_templates` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_post_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_post_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_reports`
--

DROP TABLE IF EXISTS `pro_easyblog_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_reports` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `obj_id` bigint(20) NOT NULL,
  `obj_type` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `obj_id` (`obj_id`,`created_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_reports`
--

LOCK TABLES `pro_easyblog_reports` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_revisions`
--

DROP TABLE IF EXISTS `pro_easyblog_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_revisions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `content` longtext NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_postid` (`post_id`),
  KEY `idx_ordering` (`post_id`,`ordering`),
  KEY `idx_revision_state` (`post_id`,`state`),
  KEY `idx_state` (`state`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_revisions`
--

LOCK TABLES `pro_easyblog_revisions` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_subscriptions`
--

DROP TABLE IF EXISTS `pro_easyblog_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `utype` varchar(64) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT '0',
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `easyblog_subscriptions_types` (`uid`,`utype`),
  KEY `easyblog_subscriptions_types_userid` (`uid`,`utype`,`user_id`),
  KEY `easyblog_subscriptions_types_email` (`uid`,`utype`,`email`),
  KEY `easyblog_subscriptions_userid` (`user_id`),
  KEY `easyblog_subscriptions_email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_subscriptions`
--

LOCK TABLES `pro_easyblog_subscriptions` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_easyblog_uploader_tmp`
--

DROP TABLE IF EXISTS `pro_easyblog_uploader_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_easyblog_uploader_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `path` text NOT NULL,
  `uri` text NOT NULL,
  `raw` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`),
  KEY `idx_uploader_created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_easyblog_uploader_tmp`
--

LOCK TABLES `pro_easyblog_uploader_tmp` WRITE;
/*!40000 ALTER TABLE `pro_easyblog_uploader_tmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_easyblog_uploader_tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_extensions`
--

DROP TABLE IF EXISTS `pro_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10324 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_extensions`
--

LOCK TABLES `pro_extensions` WRITE;
/*!40000 ALTER TABLE `pro_extensions` DISABLE KEYS */;
INSERT INTO `pro_extensions` VALUES (1,'com_mailto','component','com_mailto','',0,1,1,1,'{\"name\":\"com_mailto\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MAILTO_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mailto\"}','','','',0,'0000-00-00 00:00:00',0,0),(2,'com_wrapper','component','com_wrapper','',0,1,1,1,'{\"name\":\"com_wrapper\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_WRAPPER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"wrapper\"}','','','',0,'0000-00-00 00:00:00',0,0),(3,'com_admin','component','com_admin','',1,1,1,1,'{\"name\":\"com_admin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_ADMIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(4,'com_banners','component','com_banners','',1,1,1,0,'{\"name\":\"com_banners\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_BANNERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"banners\"}','{\"purchase_type\":\"3\",\"track_impressions\":\"0\",\"track_clicks\":\"0\",\"metakey_prefix\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(5,'com_cache','component','com_cache','',1,1,1,1,'{\"name\":\"com_cache\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CACHE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(6,'com_categories','component','com_categories','',1,1,1,1,'{\"name\":\"com_categories\",\"type\":\"component\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(7,'com_checkin','component','com_checkin','',1,1,1,1,'{\"name\":\"com_checkin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CHECKIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(8,'com_contact','component','com_contact','',1,1,1,0,'{\"name\":\"com_contact\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}','{\"show_contact_category\":\"hide\",\"show_contact_list\":\"0\",\"presentation_style\":\"sliders\",\"show_name\":\"1\",\"show_position\":\"1\",\"show_email\":\"0\",\"show_street_address\":\"1\",\"show_suburb\":\"1\",\"show_state\":\"1\",\"show_postcode\":\"1\",\"show_country\":\"1\",\"show_telephone\":\"1\",\"show_mobile\":\"1\",\"show_fax\":\"1\",\"show_webpage\":\"1\",\"show_misc\":\"1\",\"show_image\":\"1\",\"image\":\"\",\"allow_vcard\":\"0\",\"show_articles\":\"0\",\"show_profile\":\"0\",\"show_links\":\"0\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"contact_icons\":\"0\",\"icon_address\":\"\",\"icon_email\":\"\",\"icon_telephone\":\"\",\"icon_mobile\":\"\",\"icon_fax\":\"\",\"icon_misc\":\"\",\"show_headings\":\"1\",\"show_position_headings\":\"1\",\"show_email_headings\":\"0\",\"show_telephone_headings\":\"1\",\"show_mobile_headings\":\"0\",\"show_fax_headings\":\"0\",\"allow_vcard_headings\":\"0\",\"show_suburb_headings\":\"1\",\"show_state_headings\":\"1\",\"show_country_headings\":\"1\",\"show_email_form\":\"1\",\"show_email_copy\":\"1\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"1\",\"custom_reply\":\"0\",\"redirect\":\"\",\"show_category_crumb\":\"0\",\"metakey\":\"\",\"metadesc\":\"\",\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(9,'com_cpanel','component','com_cpanel','',1,1,1,1,'{\"name\":\"com_cpanel\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CPANEL_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10,'com_installer','component','com_installer','',1,1,1,1,'{\"name\":\"com_installer\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_INSTALLER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(11,'com_languages','component','com_languages','',1,1,1,1,'{\"name\":\"com_languages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\"}','{\"administrator\":\"en-GB\",\"site\":\"zh-CN\"}','','',0,'0000-00-00 00:00:00',0,0),(12,'com_login','component','com_login','',1,1,1,1,'{\"name\":\"com_login\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(13,'com_media','component','com_media','',1,1,0,1,'{\"name\":\"com_media\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MEDIA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"media\"}','{\"upload_extensions\":\"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\",\"upload_maxsize\":\"10\",\"file_path\":\"images\",\"image_path\":\"images\",\"restrict_uploads\":\"1\",\"allowed_media_usergroup\":\"3\",\"check_mime\":\"1\",\"image_extensions\":\"bmp,gif,jpg,png\",\"ignore_extensions\":\"\",\"upload_mime\":\"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip\",\"upload_mime_illegal\":\"text\\/html\"}','','',0,'0000-00-00 00:00:00',0,0),(14,'com_menus','component','com_menus','',1,1,1,1,'{\"name\":\"com_menus\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MENUS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(15,'com_messages','component','com_messages','',1,1,1,1,'{\"name\":\"com_messages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MESSAGES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(16,'com_modules','component','com_modules','',1,1,1,1,'{\"name\":\"com_modules\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MODULES_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(17,'com_newsfeeds','component','com_newsfeeds','',1,1,1,0,'{\"name\":\"com_newsfeeds\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}','{\"show_feed_image\":\"1\",\"show_feed_description\":\"1\",\"show_item_description\":\"1\",\"feed_word_count\":\"0\",\"show_headings\":\"1\",\"show_name\":\"1\",\"show_articles\":\"0\",\"show_link\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"1\",\"display_num\":\"\",\"show_pagination_limit\":\"1\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\",\"show_cat_items\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(18,'com_plugins','component','com_plugins','',1,1,1,1,'{\"name\":\"com_plugins\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_PLUGINS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(19,'com_search','component','com_search','',1,1,1,0,'{\"name\":\"com_search\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_SEARCH_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"search\"}','{\"enabled\":\"0\",\"show_date\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(20,'com_templates','component','com_templates','',1,1,1,1,'{\"name\":\"com_templates\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_TEMPLATES_XML_DESCRIPTION\",\"group\":\"\"}','{\"template_positions_display\":\"1\",\"upload_limit\":\"2\",\"image_formats\":\"gif,bmp,jpg,jpeg,png\",\"source_formats\":\"txt,less,ini,xml,js,php,css\",\"font_formats\":\"woff,ttf,otf\",\"compressed_formats\":\"zip\"}','','',0,'0000-00-00 00:00:00',0,0),(22,'com_content','component','com_content','',1,1,0,1,'{\"name\":\"com_content\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}','{\"article_layout\":\"_:default\",\"show_title\":\"1\",\"link_titles\":\"1\",\"show_intro\":\"1\",\"info_block_position\":\"0\",\"show_category\":\"1\",\"link_category\":\"1\",\"show_parent_category\":\"0\",\"link_parent_category\":\"0\",\"show_author\":\"1\",\"link_author\":\"0\",\"show_create_date\":\"0\",\"show_modify_date\":\"0\",\"show_publish_date\":\"1\",\"show_item_navigation\":\"1\",\"show_vote\":\"0\",\"show_readmore\":\"1\",\"show_readmore_title\":\"0\",\"readmore_limit\":\"100\",\"show_tags\":\"1\",\"show_icons\":\"1\",\"show_print_icon\":\"1\",\"show_email_icon\":\"1\",\"show_hits\":\"1\",\"show_noauth\":\"0\",\"urls_position\":\"0\",\"show_publishing_options\":\"1\",\"show_article_options\":\"1\",\"save_history\":\"0\",\"history_limit\":10,\"show_urls_images_frontend\":\"0\",\"show_urls_images_backend\":\"1\",\"targeta\":0,\"targetb\":0,\"targetc\":0,\"float_intro\":\"left\",\"float_fulltext\":\"left\",\"category_layout\":\"_:blog\",\"show_category_heading_title_text\":\"1\",\"show_category_title\":\"0\",\"show_description\":\"0\",\"show_description_image\":\"0\",\"maxLevel\":\"1\",\"show_empty_categories\":\"0\",\"show_no_articles\":\"1\",\"show_subcat_desc\":\"1\",\"show_cat_num_articles\":\"0\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_num_articles_cat\":\"1\",\"num_leading_articles\":\"1\",\"num_intro_articles\":\"4\",\"num_columns\":\"2\",\"num_links\":\"4\",\"multi_column_order\":\"0\",\"show_subcategory_content\":\"0\",\"show_pagination_limit\":\"1\",\"filter_field\":\"hide\",\"show_headings\":\"1\",\"list_show_date\":\"0\",\"date_format\":\"y-m-d\",\"list_show_hits\":\"1\",\"list_show_author\":\"1\",\"orderby_pri\":\"order\",\"orderby_sec\":\"rdate\",\"order_date\":\"published\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_feed_link\":\"1\",\"feed_summary\":\"0\",\"feed_show_readmore\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(23,'com_config','component','com_config','',1,1,0,1,'{\"name\":\"com_config\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONFIG_XML_DESCRIPTION\",\"group\":\"\"}','{\"filters\":{\"1\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"13\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"6\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"7\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"2\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"3\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"4\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"5\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"10\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"12\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"8\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"}}}','','',0,'0000-00-00 00:00:00',0,0),(24,'com_redirect','component','com_redirect','',1,1,0,1,'{\"name\":\"com_redirect\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(25,'com_users','component','com_users','',1,1,0,1,'{\"name\":\"com_users\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_USERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"users\"}','{\"allowUserRegistration\":\"1\",\"new_usertype\":\"2\",\"guest_usergroup\":\"13\",\"sendpassword\":\"1\",\"useractivation\":\"1\",\"mail_to_admin\":\"0\",\"captcha\":\"\",\"frontend_userparams\":\"1\",\"site_language\":\"0\",\"change_login_name\":\"0\",\"reset_count\":\"10\",\"reset_time\":\"1\",\"mailSubjectPrefix\":\"\",\"mailBodySuffix\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(27,'com_finder','component','com_finder','',1,1,0,0,'{\"name\":\"com_finder\",\"type\":\"component\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}','{\"show_description\":\"1\",\"description_length\":255,\"allow_empty_query\":\"0\",\"show_url\":\"1\",\"show_advanced\":\"1\",\"expand_advanced\":\"0\",\"show_date_filters\":\"0\",\"highlight_terms\":\"1\",\"opensearch_name\":\"\",\"opensearch_description\":\"\",\"batch_size\":\"50\",\"memory_table_limit\":30000,\"title_multiplier\":\"1.7\",\"text_multiplier\":\"0.7\",\"meta_multiplier\":\"1.2\",\"path_multiplier\":\"2.0\",\"misc_multiplier\":\"0.3\",\"stemmer\":\"snowball\"}','','',0,'0000-00-00 00:00:00',0,0),(28,'com_joomlaupdate','component','com_joomlaupdate','',1,1,0,1,'{\"name\":\"com_joomlaupdate\",\"type\":\"component\",\"creationDate\":\"February 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.2\",\"description\":\"COM_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(29,'com_tags','component','com_tags','',1,1,1,1,'{\"name\":\"com_tags\",\"type\":\"component\",\"creationDate\":\"December 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"COM_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}','{\"show_tag_title\":\"0\",\"tag_list_show_tag_image\":\"0\",\"tag_list_show_tag_description\":\"0\",\"tag_list_image\":\"\",\"show_tag_num_items\":\"0\",\"tag_list_orderby\":\"title\",\"tag_list_orderby_direction\":\"ASC\",\"show_headings\":\"0\",\"tag_list_show_date\":\"0\",\"tag_list_show_item_image\":\"0\",\"tag_list_show_item_description\":\"0\",\"tag_list_item_maximum_characters\":0,\"return_any_or_all\":\"1\",\"include_children\":\"0\",\"maximum\":200,\"tag_list_language_filter\":\"all\",\"tags_layout\":\"_:default\",\"all_tags_orderby\":\"title\",\"all_tags_orderby_direction\":\"ASC\",\"all_tags_show_tag_image\":\"0\",\"all_tags_show_tag_descripion\":\"0\",\"all_tags_tag_maximum_characters\":20,\"all_tags_show_tag_hits\":\"0\",\"filter_field\":\"1\",\"show_pagination_limit\":\"1\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"tag_field_ajax_mode\":\"1\",\"show_feed_link\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(30,'com_contenthistory','component','com_contenthistory','',1,1,1,0,'{\"name\":\"com_contenthistory\",\"type\":\"component\",\"creationDate\":\"May 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_CONTENTHISTORY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contenthistory\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(31,'com_ajax','component','com_ajax','',1,1,1,1,'{\"name\":\"com_ajax\",\"type\":\"component\",\"creationDate\":\"August 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_AJAX_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"ajax\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(32,'com_postinstall','component','com_postinstall','',1,1,1,1,'{\"name\":\"com_postinstall\",\"type\":\"component\",\"creationDate\":\"September 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_POSTINSTALL_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(102,'LIB_PHPUTF8','library','phputf8','',0,1,1,1,'{\"name\":\"LIB_PHPUTF8\",\"type\":\"library\",\"creationDate\":\"2006\",\"author\":\"Harry Fuecks\",\"copyright\":\"Copyright various authors\",\"authorEmail\":\"hfuecks@gmail.com\",\"authorUrl\":\"http:\\/\\/sourceforge.net\\/projects\\/phputf8\",\"version\":\"0.5\",\"description\":\"LIB_PHPUTF8_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phputf8\"}','','','',0,'0000-00-00 00:00:00',0,0),(103,'LIB_JOOMLA','library','joomla','',0,1,1,1,'{\"name\":\"LIB_JOOMLA\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"https:\\/\\/www.joomla.org\",\"version\":\"13.1\",\"description\":\"LIB_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','{\"mediaversion\":\"2465f6f36f32417fce2fcf78e762d0e4\"}','','',0,'0000-00-00 00:00:00',0,0),(104,'LIB_IDNA','library','idna_convert','',0,1,1,1,'{\"name\":\"LIB_IDNA\",\"type\":\"library\",\"creationDate\":\"2004\",\"author\":\"phlyLabs\",\"copyright\":\"2004-2011 phlyLabs Berlin, http:\\/\\/phlylabs.de\",\"authorEmail\":\"phlymail@phlylabs.de\",\"authorUrl\":\"http:\\/\\/phlylabs.de\",\"version\":\"0.8.0\",\"description\":\"LIB_IDNA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"idna_convert\"}','','','',0,'0000-00-00 00:00:00',0,0),(105,'FOF','library','fof','',0,1,1,1,'{\"name\":\"FOF\",\"type\":\"library\",\"creationDate\":\"2015-04-22 13:15:32\",\"author\":\"Nicholas K. Dionysopoulos \\/ Akeeba Ltd\",\"copyright\":\"(C)2011-2015 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@akeebabackup.com\",\"authorUrl\":\"https:\\/\\/www.akeebabackup.com\",\"version\":\"2.4.3\",\"description\":\"LIB_FOF_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"fof\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(200,'mod_articles_archive','module','mod_articles_archive','',0,1,1,0,'{\"name\":\"mod_articles_archive\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_archive\"}','','','',0,'0000-00-00 00:00:00',0,0),(201,'mod_articles_latest','module','mod_articles_latest','',0,1,1,0,'{\"name\":\"mod_articles_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_NEWS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_latest\"}','','','',0,'0000-00-00 00:00:00',0,0),(202,'mod_articles_popular','module','mod_articles_popular','',0,1,1,0,'{\"name\":\"mod_articles_popular\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_popular\"}','','','',0,'0000-00-00 00:00:00',0,0),(203,'mod_banners','module','mod_banners','',0,1,1,0,'{\"name\":\"mod_banners\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BANNERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_banners\"}','','','',0,'0000-00-00 00:00:00',0,0),(204,'mod_breadcrumbs','module','mod_breadcrumbs','',0,1,1,1,'{\"name\":\"mod_breadcrumbs\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BREADCRUMBS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_breadcrumbs\"}','','','',0,'0000-00-00 00:00:00',0,0),(205,'mod_custom','module','mod_custom','',0,1,1,1,'{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_custom\"}','','','',0,'0000-00-00 00:00:00',0,0),(206,'mod_feed','module','mod_feed','',0,1,1,0,'{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_feed\"}','','','',0,'0000-00-00 00:00:00',0,0),(207,'mod_footer','module','mod_footer','',0,1,1,0,'{\"name\":\"mod_footer\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FOOTER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_footer\"}','','','',0,'0000-00-00 00:00:00',0,0),(208,'mod_login','module','mod_login','',0,1,1,1,'{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_login\"}','','','',0,'0000-00-00 00:00:00',0,0),(209,'mod_menu','module','mod_menu','',0,1,1,1,'{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_menu\"}','','','',0,'0000-00-00 00:00:00',0,0),(210,'mod_articles_news','module','mod_articles_news','',0,1,1,0,'{\"name\":\"mod_articles_news\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_NEWS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_news\"}','','','',0,'0000-00-00 00:00:00',0,0),(211,'mod_random_image','module','mod_random_image','',0,1,1,0,'{\"name\":\"mod_random_image\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RANDOM_IMAGE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_random_image\"}','','','',0,'0000-00-00 00:00:00',0,0),(212,'mod_related_items','module','mod_related_items','',0,1,1,0,'{\"name\":\"mod_related_items\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RELATED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_related_items\"}','','','',0,'0000-00-00 00:00:00',0,0),(213,'mod_search','module','mod_search','',0,1,1,0,'{\"name\":\"mod_search\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SEARCH_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_search\"}','','','',0,'0000-00-00 00:00:00',0,0),(214,'mod_stats','module','mod_stats','',0,1,1,0,'{\"name\":\"mod_stats\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stats\"}','','','',0,'0000-00-00 00:00:00',0,0),(215,'mod_syndicate','module','mod_syndicate','',0,1,1,1,'{\"name\":\"mod_syndicate\",\"type\":\"module\",\"creationDate\":\"May 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SYNDICATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_syndicate\"}','','','',0,'0000-00-00 00:00:00',0,0),(216,'mod_users_latest','module','mod_users_latest','',0,1,1,0,'{\"name\":\"mod_users_latest\",\"type\":\"module\",\"creationDate\":\"December 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_USERS_LATEST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_users_latest\"}','','','',0,'0000-00-00 00:00:00',0,0),(218,'mod_whosonline','module','mod_whosonline','',0,1,1,0,'{\"name\":\"mod_whosonline\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WHOSONLINE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_whosonline\"}','','','',0,'0000-00-00 00:00:00',0,0),(219,'mod_wrapper','module','mod_wrapper','',0,1,1,0,'{\"name\":\"mod_wrapper\",\"type\":\"module\",\"creationDate\":\"October 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WRAPPER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_wrapper\"}','','','',0,'0000-00-00 00:00:00',0,0),(220,'mod_articles_category','module','mod_articles_category','',0,1,1,0,'{\"name\":\"mod_articles_category\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_category\"}','','','',0,'0000-00-00 00:00:00',0,0),(221,'mod_articles_categories','module','mod_articles_categories','',0,1,1,0,'{\"name\":\"mod_articles_categories\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_categories\"}','','','',0,'0000-00-00 00:00:00',0,0),(222,'mod_languages','module','mod_languages','',0,1,1,1,'{\"name\":\"mod_languages\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"MOD_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_languages\"}','','','',0,'0000-00-00 00:00:00',0,0),(223,'mod_finder','module','mod_finder','',0,1,0,0,'{\"name\":\"mod_finder\",\"type\":\"module\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_finder\"}','','','',0,'0000-00-00 00:00:00',0,0),(300,'mod_custom','module','mod_custom','',1,1,1,1,'{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_custom\"}','','','',0,'0000-00-00 00:00:00',0,0),(301,'mod_feed','module','mod_feed','',1,1,1,0,'{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_feed\"}','','','',0,'0000-00-00 00:00:00',0,0),(302,'mod_latest','module','mod_latest','',1,1,1,0,'{\"name\":\"mod_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_latest\"}','','','',0,'0000-00-00 00:00:00',0,0),(303,'mod_logged','module','mod_logged','',1,1,1,0,'{\"name\":\"mod_logged\",\"type\":\"module\",\"creationDate\":\"January 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGGED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_logged\"}','','','',0,'0000-00-00 00:00:00',0,0),(304,'mod_login','module','mod_login','',1,1,1,1,'{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"March 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_login\"}','','','',0,'0000-00-00 00:00:00',0,0),(305,'mod_menu','module','mod_menu','',1,1,1,0,'{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_menu\"}','','','',0,'0000-00-00 00:00:00',0,0),(307,'mod_popular','module','mod_popular','',1,1,1,0,'{\"name\":\"mod_popular\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_popular\"}','','','',0,'0000-00-00 00:00:00',0,0),(308,'mod_quickicon','module','mod_quickicon','',1,1,1,1,'{\"name\":\"mod_quickicon\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_QUICKICON_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_quickicon\"}','','','',0,'0000-00-00 00:00:00',0,0),(309,'mod_status','module','mod_status','',1,1,1,0,'{\"name\":\"mod_status\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATUS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_status\"}','','','',0,'0000-00-00 00:00:00',0,0),(310,'mod_submenu','module','mod_submenu','',1,1,1,0,'{\"name\":\"mod_submenu\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SUBMENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_submenu\"}','','','',0,'0000-00-00 00:00:00',0,0),(311,'mod_title','module','mod_title','',1,1,1,0,'{\"name\":\"mod_title\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TITLE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_title\"}','','','',0,'0000-00-00 00:00:00',0,0),(312,'mod_toolbar','module','mod_toolbar','',1,1,1,1,'{\"name\":\"mod_toolbar\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TOOLBAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_toolbar\"}','','','',0,'0000-00-00 00:00:00',0,0),(313,'mod_multilangstatus','module','mod_multilangstatus','',1,1,1,0,'{\"name\":\"mod_multilangstatus\",\"type\":\"module\",\"creationDate\":\"September 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MULTILANGSTATUS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_multilangstatus\"}','{\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(314,'mod_version','module','mod_version','',1,1,1,0,'{\"name\":\"mod_version\",\"type\":\"module\",\"creationDate\":\"January 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_VERSION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_version\"}','{\"format\":\"short\",\"product\":\"1\",\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(315,'mod_stats_admin','module','mod_stats_admin','',1,1,1,0,'{\"name\":\"mod_stats_admin\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stats_admin\"}','{\"serverinfo\":\"0\",\"siteinfo\":\"0\",\"counter\":\"0\",\"increase\":\"0\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}','','',0,'0000-00-00 00:00:00',0,0),(316,'mod_tags_popular','module','mod_tags_popular','',0,1,1,0,'{\"name\":\"mod_tags_popular\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_tags_popular\"}','{\"maximum\":\"5\",\"timeframe\":\"alltime\",\"owncache\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(400,'plg_authentication_gmail','plugin','gmail','authentication',0,0,1,0,'{\"name\":\"plg_authentication_gmail\",\"type\":\"plugin\",\"creationDate\":\"February 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_GMAIL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"gmail\"}','{\"applysuffix\":\"0\",\"suffix\":\"\",\"verifypeer\":\"1\",\"user_blacklist\":\"\"}','','',0,'0000-00-00 00:00:00',1,0),(401,'plg_authentication_joomla','plugin','joomla','authentication',0,1,1,1,'{\"name\":\"plg_authentication_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(402,'plg_authentication_ldap','plugin','ldap','authentication',0,0,1,0,'{\"name\":\"plg_authentication_ldap\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LDAP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"ldap\"}','{\"host\":\"\",\"port\":\"389\",\"use_ldapV3\":\"0\",\"negotiate_tls\":\"0\",\"no_referrals\":\"0\",\"auth_method\":\"bind\",\"base_dn\":\"\",\"search_string\":\"\",\"users_dn\":\"\",\"username\":\"admin\",\"password\":\"bobby7\",\"ldap_fullname\":\"fullName\",\"ldap_email\":\"mail\",\"ldap_uid\":\"uid\"}','','',0,'0000-00-00 00:00:00',3,0),(404,'plg_content_emailcloak','plugin','emailcloak','content',0,1,1,0,'{\"name\":\"plg_content_emailcloak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"emailcloak\"}','{\"mode\":\"1\"}','','',0,'0000-00-00 00:00:00',1,0),(406,'plg_content_loadmodule','plugin','loadmodule','content',0,1,1,0,'{\"name\":\"plg_content_loadmodule\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOADMODULE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"loadmodule\"}','{\"style\":\"xhtml\"}','','',0,'0000-00-00 00:00:00',0,0),(407,'plg_content_pagebreak','plugin','pagebreak','content',0,1,1,0,'{\"name\":\"plg_content_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagebreak\"}','{\"title\":\"1\",\"multipage_toc\":\"1\",\"showall\":\"1\"}','','',0,'0000-00-00 00:00:00',4,0),(408,'plg_content_pagenavigation','plugin','pagenavigation','content',0,1,1,0,'{\"name\":\"plg_content_pagenavigation\",\"type\":\"plugin\",\"creationDate\":\"January 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_PAGENAVIGATION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagenavigation\"}','{\"position\":\"1\"}','','',0,'0000-00-00 00:00:00',5,0),(409,'plg_content_vote','plugin','vote','content',0,1,1,0,'{\"name\":\"plg_content_vote\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_VOTE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"vote\"}','{}','','',0,'0000-00-00 00:00:00',6,0),(410,'plg_editors_codemirror','plugin','codemirror','editors',0,1,1,1,'{\"name\":\"plg_editors_codemirror\",\"type\":\"plugin\",\"creationDate\":\"28 March 2011\",\"author\":\"Marijn Haverbeke\",\"copyright\":\"Copyright (C) 2014 by Marijn Haverbeke <marijnh@gmail.com> and others\",\"authorEmail\":\"marijnh@gmail.com\",\"authorUrl\":\"http:\\/\\/codemirror.net\\/\",\"version\":\"5.18.0\",\"description\":\"PLG_CODEMIRROR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"codemirror\"}','{\"lineNumbers\":\"1\",\"lineWrapping\":\"1\",\"matchTags\":\"1\",\"matchBrackets\":\"1\",\"marker-gutter\":\"1\",\"autoCloseTags\":\"1\",\"autoCloseBrackets\":\"1\",\"autoFocus\":\"1\",\"theme\":\"default\",\"tabmode\":\"indent\"}','','',0,'0000-00-00 00:00:00',1,0),(411,'plg_editors_none','plugin','none','editors',0,1,1,1,'{\"name\":\"plg_editors_none\",\"type\":\"plugin\",\"creationDate\":\"September 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_NONE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"none\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(412,'plg_editors_tinymce','plugin','tinymce','editors',0,1,1,0,'{\"name\":\"plg_editors_tinymce\",\"type\":\"plugin\",\"creationDate\":\"2005-2016\",\"author\":\"Ephox Corporation\",\"copyright\":\"Ephox Corporation\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"http:\\/\\/www.tinymce.com\",\"version\":\"4.4.3\",\"description\":\"PLG_TINY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tinymce\"}','{\"mode\":\"1\",\"skin\":\"0\",\"entity_encoding\":\"raw\",\"lang_mode\":\"0\",\"lang_code\":\"en\",\"text_direction\":\"ltr\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"relative_urls\":\"1\",\"newlines\":\"0\",\"invalid_elements\":\"script,applet,iframe\",\"extended_elements\":\"\",\"toolbar\":\"top\",\"toolbar_align\":\"left\",\"html_height\":\"550\",\"html_width\":\"750\",\"resizing\":\"true\",\"resize_horizontal\":\"false\",\"element_path\":\"1\",\"fonts\":\"1\",\"paste\":\"1\",\"searchreplace\":\"1\",\"insertdate\":\"1\",\"format_date\":\"%Y-%m-%d\",\"inserttime\":\"1\",\"format_time\":\"%H:%M:%S\",\"colors\":\"1\",\"table\":\"1\",\"smilies\":\"1\",\"media\":\"1\",\"hr\":\"1\",\"directionality\":\"1\",\"fullscreen\":\"1\",\"style\":\"1\",\"layer\":\"1\",\"xhtmlxtras\":\"1\",\"visualchars\":\"1\",\"nonbreaking\":\"1\",\"template\":\"1\",\"blockquote\":\"1\",\"wordcount\":\"1\",\"advimage\":\"1\",\"advlink\":\"1\",\"advlist\":\"1\",\"autosave\":\"1\",\"contextmenu\":\"1\",\"inlinepopups\":\"1\",\"custom_plugin\":\"\",\"custom_button\":\"\"}','','',0,'0000-00-00 00:00:00',3,0),(413,'plg_editors-xtd_article','plugin','article','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_article\",\"type\":\"plugin\",\"creationDate\":\"October 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_ARTICLE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"article\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(414,'plg_editors-xtd_image','plugin','image','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_image\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_IMAGE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"image\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(415,'plg_editors-xtd_pagebreak','plugin','pagebreak','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagebreak\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(416,'plg_editors-xtd_readmore','plugin','readmore','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_readmore\",\"type\":\"plugin\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_READMORE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"readmore\"}','{}','','',0,'0000-00-00 00:00:00',4,0),(417,'plg_search_categories','plugin','categories','search',0,1,1,0,'{\"name\":\"plg_search_categories\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"categories\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(418,'plg_search_contacts','plugin','contacts','search',0,1,1,0,'{\"name\":\"plg_search_contacts\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTACTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contacts\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(419,'plg_search_content','plugin','content','search',0,1,1,0,'{\"name\":\"plg_search_content\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(420,'plg_search_newsfeeds','plugin','newsfeeds','search',0,1,1,0,'{\"name\":\"plg_search_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(422,'plg_system_languagefilter','plugin','languagefilter','system',0,0,1,1,'{\"name\":\"plg_system_languagefilter\",\"type\":\"plugin\",\"creationDate\":\"July 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"languagefilter\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(423,'plg_system_p3p','plugin','p3p','system',0,1,1,0,'{\"name\":\"plg_system_p3p\",\"type\":\"plugin\",\"creationDate\":\"September 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_P3P_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"p3p\"}','{\"headers\":\"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM\"}','','',0,'0000-00-00 00:00:00',2,0),(424,'plg_system_cache','plugin','cache','system',0,0,1,1,'{\"name\":\"plg_system_cache\",\"type\":\"plugin\",\"creationDate\":\"February 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CACHE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"cache\"}','{\"browsercache\":\"0\",\"cachetime\":\"15\"}','','',0,'0000-00-00 00:00:00',9,0),(425,'plg_system_debug','plugin','debug','system',0,1,1,0,'{\"name\":\"plg_system_debug\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_DEBUG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"debug\"}','{\"profile\":\"1\",\"queries\":\"1\",\"memory\":\"1\",\"language_files\":\"1\",\"language_strings\":\"1\",\"strip-first\":\"1\",\"strip-prefix\":\"\",\"strip-suffix\":\"\"}','','',0,'0000-00-00 00:00:00',4,0),(426,'plg_system_log','plugin','log','system',0,1,1,1,'{\"name\":\"plg_system_log\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"log\"}','{}','','',0,'0000-00-00 00:00:00',5,0),(427,'plg_system_redirect','plugin','redirect','system',0,0,1,1,'{\"name\":\"plg_system_redirect\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"redirect\"}','{}','','',0,'0000-00-00 00:00:00',6,0),(428,'plg_system_remember','plugin','remember','system',0,1,1,1,'{\"name\":\"plg_system_remember\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_REMEMBER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"remember\"}','{}','','',0,'0000-00-00 00:00:00',7,0),(429,'plg_system_sef','plugin','sef','system',0,1,1,0,'{\"name\":\"plg_system_sef\",\"type\":\"plugin\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEF_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"sef\"}','{}','','',0,'0000-00-00 00:00:00',8,0),(430,'plg_system_logout','plugin','logout','system',0,1,1,1,'{\"name\":\"plg_system_logout\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"logout\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(431,'plg_user_contactcreator','plugin','contactcreator','user',0,0,1,0,'{\"name\":\"plg_user_contactcreator\",\"type\":\"plugin\",\"creationDate\":\"August 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTACTCREATOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contactcreator\"}','{\"autowebpage\":\"\",\"category\":\"34\",\"autopublish\":\"0\"}','','',0,'0000-00-00 00:00:00',1,0),(432,'plg_user_joomla','plugin','joomla','user',0,1,1,0,'{\"name\":\"plg_user_joomla\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','{\"autoregister\":\"1\"}','','',0,'0000-00-00 00:00:00',2,0),(433,'plg_user_profile','plugin','profile','user',0,0,1,0,'{\"name\":\"plg_user_profile\",\"type\":\"plugin\",\"creationDate\":\"January 2008\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_PROFILE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"profile\"}','{\"register-require_address1\":\"1\",\"register-require_address2\":\"1\",\"register-require_city\":\"1\",\"register-require_region\":\"1\",\"register-require_country\":\"1\",\"register-require_postal_code\":\"1\",\"register-require_phone\":\"1\",\"register-require_website\":\"1\",\"register-require_favoritebook\":\"1\",\"register-require_aboutme\":\"1\",\"register-require_tos\":\"1\",\"register-require_dob\":\"1\",\"profile-require_address1\":\"1\",\"profile-require_address2\":\"1\",\"profile-require_city\":\"1\",\"profile-require_region\":\"1\",\"profile-require_country\":\"1\",\"profile-require_postal_code\":\"1\",\"profile-require_phone\":\"1\",\"profile-require_website\":\"1\",\"profile-require_favoritebook\":\"1\",\"profile-require_aboutme\":\"1\",\"profile-require_tos\":\"1\",\"profile-require_dob\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(434,'plg_extension_joomla','plugin','joomla','extension',0,1,1,1,'{\"name\":\"plg_extension_joomla\",\"type\":\"plugin\",\"creationDate\":\"May 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(435,'plg_content_joomla','plugin','joomla','content',0,1,1,0,'{\"name\":\"plg_content_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(436,'plg_system_languagecode','plugin','languagecode','system',0,0,1,0,'{\"name\":\"plg_system_languagecode\",\"type\":\"plugin\",\"creationDate\":\"November 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"languagecode\"}','{}','','',0,'0000-00-00 00:00:00',10,0),(437,'plg_quickicon_joomlaupdate','plugin','joomlaupdate','quickicon',0,1,1,1,'{\"name\":\"plg_quickicon_joomlaupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomlaupdate\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(438,'plg_quickicon_extensionupdate','plugin','extensionupdate','quickicon',0,1,1,1,'{\"name\":\"plg_quickicon_extensionupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"extensionupdate\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(439,'plg_captcha_recaptcha','plugin','recaptcha','captcha',0,1,1,0,'{\"name\":\"plg_captcha_recaptcha\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.4.0\",\"description\":\"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"recaptcha\"}','{\"public_key\":\"6LcCkOoSAAAAAO42pEiUqK_HzJbwR-OxfKcAVd2G\",\"private_key\":\"6LcCkOoSAAAAAAvriVi8FqhKmeb21J-cLcGmkfkF\",\"theme\":\"clean\"}','','',0,'0000-00-00 00:00:00',0,0),(440,'plg_system_highlight','plugin','highlight','system',0,1,1,0,'{\"name\":\"plg_system_highlight\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"highlight\"}','{}','','',0,'0000-00-00 00:00:00',7,0),(441,'plg_content_finder','plugin','finder','content',0,0,1,0,'{\"name\":\"plg_content_finder\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(442,'plg_finder_categories','plugin','categories','finder',0,1,1,0,'{\"name\":\"plg_finder_categories\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"categories\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(443,'plg_finder_contacts','plugin','contacts','finder',0,1,1,0,'{\"name\":\"plg_finder_contacts\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTACTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contacts\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(444,'plg_finder_content','plugin','content','finder',0,1,1,0,'{\"name\":\"plg_finder_content\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(445,'plg_finder_newsfeeds','plugin','newsfeeds','finder',0,1,1,0,'{\"name\":\"plg_finder_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}','{}','','',0,'0000-00-00 00:00:00',4,0),(447,'plg_finder_tags','plugin','tags','finder',0,1,1,0,'{\"name\":\"plg_finder_tags\",\"type\":\"plugin\",\"creationDate\":\"February 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(448,'plg_twofactorauth_totp','plugin','totp','twofactorauth',0,0,1,0,'{\"name\":\"plg_twofactorauth_totp\",\"type\":\"plugin\",\"creationDate\":\"August 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_TOTP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"totp\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(449,'plg_authentication_cookie','plugin','cookie','authentication',0,1,1,0,'{\"name\":\"plg_authentication_cookie\",\"type\":\"plugin\",\"creationDate\":\"July 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_COOKIE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"cookie\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(450,'plg_twofactorauth_yubikey','plugin','yubikey','twofactorauth',0,0,1,0,'{\"name\":\"plg_twofactorauth_yubikey\",\"type\":\"plugin\",\"creationDate\":\"September 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_YUBIKEY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"yubikey\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(451,'plg_search_tags','plugin','tags','search',0,0,1,0,'{\"name\":\"plg_search_tags\",\"type\":\"plugin\",\"creationDate\":\"March 2014\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}','{\"search_limit\":\"50\",\"show_tagged_items\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(452,'plg_system_updatenotification','plugin','updatenotification','system',0,1,1,0,'{\"name\":\"plg_system_updatenotification\",\"type\":\"plugin\",\"creationDate\":\"May 2015\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_SYSTEM_UPDATENOTIFICATION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"updatenotification\"}','{\"lastrun\":1491105694}','','',0,'0000-00-00 00:00:00',0,0),(453,'plg_editors-xtd_module','plugin','module','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_module\",\"type\":\"plugin\",\"creationDate\":\"October 2015\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_MODULE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"module\"}','','','',0,'0000-00-00 00:00:00',0,0),(454,'plg_system_stats','plugin','stats','system',0,1,1,0,'{\"name\":\"plg_system_stats\",\"type\":\"plugin\",\"creationDate\":\"November 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_SYSTEM_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"stats\"}','{\"mode\":1,\"lastrun\":1491105771,\"unique_id\":\"4782751523ea3cc3ac2ea2112faf2704ba2d2807\",\"interval\":12}','','',0,'0000-00-00 00:00:00',0,0),(455,'plg_installer_packageinstaller','plugin','packageinstaller','installer',0,1,1,1,'{\"name\":\"plg_installer_packageinstaller\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_PACKAGEINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"packageinstaller\"}','','','',0,'0000-00-00 00:00:00',1,0),(456,'PLG_INSTALLER_FOLDERINSTALLER','plugin','folderinstaller','installer',0,1,1,1,'{\"name\":\"PLG_INSTALLER_FOLDERINSTALLER\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_FOLDERINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"folderinstaller\"}','','','',0,'0000-00-00 00:00:00',2,0),(457,'PLG_INSTALLER_URLINSTALLER','plugin','urlinstaller','installer',0,1,1,1,'{\"name\":\"PLG_INSTALLER_URLINSTALLER\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_URLINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"urlinstaller\"}','','','',0,'0000-00-00 00:00:00',3,0),(503,'beez3','template','beez3','',0,1,1,0,'{\"name\":\"beez3\",\"type\":\"template\",\"creationDate\":\"25 November 2009\",\"author\":\"Angie Radtke\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"a.radtke@derauftritt.de\",\"authorUrl\":\"http:\\/\\/www.der-auftritt.de\",\"version\":\"3.1.0\",\"description\":\"TPL_BEEZ3_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}','{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"navposition\":\"center\",\"templatecolor\":\"nature\"}','','',0,'0000-00-00 00:00:00',0,0),(504,'hathor','template','hathor','',1,1,1,0,'{\"name\":\"hathor\",\"type\":\"template\",\"creationDate\":\"May 2010\",\"author\":\"Andrea Tarr\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"3.0.0\",\"description\":\"TPL_HATHOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}','{\"showSiteName\":\"0\",\"colourChoice\":\"0\",\"boldText\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(506,'protostar','template','protostar','',0,1,1,0,'{\"name\":\"protostar\",\"type\":\"template\",\"creationDate\":\"4\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_PROTOSTAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}','{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(507,'isis','template','isis','',1,1,1,0,'{\"name\":\"isis\",\"type\":\"template\",\"creationDate\":\"3\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_ISIS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}','{\"templateColor\":\"\",\"logoFile\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(600,'English (en-GB)','language','en-GB','',0,1,1,1,'{\"name\":\"English (en-GB)\",\"type\":\"language\",\"creationDate\":\"December 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.5\",\"description\":\"en-GB site language\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(601,'English (en-GB)','language','en-GB','',1,1,1,1,'{\"name\":\"English (en-GB)\",\"type\":\"language\",\"creationDate\":\"December 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.5\",\"description\":\"en-GB administrator language\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(700,'files_joomla','file','joomla','',0,1,1,1,'{\"name\":\"files_joomla\",\"type\":\"file\",\"creationDate\":\"December 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.5\",\"description\":\"FILES_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(802,'English (en-GB) Language Pack','package','pkg_en-GB','',0,1,1,1,'{\"name\":\"English (en-GB) Language Pack\",\"type\":\"package\",\"creationDate\":\"December 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.5.1\",\"description\":\"en-GB language pack\",\"group\":\"\",\"filename\":\"pkg_en-GB\"}','','','',0,'0000-00-00 00:00:00',0,0),(10001,'T3 Framework','plugin','t3','system',0,1,1,0,'{\"name\":\"T3 Framework\",\"type\":\"plugin\",\"creationDate\":\"March 01, 2017\",\"author\":\"JoomlArt.com\",\"copyright\":\"Copyright (C) 2005 - 2017 Open Source Matters. All rights reserved.\",\"authorEmail\":\"info@joomlart.com\",\"authorUrl\":\"http:\\/\\/www.t3-framework.org\",\"version\":\"2.6.3\",\"description\":\"\\n\\t\\n\\t<div align=\\\"center\\\">\\n\\t\\t<div class=\\\"alert alert-success\\\" style=\\\"background-color:#DFF0D8;border-color:#D6E9C6;color: #468847;padding: 1px 0;\\\">\\n\\t\\t\\t\\t<a href=\\\"http:\\/\\/t3-framework.org\\/\\\"><img src=\\\"http:\\/\\/joomlart.s3.amazonaws.com\\/images\\/jat3v3-documents\\/message-installation\\/logo.png\\\" alt=\\\"some_text\\\" width=\\\"300\\\" height=\\\"99\\\"><\\/a>\\n\\t\\t\\t\\t<h4><a href=\\\"http:\\/\\/t3-framework.org\\/\\\" title=\\\"\\\">Home<\\/a> | <a href=\\\"http:\\/\\/demo.t3-framework.org\\/\\\" title=\\\"\\\">Demo<\\/a> | <a href=\\\"http:\\/\\/t3-framework.org\\/documentation\\\" title=\\\"\\\">Document<\\/a> | <a href=\\\"https:\\/\\/github.com\\/t3framework\\/t3\\/blob\\/master\\/CHANGELOG.md\\\" title=\\\"\\\">Changelog<\\/a><\\/h4>\\n\\t\\t<p> <\\/p>\\n\\t\\t<p>Copyright 2004 - 2017 <a href=\'http:\\/\\/www.joomlart.com\\/\' title=\'Visit Joomlart.com!\'>JoomlArt.com<\\/a>.<\\/p>\\n\\t\\t<\\/div>\\n     <style>table.adminform{width: 100%;}<\\/style>\\n\\t <\\/div>\\n\\t\\t\\n\\t\",\"group\":\"\",\"filename\":\"t3\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10004,'purity_III','template','purity_iii','',0,1,1,0,'{\"name\":\"purity_III\",\"type\":\"template\",\"creationDate\":\"16 Feb 2017\",\"author\":\"JoomlArt.com\",\"copyright\":\"Copyright (C), J.O.O.M Solutions Co., Ltd. All Rights Reserved.\",\"authorEmail\":\"webmaster@joomlart.com\",\"authorUrl\":\"http:\\/\\/www.t3-framework.org\",\"version\":\"1.1.9\",\"description\":\"\\n\\t\\t\\n\\t\\t<div align=\\\"center\\\">\\n\\t\\t\\t<div class=\\\"alert alert-success\\\" style=\\\"background-color:#DFF0D8;border-color:#D6E9C6;color: #468847;padding: 1px 0;\\\">\\n\\t\\t\\t\\t<h2>Purity III Template references<\\/h2>\\n\\t\\t\\t\\t<h4><a href=\\\"http:\\/\\/joomla-templates.joomlart.com\\/purity_iii\\/\\\" title=\\\"Purity III Template demo\\\">Live Demo<\\/a> | <a href=\\\"http:\\/\\/www.joomlart.com\\/documentation\\/joomla-templates\\/purity-iii\\\" title=\\\"purity iii template documentation\\\">Documentation<\\/a> | <a href=\\\"http:\\/\\/www.joomlart.com\\/forums\\/forumdisplay.php?542-Purity-III\\\" title=\\\"purity iii forum\\\">Forum<\\/a> | <a href=\\\"http:\\/\\/www.joomlart.com\\/joomla\\/templates\\/purity-iii\\\" title=\\\"Purity III template more info\\\">More Info<\\/a><\\/h4>\\n\\t\\t\\t\\t<p> <\\/p>\\n\\t\\t\\t\\t<span style=\\\"color:#FF0000\\\">Note: Purity III requires T3 plugin to be installed and enabled.<\\/span>\\n\\t\\t\\t\\t<p> <\\/p>\\n\\t\\t\\t\\t<p>Copyright 2004 - 2017 <a href=\'http:\\/\\/www.joomlart.com\\/\' title=\'Visit Joomlart.com!\'>JoomlArt.com<\\/a>.<\\/p>\\n\\t\\t\\t<\\/div>\\n\\t\\t\\t<style>table.adminform{width: 100%;}<\\/style>\\n\\t\\t<\\/div>\\n\\t\\t\\n\\t\",\"group\":\"\",\"filename\":\"templateDetails\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10005,'plg_system_kunena','plugin','kunena','system',0,1,1,0,'{\"name\":\"plg_system_kunena\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_SYSTEM_KUNENA_DESC\",\"group\":\"\",\"filename\":\"kunena\"}','{\"jcontentevents\":\"0\",\"jcontentevent_target\":\"body\"}','','',0,'0000-00-00 00:00:00',0,0),(10006,'plg_quickicon_kunena','plugin','kunena','quickicon',0,1,1,0,'{\"name\":\"plg_quickicon_kunena\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_QUICKICON_KUNENA_DESC\",\"group\":\"\",\"filename\":\"kunena\"}','{\"context\":\"mod_quickicon\"}','','',0,'0000-00-00 00:00:00',0,0),(10009,'com_kunena','component','com_kunena','',1,1,0,0,'{\"name\":\"com_kunena\",\"type\":\"component\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2017 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"COM_KUNENA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"kunena\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10012,'plg_kunena_community','plugin','community','kunena',0,0,1,0,'{\"name\":\"plg_kunena_community\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_COMMUNITY_DESCRIPTION\",\"group\":\"\",\"filename\":\"community\"}','{\"access\":\"1\",\"login\":\"1\",\"activity\":\"1\",\"avatar\":\"1\",\"profile\":\"1\",\"private\":\"1\",\"activity_points_limit\":\"0\",\"activity_stream_limit\":\"0\"}','','',0,'0000-00-00 00:00:00',2,0),(10013,'plg_kunena_comprofiler','plugin','comprofiler','kunena',0,0,1,0,'{\"name\":\"plg_kunena_comprofiler\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_COMPROFILER_DESCRIPTION\",\"group\":\"\",\"filename\":\"comprofiler\"}','{\"access\":\"1\",\"login\":\"1\",\"activity\":\"1\",\"avatar\":\"1\",\"profile\":\"1\",\"private\":\"1\"}','','',0,'0000-00-00 00:00:00',3,0),(10014,'plg_kunena_gravatar','plugin','gravatar','kunena',0,0,1,0,'{\"name\":\"plg_kunena_gravatar\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_GRAVATAR_DESCRIPTION\",\"group\":\"\",\"filename\":\"gravatar\"}','{\"avatar\":\"1\"}','','',0,'0000-00-00 00:00:00',4,0),(10015,'plg_kunena_uddeim','plugin','uddeim','kunena',0,0,1,0,'{\"name\":\"plg_kunena_uddeim\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_UDDEIM_DESCRIPTION\",\"group\":\"\",\"filename\":\"uddeim\"}','{\"private\":\"1\"}','','',0,'0000-00-00 00:00:00',5,0),(10016,'plg_kunena_kunena','plugin','kunena','kunena',0,1,1,0,'{\"name\":\"plg_kunena_kunena\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_KUNENA_DESCRIPTION\",\"group\":\"\",\"filename\":\"kunena\"}','{\"avatar\":\"1\",\"profile\":\"1\"}','','',0,'0000-00-00 00:00:00',6,0),(10017,'plg_kunena_joomla','plugin','joomla','kunena',0,1,1,0,'{\"name\":\"plg_kunena_joomla\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_JOOMLA_25_30_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','{\"access\":\"1\",\"login\":\"1\"}','','',0,'0000-00-00 00:00:00',7,0),(10103,'com_jaextmanager','component','com_jaextmanager','',1,1,0,0,'{\"name\":\"com_jaextmanager\",\"type\":\"component\",\"creationDate\":\"Feb 2017\",\"author\":\"JoomlArt\",\"copyright\":\"Copyright (C), J.O.O.M Solutions Co., Ltd. All Rights Reserved.\",\"authorEmail\":\"webmaster@joomlart.com\",\"authorUrl\":\"http:\\/\\/www.joomlart.com\",\"version\":\"2.6.3\",\"description\":\"JA Extension Manager Component\",\"group\":\"\"}','{\"MYSQL_PATH\":\"\\/usr\\/bin\\/mysql\",\"MYSQLDUMP_PATH\":\"\\/usr\\/bin\\/mysqldump\",\"DATA_FOLDER\":\"jaextmanager_data\",\"HIDE_NONJA\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(10126,'Kunena Forum Package','package','pkg_kunena','',0,1,1,0,'{\"name\":\"Kunena Forum Package\",\"type\":\"package\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2017 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"Kunena Forum Package.\",\"group\":\"\",\"filename\":\"pkg_kunena\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10276,'LIB_PHPASS','library','phpass','',0,1,1,0,'{\"name\":\"LIB_PHPASS\",\"type\":\"library\",\"creationDate\":\"2004-2006\",\"author\":\"Solar Designer\",\"copyright\":\"\",\"authorEmail\":\"solar@openwall.com\",\"authorUrl\":\"http:\\/\\/www.openwall.com\\/phpass\\/\",\"version\":\"0.3\",\"description\":\"LIB_PHPASS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phpass\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10296,'mod_tags_similar','module','mod_tags_similar','',0,1,1,0,'{\"name\":\"mod_tags_similar\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_SIMILAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_tags_similar\"}','{}','','',0,'0000-00-00 00:00:00',0,-1),(10297,'plg_content_contact','plugin','contact','content',0,1,1,0,'{\"name\":\"plg_content_contact\",\"type\":\"plugin\",\"creationDate\":\"January 2014\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.2\",\"description\":\"PLG_CONTENT_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}','{}','','',0,'0000-00-00 00:00:00',0,-1),(10298,'plg_kunena_alphauserpoints','plugin','alphauserpoints','kunena',0,1,1,0,'{\"name\":\"plg_kunena_alphauserpoints\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_ALPHAUSERPOINTS_DESCRIPTION\",\"group\":\"\",\"filename\":\"alphauserpoints\"}','{}','','',0,'0000-00-00 00:00:00',1,-1),(10299,'plg_kunena_altauserpoints','plugin','altauserpoints','kunena',0,1,1,0,'{\"name\":\"plg_kunena_altauserpoints\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"www.kunena.org\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_ALTAUSERPOINTS_DESCRIPTION\",\"group\":\"\",\"filename\":\"altauserpoints\"}','{}','','',0,'0000-00-00 00:00:00',2,-1),(10300,'PLG_KUNENA_EASYPROFILE','plugin','easyprofile','kunena',0,1,1,0,'{\"name\":\"PLG_KUNENA_EASYPROFILE\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Onlinecommunityhub\",\"copyright\":\"https:\\/\\/onlinecommunityhub.nl\",\"authorEmail\":\"info@onlinecommunityhub.nl\",\"authorUrl\":\"https:\\/\\/onlinecommunityhub.nl\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_EASYPROFILE_DESCRIPTION\",\"group\":\"\",\"filename\":\"easyprofile\"}','{}','','',0,'0000-00-00 00:00:00',5,-1),(10301,'plg_kunena_easysocial','plugin','easysocial','kunena',0,1,1,0,'{\"name\":\"plg_kunena_easysocial\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"StackIdeas\",\"copyright\":\"https:\\/\\/stackideas.com\",\"authorEmail\":\"support@stackideas.com\",\"authorUrl\":\"https:\\/\\/stackideas.com\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_EASYSOCIAL_DESCRIPTION\",\"group\":\"\",\"filename\":\"easysocial\"}','{}','','',0,'0000-00-00 00:00:00',6,-1),(10302,'Kunena Framework','library','kunena','',0,1,1,0,'{\"name\":\"Kunena Framework\",\"type\":\"library\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2017 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"Kunena Framework.\",\"group\":\"\",\"filename\":\"kunena\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10303,'Kunena Media Files','file','kunena_media','',0,1,0,0,'{\"name\":\"Kunena Media Files\",\"type\":\"file\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2017 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"Kunena media files.\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10304,'plg_finder_kunena','plugin','kunena','finder',0,0,1,0,'{\"name\":\"plg_finder_kunena\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2017 Kunena Team. All rights reserved.\",\"authorEmail\":\"Kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_FINDER_KUNENA_DESCRIPTION\",\"group\":\"\",\"filename\":\"kunena\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(10305,'plg_kunena_finder','plugin','finder','kunena',0,0,1,0,'{\"name\":\"plg_kunena_finder\",\"type\":\"plugin\",\"creationDate\":\"2017-03-31\",\"author\":\"Kunena Team\",\"copyright\":\"(C) 2008 - 2017 Kunena Team. All rights reserved.\",\"authorEmail\":\"kunena@kunena.org\",\"authorUrl\":\"https:\\/\\/www.kunena.org\",\"version\":\"5.0.7\",\"description\":\"PLG_KUNENA_FINDER_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}','{}','','',0,'0000-00-00 00:00:00',11,0),(10306,'ChineseSimplified','language','zh-CN','',0,1,0,0,'{\"name\":\"Chinese Simplified\",\"type\":\"language\",\"creationDate\":\"2015-03-03\",\"author\":\"CHN Translation Team: joomla.cn\",\"copyright\":\"Copyright (C) 2005 - 2015 \\u7b80\\u4f53\\u4e2d\\u6587\\u7ffb\\u8bd1\\u7ec4\\uff08joomla.cn\\uff09\\u53caOpen Source Matters\\uff0c\\u7248\\u6743\\u6240\\u6709\\u3002\",\"authorEmail\":\"zhous1998@sohu.com\",\"authorUrl\":\"www.joomla.cn\",\"version\":\"3.4.1.2\",\"description\":\"\\n    \\n<div align=\\\"center\\\">\\n <table border=\\\"0\\\" width=\\\"90%\\\">\\n  <table width=\\\"100%\\\" border=\\\"0\\\">\\n  <tr>\\n    <td colspan=\\\"2\\\">Chinese language for Joomla 3.x front-end. Translated by CHN Joomla Translation Team, one of Joomla Accredited Translations.<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">Joomla 3.4\\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u662f\\u7531Joomla\\u5b98\\u65b9\\u7ffb\\u8bd1\\u7ec4\\u7684Derek Joe\\u5728Joomla 2.5\\u7ffb\\u8bd1\\u5de5\\u4f5c\\u7684\\u57fa\\u7840\\u4e0a\\u8865\\u5145\\u7ffb\\u8bd1\\u3002<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">Joomla\\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u5305\\u7684\\u4e3b\\u8981\\u8d21\\u732e\\u4eba\\uff1a<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u524d\\u53f0\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/wuyujie\\/\\\" target=\\\"_blank\\\">\\u6b66\\u7389\\u6770<\\/a>(wuyujie)\\u3001 <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/gzpan123\\/\\\" target=\\\"_blank\\\">\\u90ed\\u5fd7\\u6500<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u540e\\u53f0\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/keydiagram\\/\\\" target=\\\"_blank\\\">Key Diagram<\\/a>\\u3001<a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/tchyusuf\\/\\\">Yusuf  Wang<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u5b89\\u88c5\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/freechoice\\/\\\" target=\\\"_blank\\\">Johnathan Cheun<\\/a>\\u3001<a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/tchyusuf\\/\\\">Yusuf  Wang<\\/a>\\u3001 <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/zhous\\/\\\" target=\\\"_blank\\\">Derek Joe<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u793a\\u8303\\u5185\\u5bb9\\u53ca\\u7f16\\u8f91\\u5668\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/zhous\\/\\\" target=\\\"_blank\\\">Derek Joe<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u591a\\u8c22\\u5927\\u5bb6\\u7684\\u5949\\u732e\\u7cbe\\u795e\\u548c\\u8f9b\\u52e4\\u52b3\\u52a8\\uff01<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td width=\\\"132\\\"><p><a href=\\\"http:\\/\\/www.joomla.cn\\\" target=\\\"_blank\\\"><img src=\\\"http:\\/\\/www.joomla.cn\\/images\\/aboutJoomlaChina.png\\\" alt=\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\\" width=\\\"130\\\" height=\\\"70\\\" align=\\\"left\\\" longdesc=\\\"http:\\/\\/www.joomla.cn\\\"><br \\/>\\n    <\\/a><\\/p><\\/td>\\n    <td valign=\\\"middle\\\"><a href=\\\"http:\\/\\/www.joomla.cn\\\" target=\\\"_blank\\\">Joomla\\u53ca\\u5176\\u6269\\u5c55\\u6c49\\u5316\\u7684\\u5206\\u4eab\\u4e0e\\u8ba8\\u8bba\\u8bf7\\u8bbf\\u95ee\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\\"<\\/a><br \\/>\\n      <b>\\u6b22\\u8fce\\u559c\\u6b22\\u7ffb\\u8bd1\\u7684\\u670b\\u53cb<\\/b><br \\/>\\n    <a href=\\\"http:\\/\\/www.joomla.cn\\\" target=\\\"_blank\\\"><b>\\u52a0\\u5165\\u6211\\u4eec\\u7684\\u7ffb\\u8bd1\\u7ec4<\\/b><\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">&nbsp;<\\/td>\\n  <\\/tr>\\n<\\/table>\\n <\\/div>\\n  \\n\\t\",\"group\":\"\",\"filename\":\"install\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10307,'ChineseSimplified','language','zh-CN','',1,1,0,0,'{\"name\":\"Chinese Simplified\",\"type\":\"language\",\"creationDate\":\"2015-3-14\",\"author\":\"CHN Translation Team: joomla.cn\",\"copyright\":\"Copyright (C) 2005 - 2014 \\u7b80\\u4f53\\u4e2d\\u6587\\u7ffb\\u8bd1\\u7ec4\\uff08joomla.cn\\uff09\\u53caOpen Source Matters\\uff0c\\u7248\\u6743\\u6240\\u6709\\u3002\",\"authorEmail\":\"zhous1998@sohu.com\",\"authorUrl\":\"www.joomla.cn\",\"version\":\"3.4.1.2\",\"description\":\"\\n    \\n<div align=\\\"center\\\">\\n <table border=\\\"0\\\" width=\\\"90%\\\">\\n  <table width=\\\"100%\\\" border=\\\"0\\\">\\n  <tr>\\n    <td colspan=\\\"2\\\">Chinese language for Joomla 3.x front-end. Translated by CHN Joomla Translation Team, one of Joomla Accredited Translations.<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">Joomla 3.4\\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u662f\\u7531Joomla\\u5b98\\u65b9\\u7ffb\\u8bd1\\u7ec4\\u7684Derek Joe\\u5728Joomla 2.5\\u7ffb\\u8bd1\\u5de5\\u4f5c\\u7684\\u57fa\\u7840\\u4e0a\\u8865\\u5145\\u7ffb\\u8bd1\\u3002<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">Joomla\\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u5305\\u7684\\u4e3b\\u8981\\u8d21\\u732e\\u4eba\\uff1a<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u524d\\u53f0\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/wuyujie\\/\\\" target=\\\"_blank\\\">\\u6b66\\u7389\\u6770<\\/a>(wuyujie)\\u3001 <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/gzpan123\\/\\\" target=\\\"_blank\\\">\\u90ed\\u5fd7\\u6500<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u540e\\u53f0\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/keydiagram\\/\\\" target=\\\"_blank\\\">Key Diagram<\\/a>\\u3001<a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/tchyusuf\\/\\\">Yusuf  Wang<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u5b89\\u88c5\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/freechoice\\/\\\" target=\\\"_blank\\\">Johnathan Cheun<\\/a>\\u3001<a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/tchyusuf\\/\\\">Yusuf  Wang<\\/a>\\u3001 <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/zhous\\/\\\" target=\\\"_blank\\\">Derek Joe<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u793a\\u8303\\u5185\\u5bb9\\u53ca\\u7f16\\u8f91\\u5668\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/zhous\\/\\\" target=\\\"_blank\\\">Derek Joe<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u591a\\u8c22\\u5927\\u5bb6\\u7684\\u5949\\u732e\\u7cbe\\u795e\\u548c\\u8f9b\\u52e4\\u52b3\\u52a8\\uff01<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td width=\\\"132\\\"><p><a href=\\\"http:\\/\\/www.joomla.cn\\\" target=\\\"_blank\\\"><img src=\\\"http:\\/\\/www.joomla.cn\\/images\\/aboutJoomlaChina.png\\\" alt=\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\\" width=\\\"130\\\" height=\\\"70\\\" align=\\\"left\\\" longdesc=\\\"http:\\/\\/www.joomla.cn\\\"><br \\/>\\n    <\\/a><\\/p><\\/td>\\n    <td valign=\\\"middle\\\"><a href=\\\"http:\\/\\/www.joomla.cn\\\" target=\\\"_blank\\\">Joomla\\u53ca\\u5176\\u6269\\u5c55\\u6c49\\u5316\\u7684\\u5206\\u4eab\\u4e0e\\u8ba8\\u8bba\\u8bf7\\u8bbf\\u95ee\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\\"<\\/a><br \\/>\\n      <b>\\u6b22\\u8fce\\u559c\\u6b22\\u7ffb\\u8bd1\\u7684\\u670b\\u53cb<\\/b><br \\/>\\n    <a href=\\\"http:\\/\\/www.joomla.cn\\\" target=\\\"_blank\\\"><b>\\u52a0\\u5165\\u6211\\u4eec\\u7684\\u7ffb\\u8bd1\\u7ec4<\\/b><\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">&nbsp;<\\/td>\\n  <\\/tr>\\n<\\/table>\\n <\\/div>\\n  \\n\\t\",\"group\":\"\",\"filename\":\"install\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10308,'简体中文语言包','package','pkg_zh-CN','',0,1,1,0,'{\"name\":\"\\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u5305\",\"type\":\"package\",\"creationDate\":\"2015-03-03\",\"author\":\"CHN Translation Team: joomla.cn\",\"copyright\":\"Copyright (C) 2005 - 2015 \\u56e7\\u5566\\u4e2d\\u56fd\\uff08joomla.cn\\uff09\\u53caOpen Source Matters\\uff0c\\u7248\\u6743\\u6240\\u6709\\u3002\",\"authorEmail\":\"zhous1998@sohu.com\",\"authorUrl\":\"www.joomla.cn\",\"version\":\"3.4.1.2\",\"description\":\"\\n\\t\\n\\t<h3>Joomla! 3.4.1\\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u5305\\u7b2c\\u4e00\\u7248<\\/h3>\\n    <h3>Joomla! 3.4.1 Full Simplified Chinese (zh-CN) Language Package version 2<\\/h3>\\n\\t<div>\\n\\t<a href=\\\"http:\\/\\/www.joomla.cn\\\" target=\\\"_blank\\\"><img src=\\\"http:\\/\\/www.joomla.cn\\/images\\/joomla.cn_logo.png\\\" alt=\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\uff08Joomla.cn\\uff09\\\" title=\\\"\\u7ffb\\u8bd1\\u57fa\\u5730\\uff1a\\u56e7\\u5566!\\u4e2d\\u56fd\\uff08Joomla.cn\\uff09\\\" \\/><\\/a>\\u3002<br><br>\\u6b22\\u8fce\\u52a0\\u5165\\u201cJoomla\\u4f7f\\u7528\\u4ea4\\u6d41\\u201dQ\\u7fa4\\uff1a154673214\\u300172746093\\u3002<br><br>\\n\\tJoomla\\u5b98\\u65b9\\u7ffb\\u8bd1\\u7ec4\\u5468\\u671d\\u6656\\uff08Derek Zhou\\uff09\\u7ec4\\u7ec7\\u7ffb\\u8bd1\\u3002<br><br>\\u611f\\u8c22Joomla\\u7b80\\u4f53\\u4e2d\\u6587\\u7ffb\\u8bd1\\u7ec4\\u7684\\u6240\\u6709\\u5fd7\\u613f\\u8005\\uff1a<br>\\u6b66\\u7389\\u6770\\u3001Key Diagram\\u3001Yusuf  Wang\\u3001\\u90ed\\u5fd7\\u6500\\u3001Eric Wong\\uff08http:\\/\\/berocks2.com\\/\\uff09\\u3001wayne82\\uff01<br>\\u6b22\\u8fce\\u559c\\u6b22\\u7ffb\\u8bd1\\u7684\\u670b\\u53cb\\u52a0\\u5165\\u6211\\u4eec\\u3002<br><br>\\n\\t <br>\\n\\t<\\/div>\\n\\t\\n\\t\",\"group\":\"\",\"filename\":\"pkg_zh-CN\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10309,'plg_installer_webinstaller','plugin','webinstaller','installer',0,1,1,0,'{\"name\":\"plg_installer_webinstaller\",\"type\":\"plugin\",\"creationDate\":\"17 February 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2013-2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"1.1.0\",\"description\":\"PLG_INSTALLER_WEBINSTALLER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"webinstaller\"}','{\"tab_position\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(10310,'COM_JCE','component','com_jce','',1,1,0,0,'{\"name\":\"COM_JCE\",\"type\":\"component\",\"creationDate\":\"09-03-2017\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2017 Ryan Demmer. All rights reserved\",\"authorEmail\":\"@@e-mail@@\",\"authorUrl\":\"www.joomlacontenteditor.net\",\"version\":\"2.6.9\",\"description\":\"COM_JCE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10311,'plg_editors_jce','plugin','jce','editors',0,1,1,0,'{\"name\":\"plg_editors_jce\",\"type\":\"plugin\",\"creationDate\":\"09-03-2017\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2017 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.6.9\",\"description\":\"WF_EDITOR_PLUGIN_DESC\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10312,'plg_content_jce','plugin','jce','content',0,1,1,0,'{\"name\":\"plg_content_jce\",\"type\":\"plugin\",\"creationDate\":\"09-03-2017\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2017 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.6.9\",\"description\":\"PLG_CONTENT_JCE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10313,'plg_extension_jce','plugin','jce','extension',0,1,1,0,'{\"name\":\"plg_extension_jce\",\"type\":\"plugin\",\"creationDate\":\"09-03-2017\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2017 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.6.9\",\"description\":\"PLG_EXTENSION_JCE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10314,'plg_installer_jce','plugin','jce','installer',0,1,1,0,'{\"name\":\"plg_installer_jce\",\"type\":\"plugin\",\"creationDate\":\"09-03-2017\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2017 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.6.9\",\"description\":\"PLG_INSTALLER_JCE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10315,'plg_quickicon_jce','plugin','jce','quickicon',0,1,1,0,'{\"name\":\"plg_quickicon_jce\",\"type\":\"plugin\",\"creationDate\":\"31-08-2016\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2016 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"www.joomalcontenteditor.net\",\"version\":\"2.6.0-pro-beta3\",\"description\":\"PLG_QUICKICON_JCE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10316,'plg_system_jce','plugin','jce','system',0,1,1,0,'{\"name\":\"plg_system_jce\",\"type\":\"plugin\",\"creationDate\":\"09-03-2017\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2017 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.6.9\",\"description\":\"PLG_SYSTEM_JCE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10317,'PKG_JCE','package','pkg_jce','',0,1,1,0,'{\"name\":\"PKG_JCE\",\"type\":\"package\",\"creationDate\":\"09-03-2017\",\"author\":\"Ryan Demmer\",\"copyright\":\"\",\"authorEmail\":\"\",\"authorUrl\":\"\",\"version\":\"2.6.9\",\"description\":\"PKG_JCE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pkg_jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10318,'FOF30','library','lib_fof30','',0,1,1,0,'{\"name\":\"FOF30\",\"type\":\"library\",\"creationDate\":\"2017-02-21\",\"author\":\"Nicholas K. Dionysopoulos \\/ Akeeba Ltd\",\"copyright\":\"(C)2010-2017 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@akeebabackup.com\",\"authorUrl\":\"https:\\/\\/www.akeebabackup.com\",\"version\":\"3.0.18\",\"description\":\"\\n\\t\\t\\n\\t\\tFramework-on-Framework (FOF) 3.x - The rapid application development framework for Joomla!.<br\\/>\\n\\t\\t<b>WARNING<\\/b>: This is NOT a duplicate of the FOF library already installed with Joomla!. It is a different version used by other extensions on your site. Do NOT uninstall either FOF package. If you do you will break your site.\\n\\t\\t\\n\\t\",\"group\":\"\",\"filename\":\"lib_fof30\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10319,'Akeeba','component','com_akeeba','',1,1,0,0,'{\"name\":\"Akeeba\",\"type\":\"component\",\"creationDate\":\"2017-03-16\",\"author\":\"Nicholas K. Dionysopoulos\",\"copyright\":\"Copyright (c)2006-2017 Akeeba Ltd \\/ Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@dionysopoulos.me\",\"authorUrl\":\"http:\\/\\/www.akeebabackup.com\",\"version\":\"5.3.1\",\"description\":\"Akeeba Backup Core - Full Joomla! site backup solution, Core Edition.\",\"group\":\"\",\"filename\":\"akeeba\"}','{\"confwiz_upgrade\":1,\"updatedb\":null,\"siteurl\":\"http:\\/\\/localhost\\/knss\\/\",\"jlibrariesdir\":\"\\/Applications\\/XAMPP\\/xamppfiles\\/htdocs\\/knss\\/libraries\",\"jversion\":\"1.6\"}','','',0,'0000-00-00 00:00:00',0,0),(10320,'plg_quickicon_akeebabackup','plugin','akeebabackup','quickicon',0,1,1,0,'{\"name\":\"plg_quickicon_akeebabackup\",\"type\":\"plugin\",\"creationDate\":\"2012-09-26\",\"author\":\"Nicholas K. Dionysopoulos\",\"copyright\":\"Copyright (c)2006-2017 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@akeebabackup.com\",\"authorUrl\":\"http:\\/\\/www.akeebabackup.com\",\"version\":\"1.0\",\"description\":\"PLG_QUICKICON_AKEEBABACKUP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"akeebabackup\"}','{\"context\":\"mod_quickicon\",\"enablewarning\":\"1\",\"warnfailed\":\"1\",\"maxbackupperiod\":\"24\",\"profileid\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(10321,'PLG_SYSTEM_AKEEBAUPDATECHECK_TITLE','plugin','akeebaupdatecheck','system',0,0,1,0,'{\"name\":\"PLG_SYSTEM_AKEEBAUPDATECHECK_TITLE\",\"type\":\"plugin\",\"creationDate\":\"2011-05-26\",\"author\":\"Nicholas K. Dionysopoulos\",\"copyright\":\"Copyright (c)2006-2017 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@dionysopoulos.me\",\"authorUrl\":\"http:\\/\\/www.akeebabackup.com\",\"version\":\"1.1\",\"description\":\"PLG_AKEEBAUPDATECHECK_DESCRIPTION2\",\"group\":\"\",\"filename\":\"akeebaupdatecheck\"}','{\"email\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10322,'PLG_SYSTEM_BACKUPONUPDATE_TITLE','plugin','backuponupdate','system',0,0,1,0,'{\"name\":\"PLG_SYSTEM_BACKUPONUPDATE_TITLE\",\"type\":\"plugin\",\"creationDate\":\"2013-08-13\",\"author\":\"Nicholas K. Dionysopoulos\",\"copyright\":\"Copyright (c)2006-2017 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@dionysopoulos.me\",\"authorUrl\":\"http:\\/\\/www.akeebabackup.com\",\"version\":\"3.7\",\"description\":\"PLG_SYSTEM_BACKUPONUPDATE_DESCRIPTION\",\"group\":\"\",\"filename\":\"backuponupdate\"}','{\"profileid\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(10323,'Akeeba Backup package','package','pkg_akeeba','',0,1,1,0,'{\"name\":\"Akeeba Backup package\",\"type\":\"package\",\"creationDate\":\"2017-03-16\",\"author\":\"Nicholas K. Dionysopoulos\",\"copyright\":\"Copyright (c)2006-2017 Akeeba Ltd \\/ Nicholas K. Dionysopoulos\",\"authorEmail\":\"\",\"authorUrl\":\"\",\"version\":\"5.3.1\",\"description\":\"Akeeba Backup installation package v.5.3.1\",\"group\":\"\",\"filename\":\"pkg_akeeba\"}','{}','','',0,'0000-00-00 00:00:00',0,0);
/*!40000 ALTER TABLE `pro_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_filters`
--

DROP TABLE IF EXISTS `pro_finder_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` longtext NOT NULL,
  `params` longtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_filters`
--

LOCK TABLES `pro_finder_filters` WRITE;
/*!40000 ALTER TABLE `pro_finder_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links`
--

DROP TABLE IF EXISTS `pro_finder_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(400) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`),
  KEY `idx_title` (`title`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links`
--

LOCK TABLES `pro_finder_links` WRITE;
/*!40000 ALTER TABLE `pro_finder_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms0`
--

DROP TABLE IF EXISTS `pro_finder_links_terms0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms0`
--

LOCK TABLES `pro_finder_links_terms0` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms0` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms1`
--

DROP TABLE IF EXISTS `pro_finder_links_terms1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms1`
--

LOCK TABLES `pro_finder_links_terms1` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms1` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms2`
--

DROP TABLE IF EXISTS `pro_finder_links_terms2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms2`
--

LOCK TABLES `pro_finder_links_terms2` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms2` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms3`
--

DROP TABLE IF EXISTS `pro_finder_links_terms3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms3`
--

LOCK TABLES `pro_finder_links_terms3` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms3` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms4`
--

DROP TABLE IF EXISTS `pro_finder_links_terms4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms4`
--

LOCK TABLES `pro_finder_links_terms4` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms4` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms5`
--

DROP TABLE IF EXISTS `pro_finder_links_terms5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms5`
--

LOCK TABLES `pro_finder_links_terms5` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms5` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms6`
--

DROP TABLE IF EXISTS `pro_finder_links_terms6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms6`
--

LOCK TABLES `pro_finder_links_terms6` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms6` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms7`
--

DROP TABLE IF EXISTS `pro_finder_links_terms7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms7`
--

LOCK TABLES `pro_finder_links_terms7` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms7` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms8`
--

DROP TABLE IF EXISTS `pro_finder_links_terms8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms8`
--

LOCK TABLES `pro_finder_links_terms8` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms8` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_terms9`
--

DROP TABLE IF EXISTS `pro_finder_links_terms9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_terms9`
--

LOCK TABLES `pro_finder_links_terms9` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_terms9` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_terms9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_termsa`
--

DROP TABLE IF EXISTS `pro_finder_links_termsa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_termsa`
--

LOCK TABLES `pro_finder_links_termsa` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_termsa` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_termsa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_termsb`
--

DROP TABLE IF EXISTS `pro_finder_links_termsb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_termsb`
--

LOCK TABLES `pro_finder_links_termsb` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_termsb` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_termsb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_termsc`
--

DROP TABLE IF EXISTS `pro_finder_links_termsc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_termsc`
--

LOCK TABLES `pro_finder_links_termsc` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_termsc` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_termsc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_termsd`
--

DROP TABLE IF EXISTS `pro_finder_links_termsd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_termsd`
--

LOCK TABLES `pro_finder_links_termsd` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_termsd` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_termsd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_termse`
--

DROP TABLE IF EXISTS `pro_finder_links_termse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_termse`
--

LOCK TABLES `pro_finder_links_termse` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_termse` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_termse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_links_termsf`
--

DROP TABLE IF EXISTS `pro_finder_links_termsf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_links_termsf`
--

LOCK TABLES `pro_finder_links_termsf` WRITE;
/*!40000 ALTER TABLE `pro_finder_links_termsf` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_links_termsf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_taxonomy`
--

DROP TABLE IF EXISTS `pro_finder_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_taxonomy`
--

LOCK TABLES `pro_finder_taxonomy` WRITE;
/*!40000 ALTER TABLE `pro_finder_taxonomy` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_taxonomy_map`
--

DROP TABLE IF EXISTS `pro_finder_taxonomy_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_taxonomy_map`
--

LOCK TABLES `pro_finder_taxonomy_map` WRITE;
/*!40000 ALTER TABLE `pro_finder_taxonomy_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_taxonomy_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_terms`
--

DROP TABLE IF EXISTS `pro_finder_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_terms`
--

LOCK TABLES `pro_finder_terms` WRITE;
/*!40000 ALTER TABLE `pro_finder_terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_terms_common`
--

DROP TABLE IF EXISTS `pro_finder_terms_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_terms_common`
--

LOCK TABLES `pro_finder_terms_common` WRITE;
/*!40000 ALTER TABLE `pro_finder_terms_common` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_terms_common` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_tokens`
--

DROP TABLE IF EXISTS `pro_finder_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT '',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_tokens`
--

LOCK TABLES `pro_finder_tokens` WRITE;
/*!40000 ALTER TABLE `pro_finder_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_tokens_aggregate`
--

DROP TABLE IF EXISTS `pro_finder_tokens_aggregate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  `language` char(3) NOT NULL DEFAULT '',
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_tokens_aggregate`
--

LOCK TABLES `pro_finder_tokens_aggregate` WRITE;
/*!40000 ALTER TABLE `pro_finder_tokens_aggregate` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_tokens_aggregate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_finder_types`
--

DROP TABLE IF EXISTS `pro_finder_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_finder_types`
--

LOCK TABLES `pro_finder_types` WRITE;
/*!40000 ALTER TABLE `pro_finder_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_finder_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_jaem_log`
--

DROP TABLE IF EXISTS `pro_jaem_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_jaem_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ext_id` varchar(50) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `check_date` datetime DEFAULT NULL,
  `check_info` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ext_id` (`ext_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_jaem_log`
--

LOCK TABLES `pro_jaem_log` WRITE;
/*!40000 ALTER TABLE `pro_jaem_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_jaem_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_jaem_services`
--

DROP TABLE IF EXISTS `pro_jaem_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_jaem_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ws_name` varchar(255) NOT NULL,
  `ws_mode` varchar(50) NOT NULL DEFAULT 'local',
  `ws_uri` varchar(255) NOT NULL,
  `ws_user` varchar(100) NOT NULL,
  `ws_pass` varchar(100) NOT NULL,
  `ws_default` tinyint(1) NOT NULL DEFAULT '0',
  `ws_core` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_jaem_services`
--

LOCK TABLES `pro_jaem_services` WRITE;
/*!40000 ALTER TABLE `pro_jaem_services` DISABLE KEYS */;
INSERT INTO `pro_jaem_services` VALUES (1,'Local Service','local','','','',0,1),(2,'JoomlArt Updates','remote','http://update.joomlart.com/service/','','',1,1);
/*!40000 ALTER TABLE `pro_jaem_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_address`
--

DROP TABLE IF EXISTS `pro_joomprofile_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_address` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `line` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `md5` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`address_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_field_id` (`field_id`),
  KEY `idx_latitude` (`latitude`),
  KEY `idx_longitude` (`longitude`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_address`
--

LOCK TABLES `pro_joomprofile_address` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_config`
--

DROP TABLE IF EXISTS `pro_joomprofile_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_config` (
  `id` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_config`
--

LOCK TABLES `pro_joomprofile_config` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_field`
--

DROP TABLE IF EXISTS `pro_joomprofile_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `tooltip` varchar(255) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `css_class` varchar(255) DEFAULT NULL,
  `params` text,
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_published` (`published`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_field`
--

LOCK TABLES `pro_joomprofile_field` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_field_fieldgroups`
--

DROP TABLE IF EXISTS `pro_joomprofile_field_fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_field_fieldgroups` (
  `field_fieldgroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `fieldgroup_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `editable` tinyint(1) NOT NULL DEFAULT '1',
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `registration` tinyint(1) NOT NULL DEFAULT '1',
  `params` text,
  PRIMARY KEY (`field_fieldgroup_id`),
  KEY `idx_field_id` (`field_id`),
  KEY `idx_fieldgroup_id` (`fieldgroup_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_field_fieldgroups`
--

LOCK TABLES `pro_joomprofile_field_fieldgroups` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_field_fieldgroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_field_fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_field_values`
--

DROP TABLE IF EXISTS `pro_joomprofile_field_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_field_values` (
  `field_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `privacy` tinyint(4) NOT NULL DEFAULT '0',
  KEY `idx_field_id` (`field_id`),
  KEY `idx_user_id` (`user_id`),
  FULLTEXT KEY `fullx_value` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_field_values`
--

LOCK TABLES `pro_joomprofile_field_values` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_field_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_field_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_fieldgroup`
--

DROP TABLE IF EXISTS `pro_joomprofile_fieldgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_fieldgroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `params` text,
  `registration` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_published` (`published`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_fieldgroup`
--

LOCK TABLES `pro_joomprofile_fieldgroup` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_fieldgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_fieldgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_fieldgroup_usergroups`
--

DROP TABLE IF EXISTS `pro_joomprofile_fieldgroup_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_fieldgroup_usergroups` (
  `fieldgroup_id` int(11) NOT NULL,
  `usergroup_id` int(11) NOT NULL,
  KEY `idx_fieldgroup_id` (`fieldgroup_id`),
  KEY `idx_usergroup_id` (`usergroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_fieldgroup_usergroups`
--

LOCK TABLES `pro_joomprofile_fieldgroup_usergroups` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_fieldgroup_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_fieldgroup_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_fieldoption`
--

DROP TABLE IF EXISTS `pro_joomprofile_fieldoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_fieldoption` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_field_id` (`field_id`),
  FULLTEXT KEY `fullx_title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_fieldoption`
--

LOCK TABLES `pro_joomprofile_fieldoption` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_fieldoption` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_fieldoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_registration`
--

DROP TABLE IF EXISTS `pro_joomprofile_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_registration` (
  `id` varchar(255) NOT NULL,
  `usergroups` varchar(255) NOT NULL,
  `values` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_registration`
--

LOCK TABLES `pro_joomprofile_registration` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_registration` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_usergroup`
--

DROP TABLE IF EXISTS `pro_joomprofile_usergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_usergroup` (
  `usergroup_id` int(11) NOT NULL,
  `params` text,
  PRIMARY KEY (`usergroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_usergroup`
--

LOCK TABLES `pro_joomprofile_usergroup` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_usergroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_usergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_joomprofile_usergroup_searchfields`
--

DROP TABLE IF EXISTS `pro_joomprofile_usergroup_searchfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_joomprofile_usergroup_searchfields` (
  `usergroup_searchfield_id` int(11) NOT NULL AUTO_INCREMENT,
  `usergroup_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`usergroup_searchfield_id`),
  KEY `idx_usergroup_id` (`usergroup_id`),
  KEY `idx_field_id` (`field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_joomprofile_usergroup_searchfields`
--

LOCK TABLES `pro_joomprofile_usergroup_searchfields` WRITE;
/*!40000 ALTER TABLE `pro_joomprofile_usergroup_searchfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_joomprofile_usergroup_searchfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_aliases`
--

DROP TABLE IF EXISTS `pro_kunena_aliases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_aliases` (
  `alias` varchar(190) NOT NULL,
  `type` varchar(10) NOT NULL,
  `item` varchar(32) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `alias` (`alias`),
  KEY `state` (`state`),
  KEY `item` (`item`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_aliases`
--

LOCK TABLES `pro_kunena_aliases` WRITE;
/*!40000 ALTER TABLE `pro_kunena_aliases` DISABLE KEYS */;
INSERT INTO `pro_kunena_aliases` VALUES ('announcement','view','announcement',1),('category','view','category',1),('category/create','layout','category.create',1),('category/default','layout','category.default',1),('category/edit','layout','category.edit',1),('category/manage','layout','category.manage',1),('category/moderate','layout','category.moderate',1),('category/user','layout','category.user',1),('common','view','common',1),('create','layout','category.create',0),('credits','view','credits',1),('default','layout','category.default',0),('edit','layout','category.edit',0),('home','view','home',1),('main-forum','catid','1',1),('manage','layout','category.manage',0),('misc','view','misc',1),('moderate','layout','category.moderate',0),('search','view','search',1),('statistics','view','statistics',1),('suggestion-box','catid','3',1),('topic','view','topic',1),('topics','view','topics',1),('user','view','user',1),('welcome-mat','catid','2',1);
/*!40000 ALTER TABLE `pro_kunena_aliases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_announcement`
--

DROP TABLE IF EXISTS `pro_kunena_announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_announcement` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `sdescription` text NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` tinyint(4) NOT NULL DEFAULT '0',
  `showdate` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_announcement`
--

LOCK TABLES `pro_kunena_announcement` WRITE;
/*!40000 ALTER TABLE `pro_kunena_announcement` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_attachments`
--

DROP TABLE IF EXISTS `pro_kunena_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mesid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `protected` tinyint(4) NOT NULL DEFAULT '0',
  `hash` char(32) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `folder` varchar(255) NOT NULL,
  `filetype` varchar(20) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filename_real` varchar(255) NOT NULL DEFAULT '',
  `caption` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mesid` (`mesid`),
  KEY `userid` (`userid`),
  KEY `hash` (`hash`),
  KEY `filename` (`filename`(191)),
  KEY `filename_real` (`filename_real`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_attachments`
--

LOCK TABLES `pro_kunena_attachments` WRITE;
/*!40000 ALTER TABLE `pro_kunena_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_categories`
--

DROP TABLE IF EXISTS `pro_kunena_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `name` tinytext,
  `alias` varchar(255) NOT NULL,
  `icon` varchar(60) NOT NULL,
  `icon_id` tinyint(4) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `accesstype` varchar(20) NOT NULL DEFAULT 'joomla.level',
  `access` int(11) NOT NULL DEFAULT '0',
  `pub_access` int(11) NOT NULL DEFAULT '1',
  `pub_recurse` tinyint(4) DEFAULT '1',
  `admin_access` int(11) NOT NULL DEFAULT '0',
  `admin_recurse` tinyint(4) DEFAULT '1',
  `ordering` smallint(6) NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL DEFAULT '0',
  `channels` text,
  `checked_out` tinyint(4) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review` tinyint(4) NOT NULL DEFAULT '0',
  `allow_anonymous` tinyint(4) NOT NULL DEFAULT '0',
  `post_anonymous` tinyint(4) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `headerdesc` text NOT NULL,
  `class_sfx` varchar(20) NOT NULL,
  `allow_polls` tinyint(4) NOT NULL DEFAULT '0',
  `topic_ordering` varchar(16) NOT NULL DEFAULT 'lastpost',
  `iconset` varchar(255) NOT NULL DEFAULT 'default',
  `numTopics` mediumint(8) NOT NULL DEFAULT '0',
  `numPosts` mediumint(8) NOT NULL DEFAULT '0',
  `last_topic_id` int(11) NOT NULL DEFAULT '0',
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `last_post_time` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `allow_ratings` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `category_access` (`accesstype`,`access`),
  KEY `published_pubaccess_id` (`published`,`pub_access`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_categories`
--

LOCK TABLES `pro_kunena_categories` WRITE;
/*!40000 ALTER TABLE `pro_kunena_categories` DISABLE KEYS */;
INSERT INTO `pro_kunena_categories` VALUES (1,0,'Main Forum','main-forum','',0,0,'joomla.group',0,1,1,0,1,1,1,'THIS',0,'0000-00-00 00:00:00',0,0,0,0,'This is the main forum section. It serves as a container for categories for your topics.','The section header is used to display additional information about the categories of topics that it contains.','',0,'lastpost','default',0,0,0,0,0,'',0),(2,1,'Welcome Mat','welcome-mat','',0,0,'joomla.group',0,1,1,0,1,1,1,'THIS',0,'0000-00-00 00:00:00',0,0,0,0,'We encourage new members to introduce themselves here. Get to know one another and share your interests.','[b]Welcome to the Kunena forum![/b] \n\n Tell us and our members who you are, what you like and why you became a member of this site. \n We welcome all new members and hope to see you around a lot!','',0,'lastpost','default',1,1,1,1,1491105976,'',0),(3,1,'Suggestion Box','suggestion-box','',0,0,'joomla.group',0,1,1,0,1,2,1,'THIS',0,'0000-00-00 00:00:00',0,0,0,0,'Have some feedback and input to share? \n Don\'t be shy and drop us a note. We want to hear from you and strive to make our site better and more user friendly for our guests and members a like.','This is the optional category header for the Suggestion Box.','',1,'lastpost','default',0,0,0,0,0,'',0);
/*!40000 ALTER TABLE `pro_kunena_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_configuration`
--

DROP TABLE IF EXISTS `pro_kunena_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_configuration` (
  `id` int(11) NOT NULL DEFAULT '0',
  `params` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_configuration`
--

LOCK TABLES `pro_kunena_configuration` WRITE;
/*!40000 ALTER TABLE `pro_kunena_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_logs`
--

DROP TABLE IF EXISTS `pro_kunena_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `topic_id` int(11) NOT NULL DEFAULT '0',
  `target_user` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(40) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT '0',
  `operation` varchar(40) NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `category_id` (`category_id`),
  KEY `topic_id` (`topic_id`),
  KEY `target_user` (`target_user`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_logs`
--

LOCK TABLES `pro_kunena_logs` WRITE;
/*!40000 ALTER TABLE `pro_kunena_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_messages`
--

DROP TABLE IF EXISTS `pro_kunena_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT '0',
  `thread` int(11) DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `name` tinytext,
  `userid` int(11) NOT NULL DEFAULT '0',
  `email` tinytext,
  `subject` tinytext,
  `time` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(128) DEFAULT NULL,
  `topic_emoticon` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `hold` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `hits` int(11) DEFAULT '0',
  `moved` tinyint(4) DEFAULT '0',
  `modified_by` int(7) DEFAULT NULL,
  `modified_time` int(11) DEFAULT NULL,
  `modified_reason` tinytext,
  PRIMARY KEY (`id`),
  KEY `thread` (`thread`),
  KEY `ip` (`ip`),
  KEY `userid` (`userid`),
  KEY `time` (`time`),
  KEY `locked` (`locked`),
  KEY `hold_time` (`hold`,`time`),
  KEY `parent_hits` (`parent`,`hits`),
  KEY `catid_parent` (`catid`,`parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_messages`
--

LOCK TABLES `pro_kunena_messages` WRITE;
/*!40000 ALTER TABLE `pro_kunena_messages` DISABLE KEYS */;
INSERT INTO `pro_kunena_messages` VALUES (1,0,1,2,'Kunena',42,NULL,'Welcome to Kunena!',1491105976,'127.0.0.1',0,0,0,0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pro_kunena_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_messages_text`
--

DROP TABLE IF EXISTS `pro_kunena_messages_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_messages_text` (
  `mesid` int(11) NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  PRIMARY KEY (`mesid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_messages_text`
--

LOCK TABLES `pro_kunena_messages_text` WRITE;
/*!40000 ALTER TABLE `pro_kunena_messages_text` DISABLE KEYS */;
INSERT INTO `pro_kunena_messages_text` VALUES (1,'[size=4][b]Welcome to Kunena![/b][/size] \n\n Thank you for choosing Kunena for your community forum needs in Joomla. \n\n Kunena, translated from Swahili meaning “to speak”, is built by a team of open source professionals with the goal of providing a top quality, tightly unified forum solution for Joomla. \n\n\n [size=4][b]Additional Kunena Resources[/b][/size] \n\n [b]Kunena Documentation:[/b] [url]https://www.kunena.org/docs[/url] \n\n [b]Kunena Support Forum[/b]: [url]https://www.kunena.org/forum[/url] \n\n [b]Kunena Downloads:[/b] [url]https://www.kunena.org/download[/url] \n\n [b]Kunena Blog:[/b] [url]https://www.kunena.org/blog[/url] \n\n [b]Follow Kunena on Twitter:[/b] [url]https://www.kunena.org/twitter[/url]');
/*!40000 ALTER TABLE `pro_kunena_messages_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_polls`
--

DROP TABLE IF EXISTS `pro_kunena_polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `threadid` int(11) NOT NULL,
  `polltimetolive` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `threadid` (`threadid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_polls`
--

LOCK TABLES `pro_kunena_polls` WRITE;
/*!40000 ALTER TABLE `pro_kunena_polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_polls_options`
--

DROP TABLE IF EXISTS `pro_kunena_polls_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_polls_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pollid` int(11) DEFAULT NULL,
  `text` varchar(100) DEFAULT NULL,
  `votes` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pollid` (`pollid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_polls_options`
--

LOCK TABLES `pro_kunena_polls_options` WRITE;
/*!40000 ALTER TABLE `pro_kunena_polls_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_polls_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_polls_users`
--

DROP TABLE IF EXISTS `pro_kunena_polls_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_polls_users` (
  `pollid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `votes` int(11) DEFAULT NULL,
  `lasttime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvote` int(11) DEFAULT NULL,
  UNIQUE KEY `pollid` (`pollid`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_polls_users`
--

LOCK TABLES `pro_kunena_polls_users` WRITE;
/*!40000 ALTER TABLE `pro_kunena_polls_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_polls_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_ranks`
--

DROP TABLE IF EXISTS `pro_kunena_ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_ranks` (
  `rank_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `rank_title` varchar(255) NOT NULL DEFAULT '',
  `rank_min` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rank_special` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `rank_image` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`rank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_ranks`
--

LOCK TABLES `pro_kunena_ranks` WRITE;
/*!40000 ALTER TABLE `pro_kunena_ranks` DISABLE KEYS */;
INSERT INTO `pro_kunena_ranks` VALUES (1,'New Member',0,0,'rank1.gif'),(2,'Junior Member',20,0,'rank2.gif'),(3,'Senior Member',40,0,'rank3.gif'),(4,'Premium Member',80,0,'rank4.gif'),(5,'Elite Member',160,0,'rank5.gif'),(6,'Platinum Member',320,0,'rank6.gif'),(7,'Administrator',0,1,'rankadmin.gif'),(8,'Moderator',0,1,'rankmod.gif'),(9,'Spammer',0,1,'rankspammer.gif'),(10,'Banned',0,1,'rankbanned.gif');
/*!40000 ALTER TABLE `pro_kunena_ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_rate`
--

DROP TABLE IF EXISTS `pro_kunena_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `rate` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_rate`
--

LOCK TABLES `pro_kunena_rate` WRITE;
/*!40000 ALTER TABLE `pro_kunena_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_sessions`
--

DROP TABLE IF EXISTS `pro_kunena_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_sessions` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `allowed` text,
  `lasttime` int(11) NOT NULL DEFAULT '0',
  `readtopics` text,
  `currvisit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `currvisit` (`currvisit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_sessions`
--

LOCK TABLES `pro_kunena_sessions` WRITE;
/*!40000 ALTER TABLE `pro_kunena_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_smileys`
--

DROP TABLE IF EXISTS `pro_kunena_smileys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_smileys` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `code` varchar(12) NOT NULL DEFAULT '',
  `location` varchar(50) NOT NULL DEFAULT '',
  `greylocation` varchar(60) NOT NULL DEFAULT '',
  `emoticonbar` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_smileys`
--

LOCK TABLES `pro_kunena_smileys` WRITE;
/*!40000 ALTER TABLE `pro_kunena_smileys` DISABLE KEYS */;
INSERT INTO `pro_kunena_smileys` VALUES (1,'B)','cool.png','cool-grey.png',1),(2,'8)','cool.png','cool-grey.png',0),(3,'8-)','cool.png','cool-grey.png',0),(4,':-(','sad.png','sad-grey.png',0),(5,':(','sad.png','sad-grey.png',1),(6,':sad:','sad.png','sad-grey.png',0),(7,':cry:','sad.png','sad-grey.png',0),(8,':)','smile.png','smile-grey.png',1),(9,':-)','smile.png','smile-grey.png',0),(10,':cheer:','cheerful.png','cheerful-grey.png',1),(11,';)','wink.png','wink-grey.png',1),(12,';-)','wink.png','wink-grey.png',0),(13,':wink:','wink.png','wink-grey.png',0),(14,';-)','wink.png','wink-grey.png',0),(15,':P','tongue.png','tongue-grey.png',1),(16,':p','tongue.png','tongue-grey.png',0),(17,':-p','tongue.png','tongue-grey.png',0),(18,':-P','tongue.png','tongue-grey.png',0),(19,':razz:','tongue.png','tongue-grey.png',0),(20,':angry:','angry.png','angry-grey.png',1),(21,':mad:','angry.png','angry-grey.png',0),(22,':unsure:','unsure.png','unsure-grey.png',1),(23,':o','shocked.png','shocked-grey.png',0),(24,':-o','shocked.png','shocked-grey.png',0),(25,':O','shocked.png','shocked-grey.png',0),(26,':-O','shocked.png','shocked-grey.png',0),(27,':eek:','shocked.png','shocked-grey.png',0),(28,':ohmy:','shocked.png','shocked-grey.png',1),(29,':huh:','wassat.png','wassat-grey.png',1),(30,':?','confused.png','confused-grey.png',0),(31,':-?','confused.png','confused-grey.png',0),(32,':???','confused.png','confused-grey.png',0),(33,':dry:','ermm.png','ermm-grey.png',1),(34,':ermm:','ermm.png','ermm-grey.png',0),(35,':lol:','grin.png','grin-grey.png',1),(36,':X','sick.png','sick-grey.png',0),(37,':x','sick.png','sick-grey.png',0),(38,':sick:','sick.png','sick-grey.png',1),(39,':silly:','silly.png','silly-grey.png',1),(40,':y32b4:','silly.png','silly-grey.png',0),(41,':blink:','blink.png','blink-grey.png',1),(42,':blush:','blush.png','blush-grey.png',1),(43,':oops:','blush.png','blush-grey.png',1),(44,':kiss:','kissing.png','kissing-grey.png',1),(45,':rolleyes:','blink.png','blink-grey.png',0),(46,':roll:','blink.png','blink-grey.png',0),(47,':woohoo:','w00t.png','w00t-grey.png',1),(48,':side:','sideways.png','sideways-grey.png',1),(49,':S','dizzy.png','dizzy-grey.png',1),(50,':s','dizzy.png','dizzy-grey.png',0),(51,':evil:','devil.png','devil-grey.png',1),(52,':twisted:','devil.png','devil-grey.png',0),(53,':whistle:','whistling.png','whistling-grey.png',1),(54,':pinch:','pinch.png','pinch-grey.png',1),(55,':D','laughing.png','laughing-grey.png',0),(56,':-D','laughing.png','laughing-grey.png',0),(57,':grin:','laughing.png','laughing-grey.png',0),(58,':laugh:','laughing.png','laughing-grey.png',0),(59,':|','neutral.png','neutral-grey.png',0),(60,':-|','neutral.png','neutral-grey.png',0),(61,':neutral:','neutral.png','neutral-grey.png',0),(62,':mrgreen:','mrgreen.png','mrgreen-grey.png',0),(63,':?:','question.png','question-grey.png',0),(64,':!:','exclamation.png','exclamation-grey.png',0),(65,':arrow:','arrow.png','arrow-grey.png',0),(66,':idea:','idea.png','idea-grey.png',0);
/*!40000 ALTER TABLE `pro_kunena_smileys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_thankyou`
--

DROP TABLE IF EXISTS `pro_kunena_thankyou`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_thankyou` (
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `targetuserid` int(11) NOT NULL,
  `time` datetime NOT NULL,
  UNIQUE KEY `postid` (`postid`,`userid`),
  KEY `userid` (`userid`),
  KEY `targetuserid` (`targetuserid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_thankyou`
--

LOCK TABLES `pro_kunena_thankyou` WRITE;
/*!40000 ALTER TABLE `pro_kunena_thankyou` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_thankyou` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_topics`
--

DROP TABLE IF EXISTS `pro_kunena_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `subject` tinytext,
  `icon_id` int(11) NOT NULL DEFAULT '0',
  `label_id` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `hold` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `posts` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `attachments` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0',
  `moved_id` int(11) NOT NULL DEFAULT '0',
  `first_post_id` int(11) NOT NULL DEFAULT '0',
  `first_post_time` int(11) NOT NULL DEFAULT '0',
  `first_post_userid` int(11) NOT NULL DEFAULT '0',
  `first_post_message` text,
  `first_post_guest_name` tinytext,
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `last_post_time` int(11) NOT NULL DEFAULT '0',
  `last_post_userid` int(11) NOT NULL DEFAULT '0',
  `last_post_message` text,
  `last_post_guest_name` tinytext,
  `rating` tinyint(4) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `locked` (`locked`),
  KEY `hold` (`hold`),
  KEY `posts` (`posts`),
  KEY `hits` (`hits`),
  KEY `first_post_userid` (`first_post_userid`),
  KEY `last_post_userid` (`last_post_userid`),
  KEY `first_post_time` (`first_post_time`),
  KEY `last_post_time` (`last_post_time`),
  KEY `last_post_id` (`last_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_topics`
--

LOCK TABLES `pro_kunena_topics` WRITE;
/*!40000 ALTER TABLE `pro_kunena_topics` DISABLE KEYS */;
INSERT INTO `pro_kunena_topics` VALUES (1,2,'Welcome to Kunena!',0,0,0,0,0,1,0,0,0,0,1,1491105976,42,'[size=4][b]Welcome to Kunena![/b][/size] \n\n Thank you for choosing Kunena for your community forum needs in Joomla. \n\n Kunena, translated from Swahili meaning “to speak”, is built by a team of open source professionals with the goal of providing a top quality, tightly unified forum solution for Joomla. \n\n\n [size=4][b]Additional Kunena Resources[/b][/size] \n\n [b]Kunena Documentation:[/b] [url]https://www.kunena.org/docs[/url] \n\n [b]Kunena Support Forum[/b]: [url]https://www.kunena.org/forum[/url] \n\n [b]Kunena Downloads:[/b] [url]https://www.kunena.org/download[/url] \n\n [b]Kunena Blog:[/b] [url]https://www.kunena.org/blog[/url] \n\n [b]Follow Kunena on Twitter:[/b] [url]https://www.kunena.org/twitter[/url]','Kunena',1,1491105976,42,'[size=4][b]Welcome to Kunena![/b][/size] \n\n Thank you for choosing Kunena for your community forum needs in Joomla. \n\n Kunena, translated from Swahili meaning “to speak”, is built by a team of open source professionals with the goal of providing a top quality, tightly unified forum solution for Joomla. \n\n\n [size=4][b]Additional Kunena Resources[/b][/size] \n\n [b]Kunena Documentation:[/b] [url]https://www.kunena.org/docs[/url] \n\n [b]Kunena Support Forum[/b]: [url]https://www.kunena.org/forum[/url] \n\n [b]Kunena Downloads:[/b] [url]https://www.kunena.org/download[/url] \n\n [b]Kunena Blog:[/b] [url]https://www.kunena.org/blog[/url] \n\n [b]Follow Kunena on Twitter:[/b] [url]https://www.kunena.org/twitter[/url]','Kunena',0,'');
/*!40000 ALTER TABLE `pro_kunena_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_user_categories`
--

DROP TABLE IF EXISTS `pro_kunena_user_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_user_categories` (
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '0',
  `allreadtime` int(11) NOT NULL DEFAULT '0',
  `subscribed` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`user_id`,`category_id`),
  KEY `category_subscribed` (`category_id`,`subscribed`),
  KEY `role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_user_categories`
--

LOCK TABLES `pro_kunena_user_categories` WRITE;
/*!40000 ALTER TABLE `pro_kunena_user_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_user_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_user_read`
--

DROP TABLE IF EXISTS `pro_kunena_user_read`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_user_read` (
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  UNIQUE KEY `user_topic_id` (`user_id`,`topic_id`),
  KEY `category_user_id` (`category_id`,`user_id`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_user_read`
--

LOCK TABLES `pro_kunena_user_read` WRITE;
/*!40000 ALTER TABLE `pro_kunena_user_read` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_user_read` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_user_topics`
--

DROP TABLE IF EXISTS `pro_kunena_user_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_user_topics` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `topic_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL,
  `posts` mediumint(8) NOT NULL DEFAULT '0',
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `owner` tinyint(4) NOT NULL DEFAULT '0',
  `favorite` tinyint(4) NOT NULL DEFAULT '0',
  `subscribed` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  UNIQUE KEY `user_topic_id` (`user_id`,`topic_id`),
  KEY `topic_id` (`topic_id`),
  KEY `posts` (`posts`),
  KEY `owner` (`owner`),
  KEY `favorite` (`favorite`),
  KEY `subscribed` (`subscribed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_user_topics`
--

LOCK TABLES `pro_kunena_user_topics` WRITE;
/*!40000 ALTER TABLE `pro_kunena_user_topics` DISABLE KEYS */;
INSERT INTO `pro_kunena_user_topics` VALUES (42,1,2,1,1,1,0,0,'');
/*!40000 ALTER TABLE `pro_kunena_user_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_users`
--

DROP TABLE IF EXISTS `pro_kunena_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_users` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `status_text` varchar(255) NOT NULL,
  `view` varchar(8) NOT NULL DEFAULT '',
  `signature` text,
  `moderator` int(11) DEFAULT '0',
  `banned` datetime DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `posts` int(11) DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `karma` int(11) DEFAULT '0',
  `karma_time` int(11) DEFAULT '0',
  `group_id` int(4) DEFAULT '1',
  `uhits` int(11) DEFAULT '0',
  `personalText` tinytext,
  `gender` tinyint(4) NOT NULL DEFAULT '0',
  `birthdate` date NOT NULL DEFAULT '0001-01-01',
  `location` varchar(50) DEFAULT NULL,
  `aim` varchar(50) DEFAULT NULL,
  `friendfeed` varchar(50) DEFAULT NULL,
  `bebo` varchar(50) DEFAULT NULL,
  `digg` varchar(50) DEFAULT NULL,
  `icq` varchar(50) DEFAULT NULL,
  `telegram` varchar(50) DEFAULT NULL,
  `vk` varchar(50) DEFAULT NULL,
  `microsoft` varchar(50) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `twitter` varchar(50) DEFAULT NULL,
  `facebook` varchar(50) DEFAULT NULL,
  `google` varchar(50) DEFAULT NULL,
  `myspace` varchar(50) DEFAULT NULL,
  `linkedin` varchar(50) DEFAULT NULL,
  `delicious` varchar(50) DEFAULT NULL,
  `instagram` varchar(50) DEFAULT NULL,
  `qq` varchar(50) DEFAULT NULL,
  `blogspot` varchar(50) DEFAULT NULL,
  `flickr` varchar(50) DEFAULT NULL,
  `apple` varchar(50) DEFAULT NULL,
  `qzone` varchar(50) DEFAULT NULL,
  `weibo` varchar(50) DEFAULT NULL,
  `wechat` varchar(50) DEFAULT NULL,
  `yim` varchar(50) DEFAULT NULL,
  `websitename` varchar(50) DEFAULT NULL,
  `websiteurl` varchar(50) DEFAULT NULL,
  `rank` tinyint(4) NOT NULL DEFAULT '0',
  `hideEmail` tinyint(1) NOT NULL DEFAULT '1',
  `showOnline` tinyint(1) NOT NULL DEFAULT '1',
  `canSubscribe` tinyint(1) NOT NULL DEFAULT '-1',
  `userListtime` int(11) DEFAULT '-2',
  `thankyou` int(11) DEFAULT '0',
  `ip` varchar(13) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  KEY `group_id` (`group_id`),
  KEY `posts` (`posts`),
  KEY `uhits` (`uhits`),
  KEY `banned` (`banned`),
  KEY `moderator` (`moderator`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_users`
--

LOCK TABLES `pro_kunena_users` WRITE;
/*!40000 ALTER TABLE `pro_kunena_users` DISABLE KEYS */;
INSERT INTO `pro_kunena_users` VALUES (42,0,'','',NULL,0,NULL,0,1,NULL,0,0,1,0,NULL,0,'0001-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,-1,-2,0,'');
/*!40000 ALTER TABLE `pro_kunena_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_users_banned`
--

DROP TABLE IF EXISTS `pro_kunena_users_banned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_users_banned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `ip` varchar(128) DEFAULT NULL,
  `blocked` tinyint(4) NOT NULL DEFAULT '0',
  `expiration` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_time` datetime NOT NULL,
  `reason_private` text,
  `reason_public` text,
  `modified_by` int(11) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `comments` text,
  `params` text,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `ip` (`ip`),
  KEY `expiration` (`expiration`),
  KEY `created_time` (`created_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_users_banned`
--

LOCK TABLES `pro_kunena_users_banned` WRITE;
/*!40000 ALTER TABLE `pro_kunena_users_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_kunena_users_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_kunena_version`
--

DROP TABLE IF EXISTS `pro_kunena_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_kunena_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(20) NOT NULL,
  `versiondate` date NOT NULL,
  `installdate` date NOT NULL,
  `build` varchar(20) NOT NULL,
  `versionname` varchar(40) DEFAULT NULL,
  `state` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_kunena_version`
--

LOCK TABLES `pro_kunena_version` WRITE;
/*!40000 ALTER TABLE `pro_kunena_version` DISABLE KEYS */;
INSERT INTO `pro_kunena_version` VALUES (1,'5.0.7','2017-03-31','2017-04-02','','Gayal','');
/*!40000 ALTER TABLE `pro_kunena_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_languages`
--

DROP TABLE IF EXISTS `pro_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `lang_code` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_native` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sef` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metakey` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `sitename` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_languages`
--

LOCK TABLES `pro_languages` WRITE;
/*!40000 ALTER TABLE `pro_languages` DISABLE KEYS */;
INSERT INTO `pro_languages` VALUES (1,0,'en-GB','English (UK)','English (UK)','en','en','','','','',1,0,1);
/*!40000 ALTER TABLE `pro_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_menu`
--

DROP TABLE IF EXISTS `pro_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`(100),`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_language` (`language`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_path` (`path`(100))
) ENGINE=InnoDB AUTO_INCREMENT=1290 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_menu`
--

LOCK TABLES `pro_menu` WRITE;
/*!40000 ALTER TABLE `pro_menu` DISABLE KEYS */;
INSERT INTO `pro_menu` VALUES (1,'','Menu_Item_Root','root','','','','',1,0,0,0,0,'0000-00-00 00:00:00',0,0,'',0,'',0,101,0,'*',0),(2,'menu','com_banners','Banners','','Banners','index.php?option=com_banners','component',0,1,1,4,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',5,14,0,'*',1),(3,'menu','com_banners','Banners','','Banners/Banners','index.php?option=com_banners','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',6,7,0,'*',1),(4,'menu','com_banners_categories','Categories','','Banners/Categories','index.php?option=com_categories&extension=com_banners','component',0,2,2,6,0,'0000-00-00 00:00:00',0,0,'class:banners-cat',0,'',8,9,0,'*',1),(5,'menu','com_banners_clients','Clients','','Banners/Clients','index.php?option=com_banners&view=clients','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners-clients',0,'',10,11,0,'*',1),(6,'menu','com_banners_tracks','Tracks','','Banners/Tracks','index.php?option=com_banners&view=tracks','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners-tracks',0,'',12,13,0,'*',1),(7,'menu','com_contact','Contacts','','Contacts','index.php?option=com_contact','component',0,1,1,8,0,'0000-00-00 00:00:00',0,0,'class:contact',0,'',15,20,0,'*',1),(8,'menu','com_contact_contacts','Contacts','','Contacts/Contacts','index.php?option=com_contact','component',0,7,2,8,0,'0000-00-00 00:00:00',0,0,'class:contact',0,'',16,17,0,'*',1),(9,'menu','com_contact_categories','Categories','','Contacts/Categories','index.php?option=com_categories&extension=com_contact','component',0,7,2,6,0,'0000-00-00 00:00:00',0,0,'class:contact-cat',0,'',18,19,0,'*',1),(10,'menu','com_messages','Messaging','','Messaging','index.php?option=com_messages','component',0,1,1,15,0,'0000-00-00 00:00:00',0,0,'class:messages',0,'',21,24,0,'*',1),(11,'menu','com_messages_add','New Private Message','','Messaging/New Private Message','index.php?option=com_messages&task=message.add','component',0,10,2,15,0,'0000-00-00 00:00:00',0,0,'class:messages-add',0,'',22,23,0,'*',1),(13,'menu','com_newsfeeds','News Feeds','','News Feeds','index.php?option=com_newsfeeds','component',0,1,1,17,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds',0,'',25,30,0,'*',1),(14,'menu','com_newsfeeds_feeds','Feeds','','News Feeds/Feeds','index.php?option=com_newsfeeds','component',0,13,2,17,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds',0,'',26,27,0,'*',1),(15,'menu','com_newsfeeds_categories','Categories','','News Feeds/Categories','index.php?option=com_categories&extension=com_newsfeeds','component',0,13,2,6,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds-cat',0,'',28,29,0,'*',1),(16,'menu','com_redirect','Redirect','','Redirect','index.php?option=com_redirect','component',0,1,1,24,0,'0000-00-00 00:00:00',0,0,'class:redirect',0,'',37,38,0,'*',1),(17,'menu','com_search','Basic Search','','Basic Search','index.php?option=com_search','component',0,1,1,19,0,'0000-00-00 00:00:00',0,0,'class:search',0,'',35,36,0,'*',1),(21,'menu','com_finder','Smart Search','','Smart Search','index.php?option=com_finder','component',0,1,1,27,0,'0000-00-00 00:00:00',0,0,'class:finder',0,'',31,32,0,'*',1),(22,'menu','com_joomlaupdate','Joomla! Update','','Joomla! Update','index.php?option=com_joomlaupdate','component',0,1,1,28,0,'0000-00-00 00:00:00',0,0,'class:joomlaupdate',0,'',33,34,0,'*',1),(101,'mainmenu','Home','home','','home','index.php?option=com_content&view=featured','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,'',0,'{\"num_leading_articles\":\"1\",\"num_intro_articles\":\"3\",\"num_columns\":\"3\",\"num_links\":\"0\",\"orderby_pri\":\"\",\"orderby_sec\":\"front\",\"order_date\":\"\",\"multi_column_order\":\"1\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_noauth\":\"\",\"article-allow_ratings\":\"\",\"article-allow_comments\":\"\",\"show_feed_link\":\"1\",\"feed_summary\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_readmore\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"show_page_heading\":1,\"page_title\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',1,2,1,'*',0),(470,'main','com_tags','com-tags','','com-tags','index.php?option=com_tags','component',0,1,1,29,0,'0000-00-00 00:00:00',0,1,'class:tags',0,'',39,40,0,'',1),(565,'main','com_postinstall','Post-installation messages','','Post-installation messages','index.php?option=com_postinstall','component',0,1,1,32,0,'0000-00-00 00:00:00',0,1,'class:postinstall',0,'',3,4,0,'*',1),(1260,'main','COM_JAEXTMANAGER','com-jaextmanager','','com-jaextmanager','index.php?option=com_jaextmanager','component',0,1,1,10103,0,'0000-00-00 00:00:00',0,1,'components/com_jaextmanager/assets/images/jauc.png',0,'{}',41,42,0,'',1),(1261,'main','COM_KUNENA','com-kunena','','com-kunena','index.php?option=com_kunena','component',0,1,1,10009,0,'0000-00-00 00:00:00',0,1,'components/com_kunena/media/icons/favicons/kunena-logo-white.png',0,'{}',43,70,0,'',1),(1262,'main','COM_KUNENA_DASHBOARD','com-kunena-dashboard','','com-kunena/com-kunena-dashboard','index.php?option=com_kunena&view=cpanel','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',44,45,0,'',1),(1263,'main','COM_KUNENA_CATEGORY_MANAGER','com-kunena-category-manager','','com-kunena/com-kunena-category-manager','index.php?option=com_kunena&view=categories','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',46,47,0,'',1),(1264,'main','COM_KUNENA_USER_MANAGER','com-kunena-user-manager','','com-kunena/com-kunena-user-manager','index.php?option=com_kunena&view=users','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',48,49,0,'',1),(1265,'main','COM_KUNENA_FILE_MANAGER','com-kunena-file-manager','','com-kunena/com-kunena-file-manager','index.php?option=com_kunena&view=attachments','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',50,51,0,'',1),(1266,'main','COM_KUNENA_EMOTICON_MANAGER','com-kunena-emoticon-manager','','com-kunena/com-kunena-emoticon-manager','index.php?option=com_kunena&view=smilies','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',52,53,0,'',1),(1267,'main','COM_KUNENA_RANK_MANAGER','com-kunena-rank-manager','','com-kunena/com-kunena-rank-manager','index.php?option=com_kunena&view=ranks','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',54,55,0,'',1),(1268,'main','COM_KUNENA_TEMPLATE_MANAGER','com-kunena-template-manager','','com-kunena/com-kunena-template-manager','index.php?option=com_kunena&view=templates','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',56,57,0,'',1),(1269,'main','COM_KUNENA_CONFIGURATION','com-kunena-configuration','','com-kunena/com-kunena-configuration','index.php?option=com_kunena&view=config','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',58,59,0,'',1),(1270,'main','COM_KUNENA_PLUGIN_MANAGER','com-kunena-plugin-manager','','com-kunena/com-kunena-plugin-manager','index.php?option=com_kunena&view=plugins','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',60,61,0,'',1),(1271,'main','COM_KUNENA_LOG_MANAGER','com-kunena-log-manager','','com-kunena/com-kunena-log-manager','index.php?option=com_kunena&view=logs','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',62,63,0,'',1),(1272,'main','COM_KUNENA_MENU_STATISTICS','com-kunena-menu-statistics','','com-kunena/com-kunena-menu-statistics','index.php?option=com_kunena&view=statistics','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',64,65,0,'',1),(1273,'main','COM_KUNENA_FORUM_TOOLS','com-kunena-forum-tools','','com-kunena/com-kunena-forum-tools','index.php?option=com_kunena&view=tools','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',66,67,0,'',1),(1274,'main','COM_KUNENA_TRASH_MANAGER','com-kunena-trash-manager','','com-kunena/com-kunena-trash-manager','index.php?option=com_kunena&view=trash','component',0,1261,2,10009,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',68,69,0,'',1),(1275,'kunenamenu','Forum','forum','','forum','index.php?option=com_kunena&view=home&defaultmenu=1277','component',1,1,1,10009,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"catids\":0}',71,88,0,'*',0),(1276,'kunenamenu','Index','index','','forum/index','index.php?option=com_kunena&view=category&layout=list','component',1,1275,2,10009,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',72,73,0,'*',0),(1277,'kunenamenu','Recent Topics','recent','','forum/recent','index.php?option=com_kunena&view=topics&mode=replies','component',1,1275,2,10009,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"topics_catselection\":\"\",\"topics_categories\":\"\",\"topics_time\":\"\"}',74,75,0,'*',0),(1278,'kunenamenu','New Topic','newtopic','','forum/newtopic','index.php?option=com_kunena&view=topic&layout=create','component',1,1275,2,10009,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',76,77,0,'*',0),(1279,'kunenamenu','No Replies','noreplies','','forum/noreplies','index.php?option=com_kunena&view=topics&mode=noreplies','component',1,1275,2,10009,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"topics_catselection\":\"\",\"topics_categories\":\"\",\"topics_time\":\"\"}',78,79,0,'*',0),(1280,'kunenamenu','My Topics','mylatest','','forum/mylatest','index.php?option=com_kunena&view=topics&layout=user&mode=default','component',1,1275,2,10009,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"topics_catselection\":\"2\",\"topics_categories\":\"0\",\"topics_time\":\"\"}',80,81,0,'*',0),(1281,'kunenamenu','Profile','profile','','forum/profile','index.php?option=com_kunena&view=user','component',1,1275,2,10009,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"integration\":1}',82,83,0,'*',0),(1282,'kunenamenu','Help','help','','forum/help','index.php?option=com_kunena&view=misc','component',1,1275,2,10009,0,'0000-00-00 00:00:00',0,3,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"body\":\"This help page is a menu item inside [b]Kunena Menu[\\/b], which allows easy navigation in your forum. \\n\\n You can use Joomla Menu Manager to edit items in this menu. Please go to [b]Administration[\\/b] >> [b]Menus[\\/b] >> [b]Kunena Menu[\\/b] >> [b]Help[\\/b] to edit or remove this menu item. \\n\\n In this menu item you can use Plain Text, BBCode or HTML. If you want to bind article into this page, you may use article BBCode (with article id): [code][article=full]123[\\/article][\\/code] \\n\\n If you want to create your own menu for Kunena, please start by creating [b]Home Page[\\/b] first. In that page you can select default menu item, which is shown when you enter to Kunena.\",\"body_format\":\"bbcode\"}',84,85,0,'*',0),(1283,'kunenamenu','Search','search','','forum/search','index.php?option=com_kunena&view=search','component',1,1275,2,10009,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',86,87,0,'*',0),(1284,'mainmenu','Forum','kunena-2017-04-02','','kunena-2017-04-02','index.php?Itemid=1275','alias',0,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"aliasoptions\":\"1275\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\"}',89,90,0,'*',0),(1285,'main','COM_JCE','com-jce','','com-jce','index.php?option=com_jce','component',0,1,1,10310,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/logo.png',0,'{}',91,98,0,'',1),(1286,'main','COM_JCE_MENU_CPANEL','com-jce-menu-cpanel','','com-jce/com-jce-menu-cpanel','index.php?option=com_jce','component',0,1285,2,10310,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',92,93,0,'',1),(1287,'main','COM_JCE_MENU_CONFIG','com-jce-menu-config','','com-jce/com-jce-menu-config','index.php?option=com_jce&view=config','component',0,1285,2,10310,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',94,95,0,'',1),(1288,'main','COM_JCE_MENU_PROFILES','com-jce-menu-profiles','','com-jce/com-jce-menu-profiles','index.php?option=com_jce&view=profiles','component',0,1285,2,10310,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',96,97,0,'',1),(1289,'main','COM_AKEEBA','com-akeeba','','com-akeeba','index.php?option=com_akeeba','component',1,1,1,10319,0,'0000-00-00 00:00:00',0,1,'../media/com_akeeba/icons/akeeba-16.png',0,'{}',99,100,0,'',1);
/*!40000 ALTER TABLE `pro_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_menu_types`
--

DROP TABLE IF EXISTS `pro_menu_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `menutype` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_menu_types`
--

LOCK TABLES `pro_menu_types` WRITE;
/*!40000 ALTER TABLE `pro_menu_types` DISABLE KEYS */;
INSERT INTO `pro_menu_types` VALUES (2,0,'usermenu','User Menu','A Menu for logged-in Users'),(3,0,'top','Top','Links for major types of users'),(6,0,'mainmenu','Main Menu','Simple Home Menu'),(11,0,'jomsocial','JomSocial toolbar','Toolbar items for JomSocial toolbar'),(12,685,'kunenamenu','Kunena Menu','This is the default Kunena menu. It is used as the top navigation for Kunena. It can be publish in any module position. Simply unpublish items that are not required.');
/*!40000 ALTER TABLE `pro_menu_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_messages`
--

DROP TABLE IF EXISTS `pro_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_messages`
--

LOCK TABLES `pro_messages` WRITE;
/*!40000 ALTER TABLE `pro_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_messages_cfg`
--

DROP TABLE IF EXISTS `pro_messages_cfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cfg_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_messages_cfg`
--

LOCK TABLES `pro_messages_cfg` WRITE;
/*!40000 ALTER TABLE `pro_messages_cfg` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_messages_cfg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_affiliate_activity`
--

DROP TABLE IF EXISTS `pro_mijoshop_affiliate_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_affiliate_activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `affiliate_id` int(11) NOT NULL,
  `key` varchar(64) NOT NULL,
  `data` text NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_affiliate_activity`
--

LOCK TABLES `pro_mijoshop_affiliate_activity` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_affiliate_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_affiliate_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_affiliate_login`
--

DROP TABLE IF EXISTS `pro_mijoshop_affiliate_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_affiliate_login` (
  `affiliate_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(96) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `total` int(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`affiliate_login_id`),
  KEY `email` (`email`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_affiliate_login`
--

LOCK TABLES `pro_mijoshop_affiliate_login` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_affiliate_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_affiliate_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_api`
--

DROP TABLE IF EXISTS `pro_mijoshop_api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_api` (
  `api_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `firstname` varchar(64) NOT NULL,
  `lastname` varchar(64) NOT NULL,
  `password` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`api_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_api`
--

LOCK TABLES `pro_mijoshop_api` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_api` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_api` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_custom_field`
--

DROP TABLE IF EXISTS `pro_mijoshop_custom_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_custom_field` (
  `custom_field_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) NOT NULL,
  `value` text NOT NULL,
  `location` varchar(7) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`custom_field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_custom_field`
--

LOCK TABLES `pro_mijoshop_custom_field` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_custom_field_customer_group`
--

DROP TABLE IF EXISTS `pro_mijoshop_custom_field_customer_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_custom_field_customer_group` (
  `custom_field_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  PRIMARY KEY (`custom_field_id`,`customer_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_custom_field_customer_group`
--

LOCK TABLES `pro_mijoshop_custom_field_customer_group` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field_customer_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field_customer_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_custom_field_description`
--

DROP TABLE IF EXISTS `pro_mijoshop_custom_field_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_custom_field_description` (
  `custom_field_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`custom_field_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_custom_field_description`
--

LOCK TABLES `pro_mijoshop_custom_field_description` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_custom_field_value`
--

DROP TABLE IF EXISTS `pro_mijoshop_custom_field_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_custom_field_value` (
  `custom_field_value_id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_field_id` int(11) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`custom_field_value_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_custom_field_value`
--

LOCK TABLES `pro_mijoshop_custom_field_value` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_custom_field_value_description`
--

DROP TABLE IF EXISTS `pro_mijoshop_custom_field_value_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_custom_field_value_description` (
  `custom_field_value_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`custom_field_value_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_custom_field_value_description`
--

LOCK TABLES `pro_mijoshop_custom_field_value_description` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field_value_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_custom_field_value_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_customer_activity`
--

DROP TABLE IF EXISTS `pro_mijoshop_customer_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_customer_activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `key` varchar(64) NOT NULL,
  `data` text NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_customer_activity`
--

LOCK TABLES `pro_mijoshop_customer_activity` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_customer_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_customer_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_customer_login`
--

DROP TABLE IF EXISTS `pro_mijoshop_customer_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_customer_login` (
  `customer_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(96) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `total` int(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`customer_login_id`),
  KEY `email` (`email`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_customer_login`
--

LOCK TABLES `pro_mijoshop_customer_login` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_customer_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_customer_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_event`
--

DROP TABLE IF EXISTS `pro_mijoshop_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `trigger` text NOT NULL,
  `action` text NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_event`
--

LOCK TABLES `pro_mijoshop_event` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_layout_module`
--

DROP TABLE IF EXISTS `pro_mijoshop_layout_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_layout_module` (
  `layout_module_id` int(11) NOT NULL AUTO_INCREMENT,
  `layout_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `position` varchar(14) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`layout_module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_layout_module`
--

LOCK TABLES `pro_mijoshop_layout_module` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_layout_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_layout_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_location`
--

DROP TABLE IF EXISTS `pro_mijoshop_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `address` text NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `fax` varchar(32) NOT NULL,
  `geocode` varchar(32) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `open` text NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_location`
--

LOCK TABLES `pro_mijoshop_location` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_marketing`
--

DROP TABLE IF EXISTS `pro_mijoshop_marketing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_marketing` (
  `marketing_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` text NOT NULL,
  `code` varchar(64) NOT NULL,
  `clicks` int(5) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`marketing_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_marketing`
--

LOCK TABLES `pro_mijoshop_marketing` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_marketing` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_marketing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_modification`
--

DROP TABLE IF EXISTS `pro_mijoshop_modification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_modification` (
  `modification_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `code` varchar(64) NOT NULL,
  `author` varchar(64) NOT NULL,
  `version` varchar(32) NOT NULL,
  `link` varchar(255) NOT NULL,
  `xml` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`modification_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_modification`
--

LOCK TABLES `pro_mijoshop_modification` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_modification` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_modification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_module`
--

DROP TABLE IF EXISTS `pro_mijoshop_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_module` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `code` varchar(32) NOT NULL,
  `setting` text NOT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_module`
--

LOCK TABLES `pro_mijoshop_module` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_order_custom_field`
--

DROP TABLE IF EXISTS `pro_mijoshop_order_custom_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_order_custom_field` (
  `order_custom_field_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `custom_field_value_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(32) NOT NULL,
  `location` varchar(16) NOT NULL,
  PRIMARY KEY (`order_custom_field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_order_custom_field`
--

LOCK TABLES `pro_mijoshop_order_custom_field` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_order_custom_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_order_custom_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_order_recurring`
--

DROP TABLE IF EXISTS `pro_mijoshop_order_recurring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_order_recurring` (
  `order_recurring_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `recurring_id` int(11) NOT NULL,
  `recurring_name` varchar(255) NOT NULL,
  `recurring_description` varchar(255) NOT NULL,
  `recurring_frequency` varchar(25) NOT NULL,
  `recurring_cycle` smallint(6) NOT NULL,
  `recurring_duration` smallint(6) NOT NULL,
  `recurring_price` decimal(10,4) NOT NULL,
  `trial` tinyint(1) NOT NULL,
  `trial_frequency` varchar(25) NOT NULL,
  `trial_cycle` smallint(6) NOT NULL,
  `trial_duration` smallint(6) NOT NULL,
  `trial_price` decimal(10,4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`order_recurring_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_order_recurring`
--

LOCK TABLES `pro_mijoshop_order_recurring` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_order_recurring` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_order_recurring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_order_recurring_transaction`
--

DROP TABLE IF EXISTS `pro_mijoshop_order_recurring_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_order_recurring_transaction` (
  `order_recurring_transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_recurring_id` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `amount` decimal(10,4) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`order_recurring_transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_order_recurring_transaction`
--

LOCK TABLES `pro_mijoshop_order_recurring_transaction` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_order_recurring_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_order_recurring_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_product_recurring`
--

DROP TABLE IF EXISTS `pro_mijoshop_product_recurring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_product_recurring` (
  `product_id` int(11) NOT NULL,
  `recurring_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`recurring_id`,`customer_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_product_recurring`
--

LOCK TABLES `pro_mijoshop_product_recurring` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_product_recurring` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_product_recurring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_recurring`
--

DROP TABLE IF EXISTS `pro_mijoshop_recurring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_recurring` (
  `recurring_id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,4) NOT NULL,
  `frequency` enum('day','week','semi_month','month','year') NOT NULL,
  `duration` int(10) unsigned NOT NULL,
  `cycle` int(10) unsigned NOT NULL,
  `trial_status` tinyint(4) NOT NULL,
  `trial_price` decimal(10,4) NOT NULL,
  `trial_frequency` enum('day','week','semi_month','month','year') NOT NULL,
  `trial_duration` int(10) unsigned NOT NULL,
  `trial_cycle` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`recurring_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_recurring`
--

LOCK TABLES `pro_mijoshop_recurring` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_recurring` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_recurring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_recurring_description`
--

DROP TABLE IF EXISTS `pro_mijoshop_recurring_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_recurring_description` (
  `recurring_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`recurring_id`,`language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_recurring_description`
--

LOCK TABLES `pro_mijoshop_recurring_description` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_recurring_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_recurring_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_mijoshop_upload`
--

DROP TABLE IF EXISTS `pro_mijoshop_upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_mijoshop_upload` (
  `upload_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`upload_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_mijoshop_upload`
--

LOCK TABLES `pro_mijoshop_upload` WRITE;
/*!40000 ALTER TABLE `pro_mijoshop_upload` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_mijoshop_upload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_modules`
--

DROP TABLE IF EXISTS `pro_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_modules`
--

LOCK TABLES `pro_modules` WRITE;
/*!40000 ALTER TABLE `pro_modules` DISABLE KEYS */;
INSERT INTO `pro_modules` VALUES (1,208,'Main Menu','','',1,'sidebar-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,1,'{\"menutype\":\"mainmenu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_menu\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(2,0,'Login','','',1,'login',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_login',1,1,'',1,'*'),(3,0,'Popular Articles','','',3,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_popular',3,1,'{\"count\":\"5\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(4,0,'Recently Added Articles','','',4,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_latest',3,1,'{\"count\":\"5\",\"ordering\":\"c_dsc\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(8,0,'Toolbar','','',1,'toolbar',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_toolbar',3,1,'',1,'*'),(9,0,'Quick Icons','','',1,'icon',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_quickicon',3,1,'',1,'*'),(10,0,'Logged-in Users','','',2,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_logged',3,1,'{\"count\":\"5\",\"name\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(12,0,'Admin Menu','','',1,'menu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',3,1,'{\"layout\":\"\",\"moduleclass_sfx\":\"\",\"shownew\":\"1\",\"showhelp\":\"1\",\"cache\":\"0\"}',1,'*'),(13,0,'Admin Submenu','','',1,'submenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_submenu',3,1,'',1,'*'),(14,0,'User Status','','',2,'status',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_status',3,1,'',1,'*'),(15,0,'Title','','',1,'title',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_title',3,1,'',1,'*'),(16,249,'Login Form','','',2,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_login',1,1,'{\"pretext\":\"\",\"posttext\":\"\",\"login\":\"\",\"logout\":\"\",\"greeting\":\"1\",\"name\":\"0\",\"usesecure\":\"0\",\"usetext\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(17,0,'Breadcrumbs','','',1,'navhelper',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_breadcrumbs',1,1,'{\"showHere\":\"1\",\"showHome\":\"1\",\"homeText\":\"Home\",\"showLast\":\"1\",\"separator\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(19,586,'User Menu','','',18,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',2,1,'{\"menutype\":\"usermenu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_menu\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(20,0,'Top','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,1,'{\"menutype\":\"top\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\" nav-pills\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"1\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(25,0,'Site Map','','',1,'sitemapload',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"mainmenu\",\"startLevel\":\"2\",\"endLevel\":\"3\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"sitemap\",\"window_open\":\"\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(27,272,'Archived Articles','','',17,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_archive',1,1,'{\"count\":\"12\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(29,0,'Articles Most Read','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_popular',1,1,'{\"catid\":[\"26\",\"29\"],\"count\":\"5\",\"show_front\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(30,0,'Feed Display','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_feed',1,1,'{\"rssurl\":\"http:\\/\\/community.joomla.org\\/blogs\\/community.feed?type=rss\",\"rssrtl\":\"0\",\"rsstitle\":\"1\",\"rssdesc\":\"1\",\"rssimage\":\"1\",\"rssitems\":\"3\",\"rssitemdesc\":\"1\",\"word_count\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\"}',0,'*'),(31,560,'News Flash','','',3,'sidebar-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_news',1,1,'{\"catid\":[\"94\"],\"image\":\"0\",\"item_title\":\"0\",\"link_titles\":\"\",\"item_heading\":\"h4\",\"showLastSeparator\":\"1\",\"readmore\":\"1\",\"count\":\"1\",\"ordering\":\"a.publish_up\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(33,0,'Random Image','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_random_image',1,1,'{\"type\":\"jpg\",\"folder\":\"images\\/sampledata\\/parks\\/animals\",\"link\":\"\",\"width\":\"180\",\"height\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',0,'*'),(34,0,'Articles Related Items','','',1,'',42,'2014-03-31 04:11:22','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_related_items',1,1,'{\"showDate\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\"}',0,'*'),(35,0,'Search','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_search',1,1,'{\"label\":\"\",\"width\":\"20\",\"text\":\"\",\"button\":\"\",\"button_pos\":\"right\",\"imagebutton\":\"\",\"button_text\":\"\",\"opensearch\":\"1\",\"opensearch_title\":\"\",\"set_itemid\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(37,0,'Syndicate Feeds','','',1,'syndicateload',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_syndicate',1,1,'{\"text\":\"Feed Entries\",\"format\":\"rss\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',0,'*'),(38,0,'Users Latest','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_users_latest',1,1,'{\"shownumber\":\"5\",\"linknames\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(39,247,'Who\'s Online','','',21,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_whosonline',1,1,'{\"showmode\":\"2\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"filter_groups\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(40,0,'Wrapper','','',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_wrapper',1,1,'{\"url\":\"http:\\/\\/www.youtube.com\\/embed\\/vb2eObvmvdI\",\"add\":\"1\",\"scrolling\":\"auto\",\"width\":\"640\",\"height\":\"390\",\"height_auto\":\"1\",\"target\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(41,0,'Footer','','',1,'footer',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_footer',1,1,'{\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(45,413,'Menu Example','','',16,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,1,'{\"menutype\":\"mainmenu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(47,0,'Latest Park Blogs','','',6,'position-7',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_latest',1,1,'{\"count\":\"5\",\"ordering\":\"c_dsc\",\"user_id\":\"0\",\"show_front\":\"1\",\"catid\":\"35\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\"}',0,'en-GB'),(48,0,'Custom HTML','','<p>This is a custom html module. That means you can enter whatever content you want.</p>',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(58,0,'Special!','','<h1>This week we have a special, half price on delicious oranges!</h1><div>Only for our special customers!</div><div>Use the code: Joomla! when ordering</div><p><em>This module can only be seen by people in the customers group or higher.</em></p>',1,'position-12',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',4,1,'{\"prepare_content\":\"1\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(61,563,'Articles Categories','','',12,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_categories',1,1,'{\"parent\":\"81\",\"show_description\":\"0\",\"numitems\":\"0\",\"show_children\":\"0\",\"count\":\"0\",\"maxlevel\":\"0\",\"layout\":\"_:default\",\"item_heading\":\"4\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(63,0,'Search','','',1,'head-search',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_search',1,1,'{\"label\":\"\",\"width\":\"20\",\"text\":\"\",\"button\":\"\",\"button_pos\":\"right\",\"imagebutton\":\"1\",\"button_text\":\"\",\"opensearch\":\"1\",\"opensearch_title\":\"\",\"set_itemid\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(65,0,'About Fruit Shop','','<p>The Fruit Shop site shows a number of Joomla! features.</p><p>The template uses classes in cascading style sheets to change the layout of items, such as creating the horizontal alphabetical list in the Fruit Encyclopedia.</p><p> </p>',1,'position-4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(68,0,'About Parks','','<p>The Parks sample site is designed as a simple site that can be routinely updated from the front end of Joomla!.</p><p>As a site, it is largely focused on a blog which can be updated using the front end article submission.</p><p>New weblinks can also be added through the front end.</p><p>A simple image gallery uses com_content with thumbnails displayed in a blog layout and full size images shown in article layout.</p><p>The Parks site features the language switch module. All of the content and modules are tagged as English (en-GB). If a second language pack is added with sample data this can be filtered using the language switch.</p><p>Parks uses HTML5 which is a major web standard (along with XHTML which is used in other areas of sample data).</p>',2,'position-4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(70,0,'Search (Atomic Template)','','',1,'atomic-search',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_search',1,0,'{\"width\":\"20\",\"text\":\"\",\"button\":\"\",\"button_pos\":\"right\",\"imagebutton\":\"\",\"button_text\":\"\",\"set_itemid\":\"\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(72,0,'Top Quote (Atomic Template)','','<hr />\r\n<h2 class=\"alt\">Powerful Content Management and a Simple Extensible Framework.</h2>\r\n<hr />',1,'atomic-topquote',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(73,0,'Bottom Left Column (Atomic Template)','','<h6>This is a nested column</h6>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>',1,'atomic-bottomleft',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(74,0,'Bottom Middle Column (Atomic Template)','','<h6>This is another nested column</h6>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>',1,'atomic-bottommiddle',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(75,0,'Sidebar (Atomic Template)','','<h3>A <span class=\"alt\">Simple</span> Sidebar</h3>\r\n<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue.</p>\r\n<p class=\"quiet\">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue.</p>\r\n<h5>Incremental leading</h5>\r\n<p class=\"incr\">Vestibulum ante ipsum primis in faucibus orci luctus vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue. sed aliquet vehicula, lectus tellus.</p>\r\n<p class=\"incr\">Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue. sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue. ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Cras ornare mattis nunc. Mauris venenatis, pede sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue. sed aliquet vehicula, lectus tellus pulvinar neque, non cursus sem nisi vel augue.</p>',1,'atomic-sidebar',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"layout\":\"\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(79,0,'Multilanguage status','','',1,'status',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_multilangstatus',3,1,'{\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(84,0,'Smart Search Module','','',2,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_finder',1,1,'{\"searchfilter\":\"\",\"show_autosuggest\":\"1\",\"show_advanced\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"field_size\":20,\"alt_label\":\"\",\"show_label\":\"0\",\"label_pos\":\"top\",\"show_button\":\"0\",\"button_pos\":\"right\",\"opensearch\":\"1\",\"opensearch_title\":\"\"}',0,'*'),(86,0,'Joomla Version','','',1,'footer',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_version',3,1,'{\"format\":\"short\",\"product\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(90,391,'About us','','<p><img src=\"images/joomlart/corporate/sam-10.jpg\" alt=\"Sample image\" class=\"img-thumbnail\" /></p>\r\n\r\n<p>JoomlArt - your best provider for Joomla templates and Joomla extensions since 2006. </p>',1,'footer-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(92,393,'Follow us','','<p>Didn\'t we got you connected? If not, blame us on not showing you earlier the following magic buttons:</p>\r\n<ul class=\"social-links\">\r\n<li><i class=\"fa fa-facebook-square\"></i> <a href=\"#\" title=\"Facebook\">Facebook</a></li>\r\n<li><i class=\"fa fa-twitter-square\"></i> <a href=\"#\" title=\"Twitter\">Twitter</a></li>\r\n<li><i class=\"fa  fa-google-plus-square\"></i> <a href=\"#\" title=\"Google plus\">Google plus</a></li>\r\n<li><i class=\"fa  fa-linkedin-square\"></i> <a href=\"#\" title=\"Linked-in\">Linked-in</a></li>\r\n</ul>',1,'footer-3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(93,399,'Contact us','','<div class=\"bs-example\">\r\n <address>\r\n  <strong>Company name</strong><br />\r\n        Address: 2411 Any Street, <br />\r\nAny Town, <br />\r\n        United Kingdom. <br />\r\n        <abbr title=\"Phone\">Phone:</abbr> +123 456 7890<br />\r\n        <abbr title=\"Phone\">Fax:</abbr> +123 456 7890<br />\r\n        <abbr title=\"Phone\">Mail to:</abbr><a href=\"mailto:#\"> first.last@example.com</a>\r\n</div>',1,'footer-4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(94,429,'T3','','<ul>\r\n<li><a href=\"http://www.joomlart.com/forums/downloads.php\">Download</a></li>\r\n<li><a href=\"#\">Release Announcement</a></li>\r\n<li><a href=\"#\">New Features</a></li>\r\n<li><a href=\"#\">Changelog and Details</a></li>\r\n<li><a href=\"#\">Migration FAQs</a></li>\r\n</ul>',1,'footer-5',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(95,430,'JoomlArt','','<ul>\r\n<li><a href=\"http://wiki.joomlart.com/wiki/Main_Page\">JA Wiki</a></li>\r\n<li><a href=\"http://www.joomlart.com/joomla/templates-club\">Joomla! Themes</a></li>\r\n<li><a href=\"http://www.joomlart.com/magento/themes-club\">Magento Themes</a></li>\r\n<li><a href=\"http://www.joomlart.com/joomla/extensions-club\">Joomla! Extension</a></li>\r\n<li><a href=\"http://www.joomlart.com/member/contact.php\">Contact Us</a></li>\r\n</ul>',1,'footer-6',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(96,213,'T3 Masthead 1','','<div class=\"jumbotron masthead\">\r\n    <h1>Welcome to T3</h1>\r\n    <p>The all new, modern and flexible framework from JoomlArt.</p>\r\n    <p><a class=\"btn btn-primary btn-lg\" href=\"http://www.joomlart.com/forums/downloads.php?do=cat&amp;id=460\"> Download <span class=\"hidden-phone\">T3 </span> </a></p>\r\n</div>',1,'home-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(97,214,'T3 Introduction','','<img class=\"img-responsive\" src=\"images/joomlart/banners/t3-banner.png\" alt=\"T3 Framework\" />\r\n\r\n<div class=\"row\">\r\n\r\n<div class=\"col-xs-12 col-sm-4\">\r\n  <h2>The \"All New\" T3</h2>\r\n  <p>Support the latest Joomla 3, T3 hits the beat with the brand-new look, design approach and incredibly powerful customization feature.</p>\r\n </div>\r\n\r\n<div class=\"col-xs-12 col-sm-4\">\r\n  <h2>User Centric Design</h2>\r\n  <p>Sleek look, clean coding and elegant design make T3 a sophisticated and user-friendly theme, guarantee to catch the attention right on spot. </p>\r\n</div>\r\n\r\n<div class=\"col-xs-12 col-sm-4\">\r\n  <h2>Developer\'s Freedom</h2>\r\n  <p>Customize and style your theme in a click with the built-in tool developed for T3 only, cherish the endless flexibility it gives you.</p>\r\n</div>\r\n</div>',1,'home-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(98,554,'T3 Features','','<header class=\"jumbotron\">\r\n<h1>Why Purity III?</h1>\r\n<p>A Free Responsive Joomla 3 Template can\'t go wrong</p>\r\n</header>\r\n\r\n<div class=\"row\">\r\n\r\n<div class=\"col-sm-6 col-md-3\">\r\n  <p><img src=\"images/joomlart/banners/responsive-icon.png\" alt=\"Reponsive\"></p>\r\n  <h2>Responsive</h2>\r\n  <p>Purity III is a fully responsive Joomla template. It looks amazingly beautiful in all screen sizes: from a wide screen desktop to tablet & mobile devices.</p>\r\n</div>\r\n\r\n<div class=\"col-sm-6 col-md-3\">\r\n  <p><img src=\"images/joomlart/banners/html5-icon.png\" alt=\"Compatibilities\"></p>\r\n  <h2>Compatibilities</h2>\r\n  <p>Purity III is compatible with most of the popular 3rd party Joomla extensions, such as: EasySocial, Kunena, JomSocial, Mijoshop, and more.</p>\r\n</div>\r\n\r\n<div class=\"col-sm-6 col-md-3\">\r\n  <p><img src=\"images/joomlart/banners/bootstrap-icon.png\" alt=\"Bootstrap 3\"></p>\r\n  <h2>Bootstrap 3</h2>\r\n  <p>Purity III embraces Bootstrap 3 at core, meaning it also supports Font Awesome 4, as well as all the cool features Bootstrap 3 Framework has.</p>\r\n</div>\r\n\r\n<div class=\"col-sm-6 col-md-3\">\r\n  <p><img src=\"images/joomlart/banners/seo-icon.png\" alt=\"SEO friendly\"></p>\r\n  <h2>SEO</h2>\r\n  <p>Great design impresses your visitors, but SEO friendly codes bring visitors, drive more <a href=\"http://www.google.com\" target=\"_blank\">Googlers</a> to yours while you\'re sleeping.</p>\r\n</div>\r\n\r\n</div>',1,'home-3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(99,0,'T3 Gallery','','<header class=\"jumbotron\">\r\n  <h1>T3 Gallery</h1>\r\n  <p>More to come. Stay tune :) !</p>\r\n</header>\r\n\r\n<div class=\"row\">\r\n  <div class=\"col-xs-6 col-sm-3\">\r\n    <a class=\"thumbnail\" href=\"http://www.joomlart.com/demo/#ja_obelisk\" title=\"JA Obelisk template\" target=\"_blank\">\r\n      <img class=\"img-responsive\" src=\"images/joomlart/thumbnails/thumb-1.png\" alt=\"JA Obelisk template\">\r\n    </a>\r\n  </div>\r\n  <div class=\"col-xs-6 col-sm-3\">\r\n    <a class=\"thumbnail\" href=\"http://www.joomlart.com/demo/#ja_magz\" title=\"JA Magz template\" target=\"_blank\">\r\n      <img class=\"img-responsive\" src=\"images/joomlart/thumbnails/thumb-2.png\" alt=\"JA Magz Template\">\r\n    </a>\r\n  </div>\r\n  <div class=\"col-xs-6 col-sm-3\">\r\n    <a class=\"thumbnail\" href=\"http://www.joomlart.com/demo/#ja_muzic\" title=\"JA Muzic Template\" target=\"_blank\">\r\n      <img class=\"img-responsive\" src=\"images/joomlart/thumbnails/thumb-3.png\" alt=\"JA Muzic Template\" target=\"_blank\">\r\n    </a>\r\n  </div>\r\n <div class=\"col-xs-6 col-sm-3\">\r\n    <a class=\"thumbnail\" href=\"http://www.joomlart.com/demo/#ja_fixel\" title=\"JA Fixel template\" target=\"_blank\">\r\n      <img class=\"img-responsive\" src=\"images/joomlart/thumbnails/thumb-4.png\" alt=\"JA Fixel Template\">\r\n    </a>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"row\">\r\n  <div class=\"col-xs-6 col-sm-3\">\r\n    <a class=\"thumbnail\" href=\"http://www.joomlart.com/demo/#ja_beranis\" title=\"JA beranis template\" target=\"_blank\">\r\n      <img class=\"img-responsive\" src=\"images/joomlart/thumbnails/thumb-5.png\" alt=\"JA Beranis template\">\r\n    </a>\r\n  </div>\r\n  <div class=\"col-xs-6 col-sm-3\">\r\n    <a class=\"thumbnail\" href=\"http://www.joomlart.com/demo/#ja_smashboard\" title=\"JA Smashboard Template\" target=\"_blank\">\r\n      <img class=\"img-responsive\" src=\"images/joomlart/thumbnails/thumb-6.png\" alt=\"JA Smashboard Template\">\r\n    </a>\r\n  </div>\r\n  <div class=\"col-xs-6 col-sm-3\">\r\n    <a class=\"thumbnail\" href=\"http://www.joomlart.com/demo/#ja_hawkstore\" title=\"JA Hawstore template\"  target=\"_blank\">\r\n      <img class=\"img-responsive\" src=\"images/joomlart/thumbnails/thumb-7.png\" alt=\"JA Hawstore template\">\r\n    </a>\r\n  </div>\r\n  <div class=\"col-xs-6 col-sm-3\">\r\n    <a class=\"thumbnail\" href=\"http://www.joomlart.com/demo/#ja_fubix\" title=\"JA Fubix Template\"  target=\"_blank\">\r\n      <img class=\"img-responsive\" src=\"images/joomlart/thumbnails/thumb-8.png\" alt=\"JA Fubix Template\">\r\n    </a>\r\n  </div>\r\n</div>',1,'home-4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(100,0,'T3 Masthead 2','','<div class=\"jumbotron masthead\">\r\n  <span class=\"section-arrow-alt\"></span>\r\n  <h2>Want to be the first to try our new framework...</h2>\r\n  <p>\r\n    <a class=\"btn btn-primary btn-lg\" href=\"http://www.joomlart.com/forums/downloads.php?do=cat&amp;id=460\"> Download <span class=\"hidden-phone\">T3 </span> </a>\r\n  </p>\r\n</div>\r\n',1,'home-5',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(101,406,'Built on T3 Framework','','<p>The powerful T3 Framework makes Purity III an extreme flexible for customization especially when it comes to layout configuration, and compatible with all the popular 3rd party extensions out there in the community.</p>',1,'position-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(102,407,'Joomla 3 & Bootstrap 3','','<p>Purity III is compatible with Joomla 3.x and embraces Bootstrap 3 at core. Comes with all the outstanding cool features in Joomla 3.x core, as well as the changes and improvements Bootstrap 3 Framework has.</p>',1,'position-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(103,408,'A Free Joomla template','','<p>Purity III is a fully responsive FREE Joomla template. It looks stunning on all screen sizes: from a wide screen to mobile devices. Definitely a responsive Joomla template you would never want to miss out for 2014, We promise.</p>\r\n',1,'position-3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(104,409,'Flat Design & Stunning Typo','','<p>Sleek look, clean coding and minimalism design, Purity is real flat both front-end and back-end. It is also packed with beautiful typography pages including: Support Policy and Pricing Table that indeed, will come in handy for anyone.</p>',1,'position-4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(105,0,'Position 5','','Curabitur orci hendrerit In rhoncus iaculis ut Quisque convallis sem egestas. Curabitur quis wisi id Fusce neque sem Cras id Curabitur eros. Velit nec tempus ligula sed penatibus dui habitasse tellus Lorem Sed. Elit condimentum dapibus Phasellus Nunc turpis tristique tincidunt ac orci at. Dapibus scelerisque.',1,'position-5',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(106,0,'Position 6','','Curabitur orci hendrerit In rhoncus iaculis ut Quisque convallis sem egestas. Curabitur quis wisi id Fusce neque sem Cras id Curabitur eros. Velit nec tempus ligula sed penatibus dui habitasse tellus Lorem Sed. Elit condimentum dapibus Phasellus Nunc turpis tristique tincidunt ac orci at. Dapibus scelerisque.',1,'position-6',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(107,0,'Position 7','','Curabitur orci hendrerit In rhoncus iaculis ut Quisque convallis sem egestas. Curabitur quis wisi id Fusce neque sem Cras id Curabitur eros. Velit nec tempus ligula sed penatibus dui habitasse tellus Lorem Sed. Elit condimentum dapibus Phasellus Nunc turpis tristique tincidunt ac orci at. Dapibus scelerisque.',1,'position-7',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(108,0,'Position 8','','Curabitur orci hendrerit In rhoncus iaculis ut Quisque convallis sem egestas. Curabitur quis wisi id Fusce neque sem Cras id Curabitur eros. Velit nec tempus ligula sed penatibus dui habitasse tellus Lorem Sed. Elit condimentum dapibus Phasellus Nunc turpis tristique tincidunt ac orci at. Dapibus scelerisque.',1,'position-8',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(112,578,'Purity III - The best free Joomla Template','','<p> </p>\r\n<a href=\"index.php/layout/new-layouts/features-intro\" title=\"Video\"><img src=\"images/joomlart/demo/video.png\" alt=\"Sample video\" /></a>\r\n<p> </p>\r\n<p>Sneakpeak on Purity III - the best free responsive Joomla template of all time!</p>\r\n',1,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(113,319,'Demo Content','','',2,'sidebar-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_category',1,1,'{\"mode\":\"dynamic\",\"show_on_article_page\":\"1\",\"show_front\":\"show\",\"count\":\"5\",\"category_filtering_type\":\"1\",\"catid\":[\"\",\"80\"],\"show_child_category_articles\":\"0\",\"levels\":\"1\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.title\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"0\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"0\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"1\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(114,207,'Main Menu','','',3,'off-canvas',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"mainmenu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_menu\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(119,220,'Product intro','','<p>Dui eu dolor Curabitur pellentesque pellentesque ligula quis et leo neque. Nibh vitae Nam sit eu felis mauris porttitor odio a est. Felis lacinia risus tempus Aenean sagittis tortor Nulla non mattis pharetra. Et vel semper eu tellus lacinia sed semper ac tristique Nulla. Enim vel mattis Nulla sit In Ut Curabitur nonummy suscipit ut. Et feugiat morbi metus tincidunt ante consectetuer nec rutrum nunc at. Tellus Lorem Lorem.</p>',1,'features-intro-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\" row-feature-primary\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(120,221,'Fully Reponsive','','<div class=\"col-md-6 feature-ct pd-feature-ct\">\r\n  <h2>Fully Responsive</h2>\r\n  <p>T3 Framework is one of the first responsive Joomla frameworks template. It supports numbers of responsive layouts including: Wide, Normal, XTablet, Tablet and Mobile. </p>\r\n</div>\r\n<div class=\"col-md-6 feature-img pd-feature-img\">\r\n  <img src=\"http://joomlart.s3.amazonaws.com/images/jat3v3-documents/landing-page/responsive.png\" title=\"Fully responsive joomla framework\">\r\n</div>',2,'features-intro-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\" row-feature-alt\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(121,222,'HTML5, Bootstrap and LESS','','<div class=\"col-md-6 feature-img pd-feature-img\">\r\n  <img src=\"http://joomlart.s3.amazonaws.com/images/jat3v3-documents/landing-page/html5_bootstrap.jpg\" title=\"HTML5 and Bootstrap\">\r\n</div>\r\n\r\n<div class=\"col-md-6 feature-ct pd-feature-ct\">    \r\n  <h2>HTML5, Bootstrap and LESS</h2>\r\n  <p>HTML 5 ensures web experience and visualization quality that benefits from rich markup and compatibility. With Bootstrap and LESS- the Dynamic Stylesheet language, you can standardize your grid, typography, and modules with less efforts. All are built in T3 Framework at core.</p>\r\n</div>\r\n',6,'features-intro-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(141,250,'2 starter themes','',' <div class=\"col-md-6 feature-ct pd-feature-ct\">\r\n  <h2>2 starter themes</h2>\r\n  <p>T3 Framework comes with 2 starter themes: the usual T3 Blank template (Bootstrap 2 T3 Blank template) and the new T3 B3 Blank (Bootstrap 3 T3 Blank template). Both looks amazingly stunning on any devices. </p>\r\n </div>\r\n\r\n<div class=\"col-md-6 feature-img\">\r\n  <img src=\"http://joomlart.s3.amazonaws.com/images/jat3v3-documents/landing-page/2-starter-theme.jpg\" title=\"2 starter themes\">\r\n</div>\r\n',3,'features-intro-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(142,251,'Flat design','','<div class=\"col-md-6 feature-img\">\r\n<img src=\"http://joomlart.s3.amazonaws.com/images/jat3v3-documents/landing-page/flat_design.jpg\" title=\"Flat design\">\r\n</div>\r\n\r\n<div class=\"col-md-6 feature-ct pd-feature-ct\">\r\n<h2>Flat design</h2>\r\n<p>The T3 Framework 2.0.0 is real Flat, both Front-page and back-end setting panel. It deverses a clean layout and typography.</p>\r\n</div>',4,'features-intro-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\" row-feature-alt\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(143,252,'Megamenu and Off-canvas','','<div class=\"col-md-6 feature-ct pd-feature-ct\">\r\n<h2>Megamenu and Off-canvas</h2>\r\n<p>Megamenu and Off-canvas are highlight features in T3 Framework. It allows you to build up a powerful menu system and you are full control.</p>\r\n</div>\r\n\r\n<div class=\"col-md-6 feature-img\">\r\n<img src=\"http://joomlart.s3.amazonaws.com/images/jat3v3-documents/landing-page/megamenu_offcanvas.png\" title=\"megamenu and off-canvas\">\r\n</div>\r\n',5,'features-intro-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(163,345,'Blog Categories','','',11,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_categories',1,1,'{\"parent\":\"87\",\"show_description\":\"0\",\"numitems\":\"0\",\"show_children\":\"0\",\"count\":\"0\",\"maxlevel\":\"0\",\"layout\":\"_:default\",\"item_heading\":\"4\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(165,348,'Blog Tags','','',20,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_tags_popular',1,1,'{\"maximum\":\"10\",\"timeframe\":\"alltime\",\"order_value\":\"count\",\"order_direction\":\"1\",\"display_count\":1,\"no_results_text\":\"0\",\"minsize\":1,\"maxsize\":2,\"layout\":\"_:cloud\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(166,349,'Important Articles ','','',10,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_category',1,1,'{\"mode\":\"normal\",\"show_on_article_page\":\"1\",\"show_front\":\"show\",\"count\":\"5\",\"category_filtering_type\":\"1\",\"catid\":[\"94\",\"95\",\"96\",\"97\"],\"show_child_category_articles\":\"0\",\"levels\":\"2\",\"author_filtering_type\":\"1\",\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"Joomla\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.title\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"0\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"0\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(167,354,'Magazine - Articles','','',1,'magazine-articles',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_categories',1,1,'{\"parent\":\"85\",\"show_description\":\"0\",\"numitems\":\"0\",\"show_children\":\"0\",\"count\":\"0\",\"maxlevel\":\"0\",\"layout\":\"purity_iii:magazine\",\"item_heading\":\"4\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\",\"extra-count\":\"4\",\"extra-show-subcat\":\"0\"}',0,'*'),(168,362,'Magazine - Other articles','','',1,'after-content',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_category',1,1,'{\"mode\":\"dynamic\",\"show_on_article_page\":\"1\",\"show_front\":\"show\",\"count\":\"8\",\"category_filtering_type\":\"1\",\"catid\":[\"85\"],\"show_child_category_articles\":\"1\",\"levels\":\"2\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.title\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"1\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"0\",\"show_hits\":\"1\",\"show_author\":\"1\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(177,373,'How we work','','<p><img src=\"images/joomlart/corporate/sam-1.jpg\" alt=\"Sample image\" class=\"img-responsive\" /></p>\r\n<h3>At the first glance</h3>\r\n<p>T3 Framework. Joomla 3. Bootstrap 3.  Responsive. Customizable. Multi-style. Flat and typographic design.</p>',1,'position-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(178,374,'Success Stories','','<p><img src=\"images/joomlart/corporate/sam-2.jpg\" alt=\"Sample image 2\" class=\"img-responsive\" /></p>\r\n<h3>Purity Series Stories </h3>\r\n<p>2007: Purity, default Joomla template.\r\n<br>2009: free Joomla template JA Purity II.\r\n<br>2014: it\'s Purity III\'s time to rock.</p>',1,'position-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(179,375,'Let\'s connect','','<p><img src=\"images/joomlart/corporate/sam-3.jpg\" alt=\"Sample image\" class=\"img-responsive\" /></p>\r\n<h3>What\'s more?</h3>\r\n<p><strong>Purity III</strong> is ready for numerous of the most pupular 3rd party extensions in the market! And the list is yet to complete.</p>',1,'position-4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(181,377,'Slideshow','','<div class=\"container\">\r\n<div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\"><!-- Indicators --> <!-- Wrapper for slides -->\r\n<div class=\"carousel-inner\">\r\n<div class=\"item active\"><img src=\"images/joomlart/slideshow/sl-1.jpg\" alt=\"Sample image\" />\r\n<div class=\"carousel-caption\">\r\n<h2>Your perfect starting template, Purity III</h2>\r\n<p>Either it\'s your first time with Joomla or you are a developer already, Purity III won\'t let you down.</p>\r\n</div>\r\n</div>\r\n<div class=\"item\"><img src=\"images/joomlart/slideshow/sl-2.jpg\" alt=\"Sample image\" />\r\n<div class=\"carousel-caption\">\r\n<h2>This is the best FREE Joomla 3 template!</h2>\r\n<p>We have drunken too much of the best… but this repsonsive Joomla template truly is, and IT\'S FREE!</p>\r\n</div>\r\n</div>\r\n<div class=\"item\"><img src=\"images/joomlart/slideshow/sl-3.jpg\" alt=\"Sample image\" />\r\n<div class=\"carousel-caption\">\r\n<h2>The next generation of Purity series</h2>\r\n<p>Sophisticated in Design, Brilliant in Features. That\'s how we define Purity Series.</p>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- Controls --></div>\r\n</div>',1,'slideshow',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(182,387,'Testimonials','','<div class=\"well\" style=\"margin-bottom: 0;\">\r\n<blockquote style=\"margin-bottom: 0;\">\r\n  <p>I\'m in need of a FREE responsive Joomla template, which definitely has to be on T3 Framework. Something easy to customize, powerful in functions, quick to set it up, something to write blog and post news at the same time. Now I\'ve got Purity III. Totally satisfied.</p>\r\n  <small>Melisa Monroe in <cite title=\"Source Title\">Somewhere over Joomla world</cite></small>\r\n</blockquote>\r\n</div>\r\n',1,'position-5',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(183,388,'Business Joomla template','','<p><img src=\"images/joomlart/corporate/sam-6.jpg\" alt=\"Sample image\" class=\"img-thumbnail\" /></p>\r\n<p>This is how your eCommerce Joomla template looks with Purity III. </p>',1,'position-9',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(184,389,'Blog Joomla template','','<p><img src=\"images/joomlart/corporate/sam-7.jpg\" alt=\"Sample image\" class=\"img-thumbnail\" /></p>\r\n<p> This is how your Joomla template for personal blog looks with Purity III.</p>',1,'position-10',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(185,390,'News Joomla template','','<p><img src=\"images/joomlart/corporate/sam-8.jpg\" alt=\"Sample image\" class=\"img-thumbnail\" /></p>\r\n\r\n<p> This is how your Joomla template for news looks with Purity III. </p>',1,'position-11',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(189,397,'Why we do it','','<p><img src=\"images/joomlart/corporate/sam-4.jpg\" alt=\"Sample image\" class=\"img-responsive\" /></p>\r\n<h3>How this rocks</h3>\r\n<p>With this free Joomla template, you can create a whole fresh site in 5 minutes. Woo hoo!</p>',1,'position-3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(190,398,'Portfolio Joomla template','','<p><img src=\"images/joomlart/corporate/sam-9.jpg\" alt=\"Sample image\" class=\"img-thumbnail\" /></p>\r\n\r\n<p>This is how your Joomla template for portfolio looks with Purity III.</p>',1,'position-12',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(191,400,'Blog post','','',1,'footer-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_category',1,1,'{\"mode\":\"normal\",\"show_on_article_page\":\"1\",\"show_front\":\"show\",\"count\":\"3\",\"category_filtering_type\":\"1\",\"catid\":[\"94\",\"95\",\"96\",\"97\"],\"show_child_category_articles\":\"0\",\"levels\":\"3\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.title\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"0\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"0\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(192,403,'Popular post','','',1,'tab-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_category',1,0,'{\"mode\":\"normal\",\"show_on_article_page\":\"1\",\"show_front\":\"show\",\"count\":\"5\",\"category_filtering_type\":\"1\",\"catid\":[\"90\",\"89\",\"91\",\"92\",\"93\"],\"show_child_category_articles\":\"0\",\"levels\":\"1\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.hits\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"1\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"1\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(193,404,'Sample Banner 1','','<a href=\"#\" title=\"Sample banner\"><img class=\"img-responsive\" src=\"images/joomlart/banners/sb-1.jpg\" alt=\"Sample banner\" /></a>',13,'sidebar-2',42,'2015-03-24 08:53:26','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(194,405,'Custom tabs','','<!-- Nav tabs -->\r\n<ul class=\"nav nav-tabs\">\r\n  <li class=\"active\"><a href=\"#popular\" data-toggle=\"tab\">Latest post</a></li>\r\n  <li><a href=\"#latest\" data-toggle=\"tab\">Most read</a></li>\r\n</ul>\r\n\r\n<!-- Tab panes -->\r\n<div class=\"tab-content\">\r\n  <div class=\"tab-pane active\" id=\"popular\">{loadposition tab-1}</div>\r\n  <div class=\"tab-pane\" id=\"latest\">{loadposition tab-2}</div>\r\n</div>\r\n',14,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(195,411,'Most read','','',1,'tab-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_category',1,0,'{\"mode\":\"normal\",\"show_on_article_page\":\"1\",\"show_front\":\"show\",\"count\":\"5\",\"category_filtering_type\":\"1\",\"catid\":[\"90\",\"89\",\"91\",\"92\",\"93\"],\"show_child_category_articles\":\"0\",\"levels\":\"1\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.created\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"1\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"1\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(196,414,'Joomla','','<ul>\r\n<li><a href=\"#\" title=\"Joomla template\">Joomla template</a></li>\r\n<li><a href=\"#\" title=\"Joomla extension\">Joomla extension</a></li>\r\n<li><a href=\"#\" title=\"Joomla module\">Joomla module</a></li>\r\n<li><a href=\"#\" title=\"Joomla plugin\">Joomla plugin</a></li>\r\n<li><a href=\"#\" title=\"Joomla 3 template\">Joomla 3 template</a></li>\r\n</ul>',1,'footer-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(197,415,'Bootstrap 3','','<ul>\r\n<li><a href=\"#\" title=\"Joomla\">Joomla</a></li>\r\n<li><a href=\"#\" title=\"Bootstrap\">Bootstrap</a></li>\r\n<li><a href=\"#\" title=\"Joomla 2.5\">Joomla 2.5</a></li>\r\n<li><a href=\"#\" title=\"Joomla 3.2\">Joomla 3.2</a></li>\r\n<li><a href=\"#\" title=\"T3 framework template\">T3 framework template</a></li>\r\n</ul>',1,'footer-3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(198,416,'Framework','','<ul>\r\n<li><a href=\"#\" title=\"T3 template\">T3 template</a></li>\r\n<li><a href=\"#\" title=\"T3 Framework\">T3 Framework</a></li>\r\n<li><a href=\"#\" title=\"Joomla framework\">Joomla framework</a></li>\r\n<li><a href=\"#\" title=\"Template framework\">Template framework</a></li>\r\n\r\n<li><a href=\"#\" title=\"Responsive template\">Responsive template</a></li>\r\n</ul>',1,'footer-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(199,417,'Typography','','<ul>\r\n<li><a href=\"#\" title=\"Responsive\">Responsive</a></li>\r\n<li><a href=\"#\" title=\"Font Awesome 4\">Font Awesome 4</a></li>\r\n<li><a href=\"#\" title=\"Multiple layouts\">Multiple layouts</a></li>\r\n<li><a href=\"#\" title=\"Multiple layouts\">Multiple layouts</a></li>\r\n<li><a href=\"#\" title=\"Compatible Extensions\">Compatible Extensions</a></li>\r\n</ul>',1,'footer-4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(200,422,'Masthead','','<div class=\"jumbotron jumbotron-primary masthead\">\r\n  <h1>Hello, I\'m Purity III</h1>\r\n  <p>Now back and way cooler.</p>\r\n  <p class=\"btn-actions\"><a href=\"http://bit.ly/purity_iii\" class=\"btn btn-primary btn-lg\">Check me out</a></p>\r\n</div>',1,'masthead',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\" row-feature-primary\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(202,443,'Feature 1','','<div class=\"text-center\">\r\n<div class=\"item-image\"><img class=\"img-responsive\" pagespeed_url_hash=\"557298203\" alt=\"T3 Framework\" src=\"images/joomlart/intro-page/fullresponsive.png\"></div>\r\n\r\n<div class=\"col-md-4\">\r\n  <h3>The Perfect Starting Point</h3>\r\n  <p>Purity III is a GREAT starter theme for any Joomla lovers. It allows YOU to get started in minutes, and highly versatile to fit in any type of projects</p>\r\n </div>\r\n\r\n<div class=\"col-md-4\">\r\n  <h3>Joomla 3 Native</h3>\r\n  <p>Purity III supports Joomla 3 at core. The sleek look, clean code and flat design sets it stand out and guarantee to capture anyone\'s attention</p>\r\n</div>\r\n\r\n<div class=\"col-md-4\">\r\n  <h3>Easy to Customize</h3>\r\n  <p>Purity III is extremely flexible to customize. Thanks to the powerful T3 Framework, which makes all the impossibilities possible</p>\r\n</div>\r\n\r\n</div>',1,'features-intro-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(203,444,'Supports multiple layouts','','<header class=\"jumbotron\">\r\n<h2>Supports Multiple Layouts</h2>\r\n<p>8 layouts with dynamic and flexible grids</p>\r\n</header>\r\n\r\n<div class=\"gallery\">\r\n\r\n  <div class=\"col-xs-6 col-md-3\">\r\n    <div class=\"thumbnail\">\r\n      <a target=\"_blank\" title=\"magazine layout\" href=\"index.php/layout/new-layouts/magazine\">\r\n        <img pagespeed_url_hash=\"2579736203\" alt=\"\" src=\"images/joomlart/supported-layout/magazine.png\" class=\"img-responsive\">\r\n      </a>\r\n      <h4 class=\"text-center\">Magazine Layout</h4>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-3\">\r\n    <div class=\"thumbnail\">\r\n      <a target=\"_blank\" title=\"Coperate layout\" href=\"index.php/layout/new-layouts//corporate\">\r\n          <img pagespeed_url_hash=\"2874236124\" alt=\"\" src=\"images/joomlart/supported-layout/corporate.png\" class=\"img-responsive\">\r\n      </a>\r\n      <h4 class=\"text-center\">Corporate Layout</h4>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-3\">\r\n    <div class=\"thumbnail\">\r\n      <a target=\"_blank\" title=\"blog layout\" href=\"index.php/layout/new-layouts/blog\">\r\n        <img pagespeed_url_hash=\"3168736045\" target=\"_blank\" alt=\"\" src=\"images/joomlart/supported-layout/blog.png\" class=\"img-responsive\">\r\n      </a>\r\n      <h4 class=\"text-center\">Blog Layout</h4>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-3\">\r\n    <div class=\"thumbnail\">\r\n      <a target=\"_blank\" title=\"features intro 1\" href=\"index.php/layout/new-layouts/features-intro\">\r\n        <img pagespeed_url_hash=\"3757735887\" alt=\"\" src=\"images/joomlart/supported-layout/features_1.png\" class=\"img-responsive\">\r\n      </a>\r\n      <h4 class=\"text-center\">Features Intro 1 Layout</h4>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-3\">\r\n    <div class=\"thumbnail\">\r\n      <a target=\"_blank\" title=\"features intro 2\" href=\"http://joomla-templates.joomlart.com/purity_iii/\">\r\n        <img pagespeed_url_hash=\"4052235808\" alt=\"\" src=\"images/joomlart/supported-layout/features_2.png\" class=\"img-responsive\">\r\n      </a>\r\n      <h4 class=\"text-center\">Features Intro 2 Layout</h4>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-3\">\r\n    <div class=\"thumbnail\">\r\n      <a target=\"_blank\" title=\"portfolio layout\" href=\"index.php/layout/new-layouts/portfolio\">\r\n        <img pagespeed_url_hash=\"3463235966\" alt=\"\" src=\"images/joomlart/supported-layout/portfolio.png\" class=\"img-responsive\">\r\n      </a>\r\n      <h4 class=\"text-center\">Portfolio Layout</h4>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-3\">\r\n    <div class=\"thumbnail\">\r\n      <a target=\"_blank\" title=\"\" href=\"index.php/layout/new-layouts/glossary\">\r\n        <img alt=\"\" src=\"images/joomlart/supported-layout/glossary.png\" class=\"img-responsive\">\r\n      </a>\r\n      <h4 class=\"text-center\">Glossary Layout</h4>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-3\">\r\n    <div class=\"thumbnail\">\r\n      <a target=\"_blank\" title=\"\" href=\"index.php/layout/class-layout/default-layout\">\r\n        <img alt=\"\" src=\"images/joomlart/supported-layout/classic_layout.png\" class=\"img-responsive\">\r\n      </a>\r\n      <h4 class=\"text-center\">Classic Layout</h4>\r\n    </div>\r\n  </div>\r\n\r\n</div>',3,'features-intro-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(204,445,'Why Purity III?','','<header class=\"jumbotron\">\r\n<h2>Why Purity III?</h2>\r\n<p>A Free Responsive Joomla 3 Template that no one can resist</p>\r\n</header>\r\n\r\n<div class=\"text-center\">\r\n\r\n<div class=\"col-md-3\">\r\n  <p><img pagespeed_url_hash=\"932791188\" alt=\"Responsive\" src=\"images/joomlart/banners/responsive-icon.png\" /></p>\r\n  <h3>Responsive</h3>\r\n  <p>Purity III is a fully responsive Joomla template. It looks amazingly beautiful in all screen sizes: from a wide screen desktop to tablet & mobile devices</p>\r\n</div>\r\n\r\n<div class=\"col-md-3\">\r\n  <p><img pagespeed_url_hash=\"2048194936\" alt=\"Compatibilities\" src=\"images/joomlart/banners/html5-icon.png\"></p>\r\n  <h3>Compatibilities</h3>\r\n  <p>Purity III is compatible with most of the popular 3rd party Joomla extensions, such as: EasySocial, Kunena, JomSocial, Mijoshop, etc</p>\r\n</div>\r\n\r\n<div class=\"col-md-3\">\r\n  <p><img pagespeed_url_hash=\"1985577692\" alt=\"Bootstrap 3\" src=\"images/joomlart/banners/bootstrap-icon.png\"></p>\r\n  <h3>Bootstrap 3</h3>\r\n  <p>Purity III embraces Bootstrap 3 at core, meaning it also supports Font Awesome 4, as well as all the cool features in Bootstrap 3 Framework</p>\r\n</div>\r\n\r\n<div class=\"col-md-3\">\r\n  <p><img pagespeed_url_hash=\"1616445301\" alt=\"SEO\" src=\"images/joomlart/banners/seo-icon.png\"></p>\r\n  <h3>SEO</h3>\r\n  <p>Great design impresses your visitors, but SEO friendly codes bring visitors, drive more <a target=\"_blank\" href=\"http://www.google.com\">Googlers</a> to yours while you\'re sleeping</p>\r\n</div>\r\n\r\n</div>',4,'features-intro-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(205,446,'Want to be the first to try our Purity III','','<div class=\"container jumbotron masthead\" style=\"margin:0;\">\r\n  <span class=\"section-arrow-alt\"></span>\r\n  <p>Want to be the first to try our Purity III...</p>\r\n<div class=\"btn-actions\">\r\n    <a class=\"btn btn-success btn-lg\" role=\"button\" href=\"http://bit.ly/purity_iii\">Download <span class=\"hidden-phone\">Purity III</span></a>\r\n  </div>\r\n</div>',5,'features-intro-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\" row-feature-primary\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(206,449,'Team members','','<div class=\"media\">\r\n  <a href=\"#\" class=\"pull-left\"><img src=\"images/joomlart/corporate/staff-1.jpg\" alt=\"Sample image\" style=\"width: 60px;\" class=\"img-thumbnail\" /></a>\r\n  <div class=\"media-body\">\r\n  <h4 class=\"media-heading\">Scott Singleton</h4>\r\n    <strong><small>CEO Director</small></strong><br />\r\n    <small><a href=\"mailto:ceo@your-domain.com\">ceo@your-domain.com</a></small>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"media\">\r\n  <a href=\"#\" class=\"pull-left\"><img src=\"images/joomlart/corporate/staff-2.jpg\" alt=\"Sample image\" style=\"width: 60px;\" class=\"img-thumbnail\" /></a>\r\n  <div class=\"media-body\">\r\n  <h4 class=\"media-heading\">Marie Hall</h4>\r\n    <strong><small>Managing Director</small></strong><br />\r\n    <small><a href=\"mailto:sale@your-domain.com\">sale@your-domain.com</a></small>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"media\">\r\n  <a href=\"#\" class=\"pull-left\"><img src=\"images/joomlart/corporate/staff-3.jpg\" alt=\"Sample image\" style=\"width: 60px;\" class=\"img-thumbnail\" /></a>\r\n  <div class=\"media-body\">\r\n  <h4 class=\"media-heading\">Mamie Ray</h4>\r\n    <strong><small>Sales manager</small></strong><br />\r\n    <small><a href=\"mailto:ceo@your-domain.com\">sales@your-domain.com</a></small>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"media\">\r\n  <a href=\"#\" class=\"pull-left\"><img src=\"images/joomlart/corporate/staff-4.jpg\" alt=\"Sample image\" style=\"width: 60px;\" class=\"img-thumbnail\" /></a>\r\n  <div class=\"media-body\">\r\n  <h4 class=\"media-heading\">Johnny Payne</h4>\r\n    <strong><small>Creative director</small></strong><br />\r\n    <small><a href=\"mailto:ceo@your-domain.com\">design@your-domain.com</a></small>\r\n  </div>\r\n</div>',8,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(207,450,'Our partners','','<img src=\"images/joomlart/corporate/partners.gif\" alt=\"Sample image\" class=\"image-reponsive\" />',26,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(210,555,'Compatible Extensions','','<header class=\"jumbotron\">\r\n  <h2>Highly Compatible</h2>\r\n  <p>Purity III is highly compatible with most of the 3rd party Joomla extensions</p>\r\n</header>\r\n\r\n\r\n  <div class=\"col-xs-6 col-md-4\">\r\n    <a class=\"thumbnail\" href=\"index.php/compatible/easyblog\">\r\n      <img src=\"images/joomlart/compatible-extension/easyblog.png\" alt=\"Easy Blog\" />\r\n    </a>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-4\">\r\n    <a class=\"thumbnail\" href=\"index.php/compatible/easysocial\">\r\n      <img src=\"images/joomlart/compatible-extension/easysocial.png\" alt=\"easysocial\" />\r\n    </a>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-4\">\r\n    <a class=\"thumbnail\" href=\"index.php/compatible/discussions\">\r\n      <img src=\"images/joomlart/compatible-extension/easydiscuss.png\" border=\"0\" alt=\"easydiscuss\" />\r\n    </a>\r\n  </div>\r\n\r\n\r\n  <div class=\"col-xs-6 col-md-4\">\r\n    <a class=\"thumbnail\" href=\"index.php/forum/index\">\r\n      <img src=\"images/joomlart/compatible-extension/kunena.png\" border=\"0\" alt=\"Kunena\" />\r\n    </a>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-4\">\r\n    <a class=\"thumbnail\" href=\"index.php/compatible/jomsocial\">\r\n      <img src=\"images/joomlart/compatible-extension/jomsocial.png\" border=\"0\" alt=\"JomSocial\" />\r\n    </a>\r\n  </div>\r\n\r\n  <div class=\"col-xs-6 col-md-4\">\r\n    <a class=\"thumbnail\" href=\"index.php/compatible/mijoshop\">\r\n      <img src=\"images/joomlart/compatible-extension/mijoshop-logo.png\" border=\"0\" alt=\"mijoshop\" />\r\n    </a>\r\n  </div>\r\n\r\n<div class=\"wrap btn-actions text-center\">\r\n    <a class=\"btn btn-primary btn-lg\" role=\"button\" href=\"http://bit.ly/purity_iii\">More detail?</a>\r\n  </div>',2,'features-intro-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(211,564,'Sidebar 1','','<p>Leo Sed nibh ut ac magnis Nam hendrerit lacus convallis massa. Laoreet sed hendrerit et et penatibus tellus et Curabitur lacinia Curabitur. Dis quis semper fringilla Nam pellentesque ipsum id odio scelerisque congue. Et nunc risus Pellentesque sapien malesuada ligula orci tristique adipiscing malesuada. Pede molestie Aenean risus orci id lorem Nullam felis orci velit. </p>\r\n\r\n<p>Hendrerit eu ut id dolor nibh nisl vel augue adipiscing leo. At faucibus Lorem mauris elit Sed vel neque nibh tellus adipiscing. Sagittis dui lacus vitae convallis pretium montes pretium.</p>',1,'sidebar-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(212,565,'Sidebar 2','','<p>Leo Sed nibh ut ac magnis Nam hendrerit lacus convallis massa. Laoreet sed hendrerit et et penatibus tellus et Curabitur lacinia Curabitur. Dis quis semper fringilla Nam pellentesque ipsum id odio scelerisque congue. Et nunc risus Pellentesque sapien malesuada ligula orci tristique adipiscing malesuada. Pede molestie Aenean risus orci id lorem Nullam felis orci velit.</p>\r\n\r\n<p>Porta dapibus laoreet id ut Vestibulum Phasellus magna eros quis gravida. Faucibus Nunc tortor ac enim non ut Nam vitae Nunc ornare. Convallis id nibh id orci ligula Cum nulla Curabitur et aliquam. Auctor augue aliquam magna mi massa parturient Sed Nullam at orci. <a href=\"#\" title=\"Sample link\">Pede nunc condimentum.</a></p>',7,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(213,566,'After content','','<p>Nam pellentesque ipsum id odio scelerisque congue. Et nunc risus Pellentesque sapien malesuada ligula orci tristique adipiscing malesuada. Pede molestie Aenean risus orci id lorem Nullam felis orci velit.</p>',1,'after-content',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(214,567,'Footer 1','','<ul>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n</ul>',1,'footer-1',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(215,568,'Footer 2','','<ul>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n</ul>',1,'footer-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(216,569,'Footer 5','','<ul>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n</ul>',1,'footer-5',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(217,570,'Footer 3','','<ul>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n</ul>',1,'footer-3',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(218,571,'Footer 4','','<ul>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n</ul>',1,'footer-4',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(219,572,'Footer 6','','<ul>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n<li><a href=\"#\" title=\"Sample link\">Sample link</a></li>\r\n</ul>',1,'footer-6',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(221,576,'Purity III and its stunning typography','','<img src=\"images/joomlart/demo/typography.png\" alt=\"Sample image\">',1,'mega',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(224,580,'T3 Framework','','<a href=\"http://demo.t3-framework.org/joomla30/\" class=\"btn btn-block btn-lg btn-default\">Live Demo</a>\r\n<a href=\"http://t3-framework.org/downloads.html\" class=\"btn btn-block btn-lg btn-default\">Download</a>\r\n<a href=\"http://t3-framework.org/whats-new.html\" class=\"btn btn-block btn-lg btn-default\">More Info</a>',2,'off-canvas',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(225,581,'Purity III Template','','<img class=\"img-responsive\" src=\"images/joomlart/demo/responsive.png\" alt=\"Purity iii - The best free responsive Joomla template for Joomla 3\" style=\"margin-bottom: 20px;\" />\r\n\r\n<p class=\"text-center\">Purity III is the best responsive Joomla template that you won\'t get enough of for almost everything...</p>\r\n\r\n<ul class=\"nav nav-pills nav-stacked\">\r\n      <li class=\"active\"><a href=\"http://bit.ly/purity_iii\">Purity III Template</a></li>\r\n      <li class=\"\"><a href=\"/purity_iii/index.php/layout\">Multiple Layouts</a></li>\r\n      <li class=\"\"><a href=\"/purity_iii/index.php/compatible\">Supported 3rd Extensions</a></li>\r\n      <li class=\"\"><a href=\"http://bit.ly/purity_iii\">Download Purity III</a></li>\r\n<li class=\"\"><a href=\"http://bit.ly/purity_iii\">More Info</a></li>\r\n<li class=\"\"><a href=\"http://www.joomlart.com/documentation/joomla-templates/purity-iii\">Documentation</a></li>\r\n<li class=\"\"><a href=\"http://www.joomlart.com/forums/forumdisplay.php?542-Purity-III\">Get Support</a></li>\r\n</ul>',1,'off-canvas',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(226,585,'Purity III video','','<div class=\"jumbotron jumbotron-primary masthead\">\r\n  <div class=\"col-md-6\" align=\"left\">\r\n    <h1>I\'m Purity III</h1>\r\n    <p>The best free Joomla template that you ever need.</p>\r\n    <div class=\"btn-actions\" style=\"margin-bottom: 20px;\"><p><a href=\"http://bit.ly/purity_iii\" class=\"btn btn-success btn-lg\">Download Now</a></p></div>\r\n  </div>\r\n\r\n  <div class=\"col-md-6\">\r\n    <div class=\"video-wrapper\">\r\n      <iframe width=\"560\" height=\"315\" frameborder=\"0\" src=\"//www.youtube.com/embed/KSK2OR9pEUY?modestbranding=1&amp;;showinfo=0&amp;;autohide=1&amp;;rel=0&amp;;hd=1&amp;html5=1\" allowfullscreen=\"\"></iframe>\r\n    </div>\r\n  </div>\r\n</div>',1,'masthead',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\" row-feature-primary\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\",\"masthead-title\":\"Masthead title\",\"masthead-slogan\":\"\"}',0,'*'),(228,591,'Portfolio Articles ','','',15,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',-2,'mod_articles_category',1,1,'{\"mode\":\"normal\",\"show_on_article_page\":\"1\",\"show_front\":\"show\",\"count\":\"5\",\"category_filtering_type\":\"1\",\"catid\":[\"83\"],\"show_child_category_articles\":\"0\",\"levels\":\"2\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.title\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"0\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"0\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(229,593,'Sample Profiles','','<ul class=\"nav nav-pills nav-stacked\">\r\n<li><a href=\"index.php?option=com_joomprofile&view=profile&task=user.display&id=553&Itemid=765\">Profile 1</a></li>\r\n<li><a href=\"index.php?option=com_joomprofile&view=profile&task=user.display&id=550&Itemid=765\">Profile 2</a></li>\r\n<li><a href=\"index.php?option=com_joomprofile&view=profile&task=user.display&id=548&Itemid=765\">Profile 3</a></li>\r\n<li><a href=\"index.php?option=com_joomprofile&view=profile&task=user.display&id=549&Itemid=765\">Profile 4</a></li>\r\n<li><a href=\"index.php?option=com_joomprofile&view=profile&task=user.display&id=551&Itemid=765\">Profile 5</a></li>\r\n</ul>',3,'sidebar-2',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*');
/*!40000 ALTER TABLE `pro_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_modules_menu`
--

DROP TABLE IF EXISTS `pro_modules_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_modules_menu`
--

LOCK TABLES `pro_modules_menu` WRITE;
/*!40000 ALTER TABLE `pro_modules_menu` DISABLE KEYS */;
INSERT INTO `pro_modules_menu` VALUES (1,537),(1,548),(1,550),(1,551),(1,558),(1,566),(1,652),(1,653),(1,744),(2,0),(3,0),(4,0),(6,0),(7,0),(8,0),(9,0),(10,0),(12,0),(13,0),(14,0),(15,0),(16,537),(16,540),(16,542),(16,545),(16,549),(16,567),(16,653),(16,744),(16,765),(17,0),(19,201),(19,207),(19,444),(19,449),(19,450),(19,464),(19,468),(19,469),(19,540),(19,542),(19,543),(20,0),(22,234),(22,238),(22,242),(22,243),(22,244),(22,296),(22,399),(22,400),(23,-463),(23,-462),(23,-433),(23,-432),(23,-431),(23,-430),(23,-429),(23,-427),(23,-400),(23,-399),(23,-296),(23,-244),(23,-243),(23,-242),(23,-238),(23,-234),(25,294),(26,435),(26,533),(26,540),(26,542),(26,543),(26,545),(26,567),(26,568),(26,569),(26,570),(26,652),(26,653),(26,694),(27,325),(27,694),(29,302),(30,410),(31,558),(31,744),(32,309),(33,307),(34,326),(35,306),(37,311),(38,300),(39,545),(39,709),(40,313),(41,0),(45,540),(45,709),(47,231),(47,234),(47,242),(47,243),(47,244),(47,296),(47,399),(47,400),(48,418),(57,238),(57,427),(57,429),(57,430),(57,431),(57,432),(57,433),(57,462),(57,463),(58,427),(58,429),(58,430),(58,431),(58,432),(58,433),(58,462),(58,463),(61,537),(61,540),(61,542),(61,545),(61,653),(63,0),(65,427),(65,429),(65,430),(65,431),(65,432),(65,433),(65,462),(65,463),(68,243),(70,285),(70,316),(71,285),(71,316),(72,285),(72,316),(73,285),(73,316),(74,285),(74,316),(75,285),(75,316),(79,0),(84,467),(86,0),(87,534),(87,538),(88,534),(88,538),(89,238),(89,427),(89,429),(89,430),(89,431),(89,432),(89,433),(89,462),(89,463),(90,568),(92,568),(93,568),(94,567),(95,567),(96,0),(97,0),(98,0),(99,0),(100,0),(101,536),(101,540),(102,536),(102,540),(103,536),(103,540),(104,536),(104,540),(105,536),(106,536),(107,536),(108,536),(112,0),(113,537),(113,548),(113,558),(113,652),(113,653),(114,0),(119,0),(120,0),(121,0),(124,0),(125,0),(126,0),(127,0),(128,0),(129,0),(130,0),(141,0),(142,0),(143,0),(158,693),(159,693),(160,693),(161,693),(163,694),(163,709),(163,744),(165,694),(166,694),(166,744),(167,0),(168,567),(169,634),(170,634),(171,634),(172,634),(177,568),(178,568),(179,568),(182,568),(183,568),(184,568),(185,568),(189,568),(190,568),(191,568),(192,567),(193,567),(194,567),(195,567),(196,567),(197,567),(198,567),(199,567),(200,721),(202,721),(203,721),(204,721),(205,721),(206,549),(206,568),(206,744),(207,568),(210,0),(211,536),(212,536),(213,536),(214,536),(215,536),(216,536),(217,536),(218,536),(219,536),(221,0),(224,0),(225,0),(226,570),(228,0),(229,765),(230,0),(231,0),(232,0),(233,0),(234,0),(235,0),(236,0),(237,0),(238,0),(239,0),(242,0),(243,0),(255,0),(256,0),(257,0),(258,0),(259,0),(260,0),(261,0),(262,0),(263,0),(264,0),(265,0),(266,0),(267,0),(268,0),(269,0),(270,0),(271,0),(272,0),(273,0),(274,0),(275,0),(276,0),(277,0),(278,0),(279,0),(281,0),(282,0),(283,707),(283,710),(283,711),(283,712),(283,713),(284,707),(284,710),(284,711),(284,712),(284,713),(284,745),(285,707),(285,710),(285,711),(285,712),(285,713),(285,745),(286,707),(286,710),(286,711),(286,712),(286,745),(287,707),(287,710),(287,711),(287,712),(287,713),(288,707),(288,710),(288,711),(288,712),(288,713),(289,0),(290,0),(291,0),(292,0),(293,0),(294,0),(295,0),(296,0),(297,0),(298,0),(299,0),(300,0),(301,0),(302,0),(303,0),(304,0),(305,0),(306,0),(307,0),(308,0),(309,0),(310,0),(311,0),(312,0),(313,0),(314,0),(315,0),(316,0),(317,0);
/*!40000 ALTER TABLE `pro_modules_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_newsfeeds`
--

DROP TABLE IF EXISTS `pro_newsfeeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `link` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `images` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_newsfeeds`
--

LOCK TABLES `pro_newsfeeds` WRITE;
/*!40000 ALTER TABLE `pro_newsfeeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_newsfeeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_overrider`
--

DROP TABLE IF EXISTS `pro_overrider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `string` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_overrider`
--

LOCK TABLES `pro_overrider` WRITE;
/*!40000 ALTER TABLE `pro_overrider` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_overrider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_postinstall_messages`
--

DROP TABLE IF EXISTS `pro_postinstall_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_postinstall_messages` (
  `postinstall_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language_extension` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`postinstall_message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_postinstall_messages`
--

LOCK TABLES `pro_postinstall_messages` WRITE;
/*!40000 ALTER TABLE `pro_postinstall_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_postinstall_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_redirect_links`
--

DROP TABLE IF EXISTS `pro_redirect_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `header` smallint(3) NOT NULL DEFAULT '301',
  PRIMARY KEY (`id`),
  KEY `idx_link_modifed` (`modified_date`),
  KEY `idx_old_url` (`old_url`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_redirect_links`
--

LOCK TABLES `pro_redirect_links` WRITE;
/*!40000 ALTER TABLE `pro_redirect_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_redirect_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_schemas`
--

DROP TABLE IF EXISTS `pro_schemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_schemas`
--

LOCK TABLES `pro_schemas` WRITE;
/*!40000 ALTER TABLE `pro_schemas` DISABLE KEYS */;
INSERT INTO `pro_schemas` VALUES (700,'3.6.3-2016-08-16');
/*!40000 ALTER TABLE `pro_schemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_session`
--

DROP TABLE IF EXISTS `pro_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_session` (
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` longtext COLLATE utf8mb4_unicode_ci,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_session`
--

LOCK TABLES `pro_session` WRITE;
/*!40000 ALTER TABLE `pro_session` DISABLE KEYS */;
INSERT INTO `pro_session` VALUES ('623197866acfd7c67a04ea5b850e3c21',1,0,'1491107268','joomla|s:1176:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjM6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjo0OntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjM6e3M6NzoiY291bnRlciI7aToyMTtzOjU6InRpbWVyIjtPOjg6InN0ZENsYXNzIjozOntzOjU6InN0YXJ0IjtpOjE0OTExMDcwNjY7czo0OiJsYXN0IjtpOjE0OTExMDcyNTU7czozOiJub3ciO2k6MTQ5MTEwNzI1Njt9czo1OiJ0b2tlbiI7czozMjoiWXpFS0tNVHh4UFJLWjNIN0kyM1NSRHBhTmJUdUlLODciO31zOjg6InJlZ2lzdHJ5IjtPOjI0OiJKb29tbGFcUmVnaXN0cnlcUmVnaXN0cnkiOjM6e3M6NzoiACoAZGF0YSI7Tzo4OiJzdGRDbGFzcyI6Mjp7czoxMToiYXBwbGljYXRpb24iO086ODoic3RkQ2xhc3MiOjE6e3M6NDoibGFuZyI7czo1OiJ6aC1DTiI7fXM6MTM6ImNvbV9pbnN0YWxsZXIiO086ODoic3RkQ2xhc3MiOjI6e3M6NzoibWVzc2FnZSI7czowOiIiO3M6MTc6ImV4dGVuc2lvbl9tZXNzYWdlIjtzOjA6IiI7fX1zOjE0OiIAKgBpbml0aWFsaXplZCI7YjoxO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO31zOjQ6InVzZXIiO086NToiSlVzZXIiOjE6e3M6MjoiaWQiO3M6MjoiNDIiO31zOjExOiJhcHBsaWNhdGlvbiI7Tzo4OiJzdGRDbGFzcyI6MTp7czo1OiJxdWV1ZSI7Tjt9fXM6ODoiX19ha2VlYmEiO086ODoic3RkQ2xhc3MiOjE6e3M6NzoicHJvZmlsZSI7aToxO31zOjEyOiJfX2NvbV9ha2VlYmEiO086ODoic3RkQ2xhc3MiOjE6e3M6MjQ6Im1hZ2ljUGFyYW1zVXBkYXRlVmVyc2lvbiI7czo1OiI1LjMuMSI7fX1zOjE0OiIAKgBpbml0aWFsaXplZCI7YjowO3M6OToic2VwYXJhdG9yIjtzOjE6Ii4iO30=\";',42,'mawenqiang');
/*!40000 ALTER TABLE `pro_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_access`
--

DROP TABLE IF EXISTS `pro_social_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_access`
--

LOCK TABLES `pro_social_access` WRITE;
/*!40000 ALTER TABLE `pro_social_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_access_logs`
--

DROP TABLE IF EXISTS `pro_social_access_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_access_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rule` varchar(255) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `utype` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rule` (`rule`),
  KEY `idx_userid` (`user_id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_utypes` (`uid`,`utype`),
  KEY `idx_created` (`created`),
  KEY `idx_useritems` (`rule`,`user_id`,`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_access_logs`
--

LOCK TABLES `pro_social_access_logs` WRITE;
/*!40000 ALTER TABLE `pro_social_access_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_access_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_access_rules`
--

DROP TABLE IF EXISTS `pro_social_access_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_access_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `extension` varchar(255) NOT NULL,
  `element` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state` (`state`),
  KEY `extension` (`extension`),
  KEY `element` (`element`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_access_rules`
--

LOCK TABLES `pro_social_access_rules` WRITE;
/*!40000 ALTER TABLE `pro_social_access_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_access_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_albums`
--

DROP TABLE IF EXISTS `pro_social_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cover_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `caption` text NOT NULL,
  `created` datetime NOT NULL,
  `assigned_date` datetime NOT NULL,
  `ordering` tinyint(3) NOT NULL,
  `params` text NOT NULL,
  `core` tinyint(3) NOT NULL,
  `hits` int(11) NOT NULL,
  `notified` tinyint(1) NOT NULL,
  `finalized` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`),
  KEY `user_id` (`user_id`),
  KEY `idx_albums_user_assigned` (`uid`,`type`,`assigned_date`),
  KEY `idx_core` (`core`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_albums`
--

LOCK TABLES `pro_social_albums` WRITE;
/*!40000 ALTER TABLE `pro_social_albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_albums_favourite`
--

DROP TABLE IF EXISTS `pro_social_albums_favourite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_albums_favourite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_albums_favourite`
--

LOCK TABLES `pro_social_albums_favourite` WRITE;
/*!40000 ALTER TABLE `pro_social_albums_favourite` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_albums_favourite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_alert`
--

DROP TABLE IF EXISTS `pro_social_alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_alert` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `extension` varchar(255) NOT NULL,
  `element` varchar(255) NOT NULL,
  `rule` varchar(255) NOT NULL,
  `email` int(1) NOT NULL DEFAULT '1',
  `system` int(1) NOT NULL DEFAULT '1',
  `core` int(1) NOT NULL DEFAULT '0',
  `app` int(1) NOT NULL DEFAULT '0',
  `field` tinyint(3) NOT NULL DEFAULT '0',
  `group` varchar(255) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_alert_field` (`field`),
  KEY `idx_alert_published` (`published`),
  KEY `idx_alert_element` (`element`),
  KEY `idx_alert_rule` (`rule`),
  KEY `idx_alert_published_field` (`published`,`field`),
  KEY `idx_alert_isfield` (`published`,`field`,`element`(64),`rule`(64))
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_alert`
--

LOCK TABLES `pro_social_alert` WRITE;
/*!40000 ALTER TABLE `pro_social_alert` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_alert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_alert_map`
--

DROP TABLE IF EXISTS `pro_social_alert_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_alert_map` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT '0',
  `alert_id` bigint(20) NOT NULL,
  `email` int(1) DEFAULT '1',
  `system` int(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_alertmap_alertid` (`alert_id`),
  KEY `idx_alertmap_userid` (`user_id`),
  KEY `idx_alertmap_alertuser` (`alert_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_alert_map`
--

LOCK TABLES `pro_social_alert_map` WRITE;
/*!40000 ALTER TABLE `pro_social_alert_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_alert_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_apps`
--

DROP TABLE IF EXISTS `pro_social_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `core` tinyint(4) NOT NULL DEFAULT '0',
  `system` tinyint(3) NOT NULL DEFAULT '0',
  `unique` tinyint(4) NOT NULL DEFAULT '0',
  `default` tinyint(3) NOT NULL,
  `type` varchar(255) NOT NULL COMMENT 'It could be widgets,fields or applications',
  `element` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  `params` text NOT NULL,
  `version` varchar(255) NOT NULL,
  `widget` tinyint(3) NOT NULL,
  `visible` tinyint(4) NOT NULL DEFAULT '1',
  `installable` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state` (`state`),
  KEY `type` (`type`),
  KEY `core` (`core`),
  KEY `idx_default_widget` (`state`,`group`,`widget`,`default`),
  KEY `idx_group` (`group`),
  KEY `idx_apps_element` (`element`),
  KEY `idx_apps_type_group` (`type`(64),`group`(64))
) ENGINE=MyISAM AUTO_INCREMENT=222 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_apps`
--

LOCK TABLES `pro_social_apps` WRITE;
/*!40000 ALTER TABLE `pro_social_apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_apps_access`
--

DROP TABLE IF EXISTS `pro_social_apps_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_apps_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_apps_access`
--

LOCK TABLES `pro_social_apps_access` WRITE;
/*!40000 ALTER TABLE `pro_social_apps_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_apps_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_apps_calendar`
--

DROP TABLE IF EXISTS `pro_social_apps_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_apps_calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `reminder` tinyint(3) NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `all_day` tinyint(3) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_apps_calendar`
--

LOCK TABLES `pro_social_apps_calendar` WRITE;
/*!40000 ALTER TABLE `pro_social_apps_calendar` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_apps_calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_apps_directory`
--

DROP TABLE IF EXISTS `pro_social_apps_directory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_apps_directory` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `info` text NOT NULL,
  `price` varchar(255) NOT NULL,
  `logo` text NOT NULL,
  `element` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `permalink` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `download` tinyint(3) NOT NULL,
  `version_checking` tinyint(3) NOT NULL,
  `raw` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_apps_directory`
--

LOCK TABLES `pro_social_apps_directory` WRITE;
/*!40000 ALTER TABLE `pro_social_apps_directory` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_apps_directory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_apps_map`
--

DROP TABLE IF EXISTS `pro_social_apps_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_apps_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `app_id` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_app_uid_type` (`app_id`,`uid`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_apps_map`
--

LOCK TABLES `pro_social_apps_map` WRITE;
/*!40000 ALTER TABLE `pro_social_apps_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_apps_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_apps_store`
--

DROP TABLE IF EXISTS `pro_social_apps_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_apps_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `info` text NOT NULL,
  `price` varchar(255) NOT NULL,
  `logo` text NOT NULL,
  `element` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `permalink` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `download` tinyint(3) NOT NULL,
  `download_api` tinyint(3) NOT NULL,
  `version_checking` tinyint(3) NOT NULL,
  `raw` text NOT NULL,
  `ratings` int(11) NOT NULL,
  `votes` int(11) NOT NULL,
  `payment` tinyint(3) NOT NULL,
  `featured` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_apps_store`
--

LOCK TABLES `pro_social_apps_store` WRITE;
/*!40000 ALTER TABLE `pro_social_apps_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_apps_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_apps_views`
--

DROP TABLE IF EXISTS `pro_social_apps_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_apps_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `view` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_app_view` (`app_id`,`view`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_apps_views`
--

LOCK TABLES `pro_social_apps_views` WRITE;
/*!40000 ALTER TABLE `pro_social_apps_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_apps_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_avatars`
--

DROP TABLE IF EXISTS `pro_social_avatars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_avatars` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary ID',
  `uid` int(11) NOT NULL COMMENT 'Node''s ID',
  `type` varchar(255) NOT NULL,
  `avatar_id` bigint(20) NOT NULL COMMENT 'If the node is using a default avatar, this field will be populated with an id.',
  `photo_id` int(11) NOT NULL COMMENT 'If the avatar is created from a photo, this field will be populated with the photo id.',
  `small` text NOT NULL,
  `medium` text NOT NULL,
  `square` text NOT NULL,
  `large` text NOT NULL,
  `modified` datetime NOT NULL,
  `storage` varchar(255) NOT NULL DEFAULT 'joomla',
  PRIMARY KEY (`id`),
  KEY `avatar_id` (`avatar_id`),
  KEY `photo_id` (`photo_id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_uid_type` (`uid`,`type`),
  KEY `idx_storage_cron` (`storage`,`avatar_id`,`small`(64)),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_avatars`
--

LOCK TABLES `pro_social_avatars` WRITE;
/*!40000 ALTER TABLE `pro_social_avatars` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_avatars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_badges`
--

DROP TABLE IF EXISTS `pro_social_badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_badges` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `command` varchar(255) NOT NULL,
  `extension` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `howto` text NOT NULL,
  `avatar` text NOT NULL,
  `created` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `frequency` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discuss_badges_alias` (`alias`),
  KEY `discuss_badges_published` (`state`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_badges`
--

LOCK TABLES `pro_social_badges` WRITE;
/*!40000 ALTER TABLE `pro_social_badges` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_badges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_badges_history`
--

DROP TABLE IF EXISTS `pro_social_badges_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_badges_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `badge_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `achieved` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_badges_history`
--

LOCK TABLES `pro_social_badges_history` WRITE;
/*!40000 ALTER TABLE `pro_social_badges_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_badges_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_badges_maps`
--

DROP TABLE IF EXISTS `pro_social_badges_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_badges_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `badge_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `custom_message` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `badge_id` (`badge_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_badges_maps`
--

LOCK TABLES `pro_social_badges_maps` WRITE;
/*!40000 ALTER TABLE `pro_social_badges_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_badges_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_block_users`
--

DROP TABLE IF EXISTS `pro_social_block_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_block_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`target_id`),
  KEY `idx_userid` (`user_id`),
  KEY `idx_targetid` (`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_block_users`
--

LOCK TABLES `pro_social_block_users` WRITE;
/*!40000 ALTER TABLE `pro_social_block_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_block_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_bookmarks`
--

DROP TABLE IF EXISTS `pro_social_bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary key',
  `uid` int(11) NOT NULL COMMENT 'The bookmarked item id',
  `type` varchar(255) NOT NULL COMMENT 'The bookmarked type',
  `created` datetime NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'The owner of the bookmarked item',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`),
  KEY `user_id` (`user_id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_user_utype` (`uid`,`type`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_bookmarks`
--

LOCK TABLES `pro_social_bookmarks` WRITE;
/*!40000 ALTER TABLE `pro_social_bookmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_broadcasts`
--

DROP TABLE IF EXISTS `pro_social_broadcasts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_broadcasts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` int(11) NOT NULL,
  `target_type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `link` text NOT NULL,
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `expiry_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_broadcast` (`target_id`,`target_type`,`state`,`created`),
  KEY `idx_created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_broadcasts`
--

LOCK TABLES `pro_social_broadcasts` WRITE;
/*!40000 ALTER TABLE `pro_social_broadcasts` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_broadcasts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_clusters`
--

DROP TABLE IF EXISTS `pro_social_clusters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_clusters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `cluster_type` varchar(255) NOT NULL,
  `creator_type` varchar(255) NOT NULL,
  `creator_uid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `featured` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  `params` text NOT NULL,
  `hits` int(11) NOT NULL,
  `type` tinyint(3) NOT NULL,
  `key` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `parent_type` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL COMMENT 'The longitude value of the event for proximity search purposes',
  `latitude` varchar(255) NOT NULL COMMENT 'The latitude value of the event for proximity search purposes',
  `address` text NOT NULL COMMENT 'The full address value of the event for displaying purposes',
  `notification` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `featured` (`featured`),
  KEY `idx_state` (`state`),
  KEY `idx_clustertype` (`cluster_type`),
  KEY `idx_user_cluster` (`creator_uid`,`creator_type`(64),`cluster_type`(64))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_clusters`
--

LOCK TABLES `pro_social_clusters` WRITE;
/*!40000 ALTER TABLE `pro_social_clusters` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_clusters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_clusters_categories`
--

DROP TABLE IF EXISTS `pro_social_clusters_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_clusters_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `uid` int(11) NOT NULL COMMENT 'The creator of the category',
  `ordering` tinyint(3) NOT NULL,
  `site_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_clusters_categories`
--

LOCK TABLES `pro_social_clusters_categories` WRITE;
/*!40000 ALTER TABLE `pro_social_clusters_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_clusters_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_clusters_categories_access`
--

DROP TABLE IF EXISTS `pro_social_clusters_categories_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_clusters_categories_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'create',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`,`profile_id`),
  KEY `category_id_2` (`category_id`,`profile_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_clusters_categories_access`
--

LOCK TABLES `pro_social_clusters_categories_access` WRITE;
/*!40000 ALTER TABLE `pro_social_clusters_categories_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_clusters_categories_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_clusters_news`
--

DROP TABLE IF EXISTS `pro_social_clusters_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_clusters_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cluster_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `hits` int(11) NOT NULL,
  `comments` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cluster_id` (`cluster_id`,`created_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_clusters_news`
--

LOCK TABLES `pro_social_clusters_news` WRITE;
/*!40000 ALTER TABLE `pro_social_clusters_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_clusters_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_clusters_nodes`
--

DROP TABLE IF EXISTS `pro_social_clusters_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_clusters_nodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cluster_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `state` tinyint(4) NOT NULL,
  `owner` tinyint(3) NOT NULL,
  `admin` tinyint(3) NOT NULL,
  `invited_by` int(11) NOT NULL,
  `reminder_sent` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cluster_id` (`cluster_id`,`state`),
  KEY `invited_by` (`invited_by`),
  KEY `idx_clusters_nodes_uid` (`uid`),
  KEY `idx_clusters_nodes_user` (`uid`,`state`,`created`),
  KEY `idx_members` (`cluster_id`,`type`,`state`),
  KEY `idx_reminder_sent` (`reminder_sent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_clusters_nodes`
--

LOCK TABLES `pro_social_clusters_nodes` WRITE;
/*!40000 ALTER TABLE `pro_social_clusters_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_clusters_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_clusters_reject`
--

DROP TABLE IF EXISTS `pro_social_clusters_reject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_clusters_reject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `cluster_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cluster_id` (`cluster_id`),
  KEY `idx_created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_clusters_reject`
--

LOCK TABLES `pro_social_clusters_reject` WRITE;
/*!40000 ALTER TABLE `pro_social_clusters_reject` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_clusters_reject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_comments`
--

DROP TABLE IF EXISTS `pro_social_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `element` varchar(255) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `comment` text NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL,
  `depth` bigint(10) DEFAULT '0',
  `parent` bigint(20) DEFAULT '0',
  `child` bigint(20) DEFAULT '0',
  `lft` bigint(20) DEFAULT '0',
  `rgt` bigint(20) DEFAULT '0',
  `stream_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `social_comments_uid` (`uid`),
  KEY `social_comments_type` (`element`),
  KEY `social_comments_createdby` (`created_by`),
  KEY `social_comments_content_type` (`element`,`uid`),
  KEY `social_comments_content_type_by` (`element`,`uid`,`created_by`),
  KEY `social_comments_content_parent` (`element`,`uid`,`parent`),
  KEY `idx_comment_batch` (`stream_id`,`element`,`uid`),
  KEY `idx_comment_stream_id` (`stream_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_comments`
--

LOCK TABLES `pro_social_comments` WRITE;
/*!40000 ALTER TABLE `pro_social_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_config`
--

DROP TABLE IF EXISTS `pro_social_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_config` (
  `type` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `value_binary` blob,
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_config`
--

LOCK TABLES `pro_social_config` WRITE;
/*!40000 ALTER TABLE `pro_social_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_conversations`
--

DROP TABLE IF EXISTS `pro_social_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_conversations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `lastreplied` datetime NOT NULL,
  `type` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_conversations`
--

LOCK TABLES `pro_social_conversations` WRITE;
/*!40000 ALTER TABLE `pro_social_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_conversations_message`
--

DROP TABLE IF EXISTS `pro_social_conversations_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_conversations_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `conversation_id` bigint(20) NOT NULL,
  `type` varchar(200) NOT NULL,
  `message` text,
  `created` datetime NOT NULL,
  `created_by` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conversation_id` (`conversation_id`),
  KEY `created_by` (`created_by`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_conversations_message`
--

LOCK TABLES `pro_social_conversations_message` WRITE;
/*!40000 ALTER TABLE `pro_social_conversations_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_conversations_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_conversations_message_maps`
--

DROP TABLE IF EXISTS `pro_social_conversations_message_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_conversations_message_maps` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `conversation_id` bigint(20) NOT NULL,
  `message_id` bigint(20) NOT NULL,
  `isread` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 - publish, 2 - archive, 3 - trash',
  PRIMARY KEY (`id`),
  KEY `node_id` (`user_id`),
  KEY `conversation_id` (`conversation_id`),
  KEY `message_id` (`message_id`),
  KEY `idx_user_conversation` (`user_id`,`state`,`conversation_id`,`message_id`),
  KEY `idx_user_conversation_isread` (`user_id`,`state`,`isread`,`conversation_id`,`message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_conversations_message_maps`
--

LOCK TABLES `pro_social_conversations_message_maps` WRITE;
/*!40000 ALTER TABLE `pro_social_conversations_message_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_conversations_message_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_conversations_participants`
--

DROP TABLE IF EXISTS `pro_social_conversations_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_conversations_participants` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `conversation_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `state` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `social_conversation_maps_conversation_id` (`conversation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_conversations_participants`
--

LOCK TABLES `pro_social_conversations_participants` WRITE;
/*!40000 ALTER TABLE `pro_social_conversations_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_conversations_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_covers`
--

DROP TABLE IF EXISTS `pro_social_covers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_covers` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary ID',
  `uid` int(11) NOT NULL COMMENT 'Node''s ID',
  `type` varchar(255) NOT NULL,
  `photo_id` int(13) NOT NULL COMMENT 'If the node is using a default avatar, this field will be populated with an id.',
  `cover_id` int(11) NOT NULL,
  `x` varchar(255) NOT NULL,
  `y` varchar(255) NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `avatar_id` (`photo_id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_uid_type` (`uid`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_covers`
--

LOCK TABLES `pro_social_covers` WRITE;
/*!40000 ALTER TABLE `pro_social_covers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_covers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_default_avatars`
--

DROP TABLE IF EXISTS `pro_social_default_avatars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_default_avatars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` text,
  `created` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `large` text NOT NULL,
  `medium` text NOT NULL,
  `small` text NOT NULL,
  `square` text NOT NULL,
  `default` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`),
  KEY `system` (`default`),
  KEY `state` (`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_default_avatars`
--

LOCK TABLES `pro_social_default_avatars` WRITE;
/*!40000 ALTER TABLE `pro_social_default_avatars` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_default_avatars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_default_covers`
--

DROP TABLE IF EXISTS `pro_social_default_covers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_default_covers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` text,
  `created` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `large` text NOT NULL,
  `small` text NOT NULL,
  `default` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`type`),
  KEY `system` (`default`),
  KEY `state` (`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_default_covers`
--

LOCK TABLES `pro_social_default_covers` WRITE;
/*!40000 ALTER TABLE `pro_social_default_covers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_default_covers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_discussions`
--

DROP TABLE IF EXISTS `pro_social_discussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_discussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'This determines if this is a reply to a discussion. If it is a reply, it should contain the parent''s id here.',
  `uid` int(11) NOT NULL COMMENT 'The unique id this discussion is associated to. For example, if it is associated with a group, it should store the group''s id.',
  `type` varchar(255) NOT NULL COMMENT 'The unique type this discussion is associated to. For example, if it is associated with a group, it should store the type as group',
  `answer_id` int(11) NOT NULL COMMENT 'This is only applicable to main question. This should contain the reference to the discussion that is an answer.',
  `last_reply_id` int(11) NOT NULL COMMENT 'Determines the last reply for the discussion',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0' COMMENT 'Stores the total views for this discussion.',
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  `last_replied` datetime NOT NULL COMMENT 'Stores the last replied date time.',
  `votes` int(11) NOT NULL COMMENT 'Determines the vote count for this discussion.',
  `total_replies` int(11) NOT NULL DEFAULT '0' COMMENT 'This is to denormalize the reply count of a discussion.',
  `lock` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Determines if this discussion is locked',
  `params` text NOT NULL COMMENT 'Stores additional raw parameters for the discussion that doesn''t need to be indexed',
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `uid_2` (`uid`,`type`),
  KEY `id` (`id`,`parent_id`),
  KEY `id_2` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_discussions`
--

LOCK TABLES `pro_social_discussions` WRITE;
/*!40000 ALTER TABLE `pro_social_discussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_discussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_discussions_files`
--

DROP TABLE IF EXISTS `pro_social_discussions_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_discussions_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_id` int(11) NOT NULL,
  `discussion_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`,`discussion_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_discussions_files`
--

LOCK TABLES `pro_social_discussions_files` WRITE;
/*!40000 ALTER TABLE `pro_social_discussions_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_discussions_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_events_meta`
--

DROP TABLE IF EXISTS `pro_social_events_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_events_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cluster_id` int(11) NOT NULL COMMENT 'The event cluster id',
  `start` datetime NOT NULL COMMENT 'The start datetime of the event',
  `end` datetime NOT NULL COMMENT 'The end datetime of the event',
  `timezone` varchar(255) NOT NULL COMMENT 'The optional timezone of the event for datetime calculation',
  `all_day` tinyint(3) NOT NULL COMMENT 'Flag if this event is an all day event',
  `group_id` int(11) NOT NULL COMMENT 'The group id if this is a group event',
  `reminder` int(11) DEFAULT '0',
  `start_gmt` datetime NOT NULL,
  `end_gmt` datetime NOT NULL,
  `page_id` int(11) NOT NULL COMMENT 'The page id if this is a page event',
  PRIMARY KEY (`id`),
  KEY `cluster_id` (`cluster_id`),
  KEY `idx_reminder` (`reminder`),
  KEY `idx_upcoming_reminder` (`reminder`,`start`),
  KEY `idx_start` (`start`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_events_meta`
--

LOCK TABLES `pro_social_events_meta` WRITE;
/*!40000 ALTER TABLE `pro_social_events_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_events_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_feeds`
--

DROP TABLE IF EXISTS `pro_social_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `url` text NOT NULL,
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_feeds`
--

LOCK TABLES `pro_social_feeds` WRITE;
/*!40000 ALTER TABLE `pro_social_feeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_fields`
--

DROP TABLE IF EXISTS `pro_social_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_key` text NOT NULL,
  `app_id` int(11) NOT NULL,
  `step_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `display_title` tinyint(3) NOT NULL,
  `description` text NOT NULL,
  `display_description` tinyint(3) NOT NULL,
  `default` text NOT NULL,
  `validation` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '1',
  `searchable` tinyint(4) NOT NULL DEFAULT '1',
  `required` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `ordering` tinyint(4) NOT NULL DEFAULT '0',
  `core` tinyint(4) NOT NULL DEFAULT '0',
  `visible_registration` tinyint(3) NOT NULL,
  `visible_edit` tinyint(3) NOT NULL,
  `visible_display` tinyint(3) NOT NULL,
  `friend_suggest` tinyint(4) DEFAULT '0',
  `visible_mini_registration` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_id` (`app_id`),
  KEY `required` (`required`),
  KEY `searchable` (`searchable`),
  KEY `state` (`state`),
  KEY `step_id` (`step_id`),
  KEY `friend_suggest` (`friend_suggest`),
  KEY `idx_advanced_search1` (`searchable`,`state`,`ordering`),
  KEY `idx_unique_key` (`unique_key`(64))
) ENGINE=MyISAM AUTO_INCREMENT=203 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_fields`
--

LOCK TABLES `pro_social_fields` WRITE;
/*!40000 ALTER TABLE `pro_social_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_fields_data`
--

DROP TABLE IF EXISTS `pro_social_fields_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_fields_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `datakey` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `params` text NOT NULL,
  `raw` text,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`,`uid`),
  KEY `node_id` (`uid`),
  KEY `idx_uid_type` (`uid`,`type`),
  KEY `idx_type_raw` (`type`(25),`raw`(255)),
  KEY `idx_type_key_raw` (`type`(25),`datakey`(50),`raw`(255)),
  FULLTEXT KEY `fields_data_raw` (`raw`)
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_fields_data`
--

LOCK TABLES `pro_social_fields_data` WRITE;
/*!40000 ALTER TABLE `pro_social_fields_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_fields_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_fields_options`
--

DROP TABLE IF EXISTS `pro_social_fields_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_fields_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `ordering` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_parents` (`parent_id`,`key`),
  KEY `idx_parentid` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_fields_options`
--

LOCK TABLES `pro_social_fields_options` WRITE;
/*!40000 ALTER TABLE `pro_social_fields_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_fields_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_fields_position`
--

DROP TABLE IF EXISTS `pro_social_fields_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_fields_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `position` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_fields_position`
--

LOCK TABLES `pro_social_fields_position` WRITE;
/*!40000 ALTER TABLE `pro_social_fields_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_fields_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_fields_rules`
--

DROP TABLE IF EXISTS `pro_social_fields_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_fields_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `match_text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `field_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_fields_rules`
--

LOCK TABLES `pro_social_fields_rules` WRITE;
/*!40000 ALTER TABLE `pro_social_fields_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_fields_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_fields_steps`
--

DROP TABLE IF EXISTS `pro_social_fields_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_fields_steps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `state` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `sequence` int(11) NOT NULL,
  `visible_registration` tinyint(3) NOT NULL,
  `visible_edit` tinyint(3) NOT NULL,
  `visible_display` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `workflow_id` (`uid`),
  KEY `state` (`state`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_fields_steps`
--

LOCK TABLES `pro_social_fields_steps` WRITE;
/*!40000 ALTER TABLE `pro_social_fields_steps` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_fields_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_files`
--

DROP TABLE IF EXISTS `pro_social_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `hits` int(11) NOT NULL,
  `hash` text NOT NULL,
  `uid` int(11) NOT NULL,
  `type` text NOT NULL,
  `created` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `size` text NOT NULL,
  `mime` text NOT NULL,
  `state` tinyint(3) NOT NULL,
  `storage` varchar(255) NOT NULL DEFAULT 'joomla',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `collection_id` (`collection_id`),
  KEY `idx_storage_cron` (`storage`,`created`),
  KEY `idx_created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_files`
--

LOCK TABLES `pro_social_files` WRITE;
/*!40000 ALTER TABLE `pro_social_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_files_collections`
--

DROP TABLE IF EXISTS `pro_social_files_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_files_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `owner_type` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'This is the person that creates the item.',
  `title` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_files_collections`
--

LOCK TABLES `pro_social_files_collections` WRITE;
/*!40000 ALTER TABLE `pro_social_files_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_files_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_friends`
--

DROP TABLE IF EXISTS `pro_social_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_friends` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `actor_id` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  `message` text NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_friends_actor` (`actor_id`),
  KEY `idx_friends_target` (`target_id`),
  KEY `idx_friends_actor_state` (`actor_id`,`state`),
  KEY `idx_friends_target_state` (`target_id`,`state`),
  KEY `idx_actor_target` (`actor_id`,`target_id`,`state`),
  KEY `idx_target_actor` (`target_id`,`actor_id`,`state`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_friends`
--

LOCK TABLES `pro_social_friends` WRITE;
/*!40000 ALTER TABLE `pro_social_friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_friends_invitations`
--

DROP TABLE IF EXISTS `pro_social_friends_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_friends_invitations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` text NOT NULL,
  `created` datetime NOT NULL,
  `message` text NOT NULL,
  `registered_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_friends_invitations`
--

LOCK TABLES `pro_social_friends_invitations` WRITE;
/*!40000 ALTER TABLE `pro_social_friends_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_friends_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_indexer`
--

DROP TABLE IF EXISTS `pro_social_indexer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_indexer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `utype` varchar(64) DEFAULT NULL,
  `component` varchar(64) DEFAULT NULL,
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `link` text,
  `last_update` datetime NOT NULL,
  `ucreator` bigint(20) unsigned DEFAULT '0',
  `image` text,
  PRIMARY KEY (`id`),
  KEY `social_source` (`uid`,`utype`,`component`),
  FULLTEXT KEY `social_indexer_snapshot` (`title`,`content`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_indexer`
--

LOCK TABLES `pro_social_indexer` WRITE;
/*!40000 ALTER TABLE `pro_social_indexer` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_indexer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_languages`
--

DROP TABLE IF EXISTS `pro_social_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `updated` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `translator` varchar(255) NOT NULL,
  `progress` int(11) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_languages`
--

LOCK TABLES `pro_social_languages` WRITE;
/*!40000 ALTER TABLE `pro_social_languages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_likes`
--

DROP TABLE IF EXISTS `pro_social_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_likes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `stream_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `social_likes_uid` (`uid`),
  KEY `social_likes_contenttype` (`type`),
  KEY `social_likes_createdby` (`created_by`),
  KEY `social_likes_content_type` (`type`,`uid`),
  KEY `social_likes_content_type_by` (`type`,`uid`,`created_by`),
  KEY `idx_stream_id` (`stream_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_likes`
--

LOCK TABLES `pro_social_likes` WRITE;
/*!40000 ALTER TABLE `pro_social_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_links`
--

DROP TABLE IF EXISTS `pro_social_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_links`
--

LOCK TABLES `pro_social_links` WRITE;
/*!40000 ALTER TABLE `pro_social_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_links_images`
--

DROP TABLE IF EXISTS `pro_social_links_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_links_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_url` text NOT NULL,
  `internal_url` text NOT NULL,
  `storage` varchar(255) NOT NULL DEFAULT 'joomla',
  PRIMARY KEY (`id`),
  KEY `idx_storage_cron` (`storage`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_links_images`
--

LOCK TABLES `pro_social_links_images` WRITE;
/*!40000 ALTER TABLE `pro_social_links_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_links_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_lists`
--

DROP TABLE IF EXISTS `pro_social_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_lists` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `alias` text NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `default` tinyint(3) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_userid` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_lists`
--

LOCK TABLES `pro_social_lists` WRITE;
/*!40000 ALTER TABLE `pro_social_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_lists_maps`
--

DROP TABLE IF EXISTS `pro_social_lists_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_lists_maps` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `list_id` bigint(20) NOT NULL,
  `target_id` bigint(20) NOT NULL,
  `target_type` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_target_id` (`target_id`),
  KEY `idx_target_list_type` (`target_id`,`list_id`,`target_type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_lists_maps`
--

LOCK TABLES `pro_social_lists_maps` WRITE;
/*!40000 ALTER TABLE `pro_social_lists_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_lists_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_locations`
--

DROP TABLE IF EXISTS `pro_social_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_locations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `type` text NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created` datetime NOT NULL,
  `short_address` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `latitude` varchar(255) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_locations`
--

LOCK TABLES `pro_social_locations` WRITE;
/*!40000 ALTER TABLE `pro_social_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_logger`
--

DROP TABLE IF EXISTS `pro_social_logger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_logger` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file` varchar(255) NOT NULL,
  `line` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_logger`
--

LOCK TABLES `pro_social_logger` WRITE;
/*!40000 ALTER TABLE `pro_social_logger` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_logger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_mailer`
--

DROP TABLE IF EXISTS `pro_social_mailer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_mailer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_name` text NOT NULL,
  `sender_email` text NOT NULL,
  `replyto_email` text NOT NULL,
  `recipient_name` text NOT NULL,
  `recipient_email` text NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `template` text NOT NULL,
  `html` tinyint(4) NOT NULL,
  `state` tinyint(4) NOT NULL,
  `response` text NOT NULL,
  `created` datetime NOT NULL,
  `params` text NOT NULL,
  `priority` tinyint(4) NOT NULL COMMENT '1 - Low , 2 - Medium , 3 - High , 4 - Highest',
  `language` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state` (`state`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_mailer`
--

LOCK TABLES `pro_social_mailer` WRITE;
/*!40000 ALTER TABLE `pro_social_mailer` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_mailer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_migrators`
--

DROP TABLE IF EXISTS `pro_social_migrators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_migrators` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `oid` bigint(20) unsigned NOT NULL,
  `element` varchar(100) NOT NULL,
  `component` varchar(100) NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `component_content` (`component`,`oid`,`element`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Store migrated content id and map with easysocial item id.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_migrators`
--

LOCK TABLES `pro_social_migrators` WRITE;
/*!40000 ALTER TABLE `pro_social_migrators` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_migrators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_moods`
--

DROP TABLE IF EXISTS `pro_social_moods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_moods` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary key of the row',
  `namespace` varchar(255) NOT NULL COMMENT 'Determines if this item is tied to a specific item',
  `namespace_uid` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL COMMENT 'Contains the css class for the emoticon',
  `verb` varchar(255) NOT NULL COMMENT 'Feeling, Watching, Eating etc',
  `subject` text NOT NULL COMMENT 'Happy, Sad, Angry etc',
  `custom` tinyint(3) NOT NULL COMMENT 'Determines if the user supplied a custom text',
  `text` text NOT NULL COMMENT 'If there is a custom text, based on the custom column, this text will be used.',
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_moods`
--

LOCK TABLES `pro_social_moods` WRITE;
/*!40000 ALTER TABLE `pro_social_moods` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_moods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_notes`
--

DROP TABLE IF EXISTS `pro_social_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_notes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `alias` text NOT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_notes`
--

LOCK TABLES `pro_social_notes` WRITE;
/*!40000 ALTER TABLE `pro_social_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_notifications`
--

DROP TABLE IF EXISTS `pro_social_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `context_ids` text NOT NULL,
  `context_type` varchar(255) NOT NULL,
  `cmd` text NOT NULL,
  `app_id` bigint(20) DEFAULT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `image` text NOT NULL,
  `created` datetime NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0',
  `actor_id` int(11) NOT NULL,
  `actor_type` varchar(255) NOT NULL,
  `target_id` int(11) NOT NULL,
  `target_type` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `node_id` (`uid`,`created`),
  KEY `idx_target_state` (`target_id`,`target_type`,`state`),
  KEY `idx_target_created` (`target_id`,`target_type`,`created`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_notifications`
--

LOCK TABLES `pro_social_notifications` WRITE;
/*!40000 ALTER TABLE `pro_social_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_oauth`
--

DROP TABLE IF EXISTS `pro_social_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_oauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oauth_id` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` text NOT NULL,
  `client` varchar(255) NOT NULL,
  `token` text NOT NULL,
  `secret` text NOT NULL,
  `created` datetime NOT NULL,
  `expires` varchar(255) NOT NULL,
  `pull` tinyint(3) NOT NULL,
  `push` tinyint(3) NOT NULL,
  `params` text NOT NULL,
  `last_pulled` datetime NOT NULL,
  `last_pushed` datetime NOT NULL,
  `permissions` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pull` (`pull`,`push`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_oauth`
--

LOCK TABLES `pro_social_oauth` WRITE;
/*!40000 ALTER TABLE `pro_social_oauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_oauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_oauth_history`
--

DROP TABLE IF EXISTS `pro_social_oauth_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_oauth_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oauth_id` int(11) NOT NULL,
  `remote_id` int(11) NOT NULL,
  `remote_type` varchar(255) NOT NULL,
  `local_id` int(11) NOT NULL,
  `local_type` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_oauth_history`
--

LOCK TABLES `pro_social_oauth_history` WRITE;
/*!40000 ALTER TABLE `pro_social_oauth_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_oauth_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_photos`
--

DROP TABLE IF EXISTS `pro_social_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `post_as` varchar(64) DEFAULT 'user',
  `user_id` int(11) NOT NULL,
  `album_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `caption` text NOT NULL,
  `created` datetime NOT NULL,
  `assigned_date` datetime NOT NULL,
  `ordering` tinyint(3) NOT NULL,
  `featured` tinyint(3) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `storage` varchar(255) NOT NULL DEFAULT 'joomla',
  `total_size` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_photos_user_photos` (`state`,`uid`,`type`,`ordering`),
  KEY `idx_albums` (`state`,`album_id`,`ordering`),
  KEY `idx_storage_cron` (`state`,`storage`,`created`),
  KEY `idx_created` (`created`),
  KEY `idx_state_created` (`state`,`created`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_photos`
--

LOCK TABLES `pro_social_photos` WRITE;
/*!40000 ALTER TABLE `pro_social_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_photos_meta`
--

DROP TABLE IF EXISTS `pro_social_photos_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_photos_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `group` varchar(255) NOT NULL,
  `property` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `photo_id` (`photo_id`),
  KEY `group` (`group`),
  KEY `idx_sql1` (`photo_id`,`group`(64),`property`),
  KEY `idx_sql2` (`photo_id`,`group`(64))
) ENGINE=MyISAM AUTO_INCREMENT=329 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_photos_meta`
--

LOCK TABLES `pro_social_photos_meta` WRITE;
/*!40000 ALTER TABLE `pro_social_photos_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_photos_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_photos_tag`
--

DROP TABLE IF EXISTS `pro_social_photos_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_photos_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `label` text NOT NULL,
  `top` varchar(255) NOT NULL,
  `left` varchar(255) NOT NULL,
  `width` varchar(255) NOT NULL,
  `height` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_photos_tag`
--

LOCK TABLES `pro_social_photos_tag` WRITE;
/*!40000 ALTER TABLE `pro_social_photos_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_photos_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_points`
--

DROP TABLE IF EXISTS `pro_social_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_points` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `command` varchar(255) NOT NULL,
  `extension` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL COMMENT 'The title of the points',
  `description` text NOT NULL,
  `alias` varchar(255) NOT NULL COMMENT 'The permalink that links to the points.',
  `created` datetime NOT NULL COMMENT 'Creation datetime of the points.',
  `threshold` int(11) DEFAULT NULL COMMENT 'Optional value if app needs to give points based on certain actions multiple times.',
  `interval` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0 - every time , 1 - once , 2 - twice - n times',
  `points` int(11) NOT NULL DEFAULT '0' COMMENT 'The amount of points to be given.',
  `state` tinyint(3) NOT NULL COMMENT 'The state of the points. 0 - unpublished, 1 - published ',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state` (`state`),
  KEY `command_id` (`command`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_points`
--

LOCK TABLES `pro_social_points` WRITE;
/*!40000 ALTER TABLE `pro_social_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_points_history`
--

DROP TABLE IF EXISTS `pro_social_points_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_points_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Primary key for this table',
  `points_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL COMMENT 'The target user id',
  `points` int(11) NOT NULL COMMENT 'The number of points',
  `created` datetime NOT NULL COMMENT 'The date time value when the user earned the point.',
  `state` tinyint(3) NOT NULL COMMENT 'The publish state',
  `message` text NOT NULL COMMENT 'Any custom message set for this points assignment',
  PRIMARY KEY (`id`),
  KEY `state` (`state`),
  KEY `points_id` (`points_id`),
  KEY `idx_userid` (`user_id`),
  KEY `user_points` (`user_id`,`points`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_points_history`
--

LOCK TABLES `pro_social_points_history` WRITE;
/*!40000 ALTER TABLE `pro_social_points_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_points_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_polls`
--

DROP TABLE IF EXISTS `pro_social_polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_polls` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `element` varchar(255) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `multiple` tinyint(1) DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `cluster_id` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expiry_date` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_element_id` (`element`,`uid`),
  KEY `idx_clusterid` (`cluster_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_polls`
--

LOCK TABLES `pro_social_polls` WRITE;
/*!40000 ALTER TABLE `pro_social_polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_polls_items`
--

DROP TABLE IF EXISTS `pro_social_polls_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_polls_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `poll_id` bigint(20) unsigned NOT NULL,
  `value` text NOT NULL,
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pollid` (`poll_id`),
  KEY `idx_polls` (`poll_id`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_polls_items`
--

LOCK TABLES `pro_social_polls_items` WRITE;
/*!40000 ALTER TABLE `pro_social_polls_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_polls_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_polls_users`
--

DROP TABLE IF EXISTS `pro_social_polls_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_polls_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `poll_id` bigint(20) unsigned NOT NULL,
  `poll_itemid` bigint(20) NOT NULL DEFAULT '0',
  `user_id` bigint(20) NOT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_pollid` (`poll_id`),
  KEY `idx_userid` (`user_id`),
  KEY `idx_pollitem` (`poll_itemid`),
  KEY `idx_poll_user` (`poll_id`,`user_id`),
  KEY `idx_poll_item_user` (`poll_id`,`poll_itemid`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_polls_users`
--

LOCK TABLES `pro_social_polls_users` WRITE;
/*!40000 ALTER TABLE `pro_social_polls_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_polls_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_privacy`
--

DROP TABLE IF EXISTS `pro_social_privacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_privacy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL COMMENT 'object type e.g. photos, friends, albums, profile and etc',
  `rule` varchar(64) NOT NULL COMMENT 'rule type e.g. view_friends, view, search, comment, tag and etc',
  `value` int(11) DEFAULT '0',
  `options` text,
  `description` text,
  `state` tinyint(3) NOT NULL DEFAULT '1',
  `core` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `type_rule` (`type`,`rule`),
  KEY `type_rule_privacy` (`type`,`rule`,`value`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_privacy`
--

LOCK TABLES `pro_social_privacy` WRITE;
/*!40000 ALTER TABLE `pro_social_privacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_privacy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_privacy_customize`
--

DROP TABLE IF EXISTS `pro_social_privacy_customize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_privacy_customize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'id from user or profile or item',
  `utype` varchar(64) NOT NULL COMMENT 'user or profile or item',
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `uid_type` (`uid`,`utype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_privacy_customize`
--

LOCK TABLES `pro_social_privacy_customize` WRITE;
/*!40000 ALTER TABLE `pro_social_privacy_customize` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_privacy_customize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_privacy_items`
--

DROP TABLE IF EXISTS `pro_social_privacy_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_privacy_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `privacy_id` int(11) NOT NULL COMMENT 'key to social_privacy.id',
  `user_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL COMMENT 'object id e.g streamid, activityid and etc',
  `type` varchar(64) NOT NULL COMMENT 'object type e.g. stream, activity and etc',
  `value` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `privacy_id` (`privacy_id`),
  KEY `user_privacy_item` (`user_id`,`uid`,`type`),
  KEY `idx_uid_type` (`uid`,`type`),
  KEY `idx_user_type` (`user_id`,`type`),
  KEY `idx_value_user` (`value`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_privacy_items`
--

LOCK TABLES `pro_social_privacy_items` WRITE;
/*!40000 ALTER TABLE `pro_social_privacy_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_privacy_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_privacy_map`
--

DROP TABLE IF EXISTS `pro_social_privacy_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_privacy_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `privacy_id` int(11) NOT NULL COMMENT 'key to social_privacy.id',
  `uid` int(11) NOT NULL COMMENT 'userid or profileid',
  `utype` varchar(64) NOT NULL COMMENT 'user or profile',
  `value` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `privacy_id` (`privacy_id`),
  KEY `uid_type` (`uid`,`utype`),
  KEY `uid_type_value` (`uid`,`utype`,`value`),
  KEY `idx_privacy_uid_type` (`privacy_id`,`uid`,`utype`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_privacy_map`
--

LOCK TABLES `pro_social_privacy_map` WRITE;
/*!40000 ALTER TABLE `pro_social_privacy_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_privacy_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_profiles`
--

DROP TABLE IF EXISTS `pro_social_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_profiles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `gid` text NOT NULL,
  `default` tinyint(4) NOT NULL,
  `default_avatar` int(11) DEFAULT NULL COMMENT 'If this field contains an id, it''s from the default avatar, otherwise use system''s default avatar.',
  `created` datetime NOT NULL,
  `state` tinyint(4) NOT NULL,
  `params` text NOT NULL,
  `registration` tinyint(4) NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL,
  `site_id` varchar(255) DEFAULT NULL,
  `community_access` tinyint(3) NOT NULL DEFAULT '1',
  `switchable` tinyint(3) NOT NULL DEFAULT '0',
  `modified` datetime NOT NULL,
  `apps` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state` (`state`),
  KEY `profile_esad` (`community_access`),
  KEY `idx_profile_access` (`id`,`community_access`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_profiles`
--

LOCK TABLES `pro_social_profiles` WRITE;
/*!40000 ALTER TABLE `pro_social_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_profiles_maps`
--

DROP TABLE IF EXISTS `pro_social_profiles_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_profiles_maps` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `state` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_id` (`profile_id`),
  KEY `idx_userid` (`user_id`),
  KEY `idx_profile_users` (`profile_id`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_profiles_maps`
--

LOCK TABLES `pro_social_profiles_maps` WRITE;
/*!40000 ALTER TABLE `pro_social_profiles_maps` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_profiles_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_regions`
--

DROP TABLE IF EXISTS `pro_social_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_regions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(64) NOT NULL,
  `parent_uid` bigint(20) NOT NULL,
  `parent_type` varchar(255) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  `params` text,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `site_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_regions`
--

LOCK TABLES `pro_social_regions` WRITE;
/*!40000 ALTER TABLE `pro_social_regions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_registrations`
--

DROP TABLE IF EXISTS `pro_social_registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_registrations` (
  `session_id` varchar(200) NOT NULL,
  `profile_id` bigint(20) NOT NULL,
  `created` datetime NOT NULL,
  `values` text NOT NULL,
  `step` bigint(20) NOT NULL,
  `step_access` text NOT NULL,
  `errors` text NOT NULL,
  UNIQUE KEY `session_id` (`session_id`),
  KEY `profile_id` (`profile_id`),
  KEY `step` (`step`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_registrations`
--

LOCK TABLES `pro_social_registrations` WRITE;
/*!40000 ALTER TABLE `pro_social_registrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_relationship_status`
--

DROP TABLE IF EXISTS `pro_social_relationship_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_relationship_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actor` bigint(20) NOT NULL,
  `target` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relation_type` (`type`),
  KEY `state` (`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_relationship_status`
--

LOCK TABLES `pro_social_relationship_status` WRITE;
/*!40000 ALTER TABLE `pro_social_relationship_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_relationship_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_reports`
--

DROP TABLE IF EXISTS `pro_social_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `message` text NOT NULL,
  `extension` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `url` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_reports`
--

LOCK TABLES `pro_social_reports` WRITE;
/*!40000 ALTER TABLE `pro_social_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_reviews`
--

DROP TABLE IF EXISTS `pro_social_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `published` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  `message` text NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_reviews`
--

LOCK TABLES `pro_social_reviews` WRITE;
/*!40000 ALTER TABLE `pro_social_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_rss`
--

DROP TABLE IF EXISTS `pro_social_rss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_rss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `url` text NOT NULL,
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`state`),
  KEY `uid` (`uid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_rss`
--

LOCK TABLES `pro_social_rss` WRITE;
/*!40000 ALTER TABLE `pro_social_rss` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_rss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_search_filter`
--

DROP TABLE IF EXISTS `pro_social_search_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_search_filter` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `element` varchar(255) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `filter` text NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sitewide` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_searchfilter_element_id` (`element`,`uid`),
  KEY `idx_searchfilter_owner` (`element`,`uid`,`created_by`),
  KEY `idx_searchfilter_alias` (`alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_search_filter`
--

LOCK TABLES `pro_social_search_filter` WRITE;
/*!40000 ALTER TABLE `pro_social_search_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_search_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_shares`
--

DROP TABLE IF EXISTS `pro_social_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_shares` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `element` varchar(255) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shares_element` (`uid`,`element`),
  KEY `shares_element_user` (`uid`,`element`,`user_id`),
  KEY `shares_userid` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_shares`
--

LOCK TABLES `pro_social_shares` WRITE;
/*!40000 ALTER TABLE `pro_social_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_step_sessions`
--

DROP TABLE IF EXISTS `pro_social_step_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_step_sessions` (
  `session_id` varchar(200) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `values` text NOT NULL,
  `step` bigint(20) NOT NULL,
  `step_access` text NOT NULL,
  `errors` text NOT NULL,
  UNIQUE KEY `session_id` (`session_id`),
  KEY `profile_id` (`uid`),
  KEY `step` (`step`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_step_sessions`
--

LOCK TABLES `pro_social_step_sessions` WRITE;
/*!40000 ALTER TABLE `pro_social_step_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_step_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_storage_log`
--

DROP TABLE IF EXISTS `pro_social_storage_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_storage_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `object_type` varchar(255) NOT NULL,
  `target` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_storage_log`
--

LOCK TABLES `pro_social_storage_log` WRITE;
/*!40000 ALTER TABLE `pro_social_storage_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_storage_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream`
--

DROP TABLE IF EXISTS `pro_social_stream`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` bigint(20) unsigned NOT NULL,
  `alias` varchar(255) DEFAULT '',
  `actor_type` varchar(64) DEFAULT 'people',
  `post_as` varchar(64) DEFAULT 'user',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `title` text,
  `content` text,
  `context_type` varchar(64) DEFAULT '',
  `stream_type` varchar(15) DEFAULT NULL,
  `sitewide` tinyint(1) DEFAULT '0',
  `target_id` bigint(20) NOT NULL,
  `location_id` int(11) NOT NULL,
  `mood_id` int(11) NOT NULL,
  `with` text NOT NULL,
  `ispublic` tinyint(3) NOT NULL DEFAULT '0',
  `params` longtext,
  `cluster_id` int(11) DEFAULT '0',
  `cluster_type` varchar(64) DEFAULT NULL,
  `cluster_access` tinyint(3) DEFAULT '0',
  `state` tinyint(3) NOT NULL DEFAULT '1',
  `privacy_id` int(11) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `custom_access` text,
  `verb` varchar(64) DEFAULT '',
  `edited` datetime DEFAULT '0000-00-00 00:00:00',
  `last_action` varchar(255) DEFAULT NULL,
  `last_userid` bigint(20) unsigned DEFAULT '0',
  `last_action_date` datetime DEFAULT '0000-00-00 00:00:00',
  `sticky_id` bigint(20) unsigned DEFAULT '0',
  `datafix` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `stream_actor` (`actor_id`),
  KEY `stream_created` (`created`),
  KEY `stream_modified` (`modified`),
  KEY `stream_alias` (`alias`),
  KEY `stream_source` (`actor_type`),
  KEY `idx_stream_context_type` (`context_type`),
  KEY `idx_stream_target` (`target_id`),
  KEY `idx_actor_modified` (`actor_id`,`modified`),
  KEY `idx_target_context_modified` (`target_id`,`context_type`,`modified`),
  KEY `idx_sitewide_modified` (`sitewide`,`modified`),
  KEY `idx_ispublic` (`ispublic`,`modified`),
  KEY `idx_cluster_access` (`cluster_id`,`cluster_access`),
  KEY `idx_clusterid` (`cluster_id`),
  KEY `idx_cluster_items` (`cluster_id`,`cluster_type`,`modified`),
  KEY `idx_access` (`access`),
  KEY `idx_custom_access` (`access`,`custom_access`(255)),
  KEY `idx_stream_total_cluster` (`cluster_id`,`cluster_access`,`context_type`,`id`,`actor_id`),
  KEY `idx_stream_total_user` (`cluster_id`,`access`,`actor_id`,`context_type`),
  KEY `idx_stickyid` (`sticky_id`)
) ENGINE=MyISAM AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream`
--

LOCK TABLES `pro_social_stream` WRITE;
/*!40000 ALTER TABLE `pro_social_stream` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_assets`
--

DROP TABLE IF EXISTS `pro_social_stream_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_assets`
--

LOCK TABLES `pro_social_stream_assets` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_filter`
--

DROP TABLE IF EXISTS `pro_social_stream_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_filter` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) unsigned NOT NULL,
  `utype` varchar(255) DEFAULT 'user',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `streamfilter_uidtype` (`uid`,`utype`),
  KEY `streamfilter_alias` (`alias`),
  KEY `streamfilter_cluster_user` (`uid`,`utype`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_filter`
--

LOCK TABLES `pro_social_stream_filter` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_filter_item`
--

DROP TABLE IF EXISTS `pro_social_stream_filter_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_filter_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filter_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `filteritem_fid` (`filter_id`),
  KEY `filteritem_type` (`type`),
  KEY `filteritem_fidtype` (`filter_id`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_filter_item`
--

LOCK TABLES `pro_social_stream_filter_item` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_filter_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_filter_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_hide`
--

DROP TABLE IF EXISTS `pro_social_stream_hide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_hide` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `context` varchar(255) DEFAULT NULL,
  `actor_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `stream_hide_user` (`user_id`),
  KEY `stream_hide_uid` (`uid`),
  KEY `stream_hide_user_uid` (`user_id`,`uid`),
  KEY `stream_hide_actorid` (`actor_id`),
  KEY `idx_stream_hide_context` (`context`,`user_id`,`uid`,`actor_id`),
  KEY `idx_stream_hide_actor` (`actor_id`,`user_id`,`uid`,`context`),
  KEY `idx_stream_hide_uid` (`uid`,`user_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_hide`
--

LOCK TABLES `pro_social_stream_hide` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_hide` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_hide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_history`
--

DROP TABLE IF EXISTS `pro_social_stream_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_history` (
  `id` bigint(20) unsigned NOT NULL,
  `actor_id` bigint(20) unsigned NOT NULL,
  `alias` varchar(255) DEFAULT '',
  `actor_type` varchar(64) DEFAULT 'user',
  `post_as` varchar(64) DEFAULT 'user',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `edited` datetime DEFAULT '0000-00-00 00:00:00',
  `title` text,
  `content` text,
  `context_type` varchar(64) DEFAULT '',
  `verb` varchar(64) DEFAULT '',
  `stream_type` varchar(15) DEFAULT NULL,
  `sitewide` tinyint(1) DEFAULT '0',
  `target_id` bigint(20) NOT NULL,
  `location_id` int(11) NOT NULL,
  `mood_id` int(11) NOT NULL,
  `with` text NOT NULL,
  `ispublic` tinyint(3) NOT NULL DEFAULT '0',
  `cluster_id` int(11) DEFAULT '0',
  `cluster_type` varchar(64) DEFAULT NULL,
  `cluster_access` tinyint(3) DEFAULT '0',
  `params` longtext,
  `state` tinyint(3) NOT NULL DEFAULT '1',
  `privacy_id` int(11) DEFAULT NULL,
  `access` int(11) NOT NULL DEFAULT '0',
  `custom_access` text,
  `last_action` varchar(255) DEFAULT NULL,
  `last_userid` bigint(20) unsigned DEFAULT '0',
  `last_action_date` datetime DEFAULT '0000-00-00 00:00:00',
  `sticky_id` bigint(20) unsigned DEFAULT '0',
  `datafix` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `stream_history_created` (`created`),
  KEY `stream_history_modified` (`modified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_history`
--

LOCK TABLES `pro_social_stream_history` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_item`
--

DROP TABLE IF EXISTS `pro_social_stream_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` bigint(20) unsigned NOT NULL,
  `actor_type` varchar(255) DEFAULT 'people',
  `context_type` varchar(64) DEFAULT '',
  `context_id` bigint(20) unsigned DEFAULT '0',
  `verb` varchar(64) DEFAULT '',
  `target_id` bigint(20) unsigned DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uid` bigint(20) unsigned NOT NULL,
  `sitewide` tinyint(1) DEFAULT '0',
  `params` text,
  `state` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `activity_actor` (`actor_id`),
  KEY `activity_created` (`created`),
  KEY `activity_context` (`context_type`),
  KEY `activity_context_id` (`context_id`),
  KEY `idx_context_verb` (`context_type`,`verb`),
  KEY `idx_uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_item`
--

LOCK TABLES `pro_social_stream_item` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_item_history`
--

DROP TABLE IF EXISTS `pro_social_stream_item_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_item_history` (
  `id` bigint(20) unsigned NOT NULL,
  `actor_id` bigint(20) unsigned NOT NULL,
  `actor_type` varchar(255) DEFAULT 'people',
  `context_type` varchar(64) DEFAULT '',
  `context_id` bigint(20) unsigned DEFAULT '0',
  `verb` varchar(64) DEFAULT '',
  `target_id` bigint(20) unsigned DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uid` bigint(20) unsigned NOT NULL,
  `sitewide` tinyint(1) DEFAULT '0',
  `params` text,
  `state` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_history_uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_item_history`
--

LOCK TABLES `pro_social_stream_item_history` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_item_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_item_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_sticky`
--

DROP TABLE IF EXISTS `pro_social_stream_sticky`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_sticky` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` bigint(20) unsigned NOT NULL,
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_streamid` (`stream_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_sticky`
--

LOCK TABLES `pro_social_stream_sticky` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_sticky` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_sticky` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_stream_tags`
--

DROP TABLE IF EXISTS `pro_social_stream_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_stream_tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `stream_id` bigint(20) unsigned NOT NULL,
  `uid` bigint(20) unsigned NOT NULL,
  `utype` varchar(255) DEFAULT 'user',
  `with` tinyint(3) unsigned DEFAULT '0',
  `offset` int(11) DEFAULT '0',
  `length` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `streamtags_streamid` (`stream_id`),
  KEY `streamtags_uidtype` (`uid`,`utype`),
  KEY `streamtags_uidoffset` (`stream_id`,`offset`),
  KEY `streamtags_title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_stream_tags`
--

LOCK TABLES `pro_social_stream_tags` WRITE;
/*!40000 ALTER TABLE `pro_social_stream_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_stream_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_subscriptions`
--

DROP TABLE IF EXISTS `pro_social_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'object id e.g userid, groupid, streamid and etc',
  `type` varchar(64) NOT NULL COMMENT 'subscription type e.g. user, group, stream and etc',
  `user_id` int(11) DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid_type` (`uid`,`type`),
  KEY `uid_type_user` (`uid`,`type`,`user_id`),
  KEY `uid_type_email` (`uid`,`type`),
  KEY `idx_uid` (`uid`),
  KEY `idx_type_userid` (`type`,`user_id`),
  KEY `idx_userid` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_subscriptions`
--

LOCK TABLES `pro_social_subscriptions` WRITE;
/*!40000 ALTER TABLE `pro_social_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_tags`
--

DROP TABLE IF EXISTS `pro_social_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_type` varchar(255) NOT NULL,
  `target_id` int(11) NOT NULL,
  `target_type` varchar(255) NOT NULL,
  `creator_id` int(11) NOT NULL,
  `creator_type` varchar(255) NOT NULL,
  `offset` int(11) NOT NULL,
  `length` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_targets` (`target_id`,`target_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_tags`
--

LOCK TABLES `pro_social_tags` WRITE;
/*!40000 ALTER TABLE `pro_social_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_tags_filter`
--

DROP TABLE IF EXISTS `pro_social_tags_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_tags_filter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cid` bigint(20) NOT NULL,
  `filter_type` varchar(255) NOT NULL,
  `cluster_type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_filter` (`user_id`,`filter_type`,`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_tags_filter`
--

LOCK TABLES `pro_social_tags_filter` WRITE;
/*!40000 ALTER TABLE `pro_social_tags_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_tags_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_tags_filter_item`
--

DROP TABLE IF EXISTS `pro_social_tags_filter_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_tags_filter_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `filter_id` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `idx_filter_id` (`filter_id`),
  KEY `idx_type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_tags_filter_item`
--

LOCK TABLES `pro_social_tags_filter_item` WRITE;
/*!40000 ALTER TABLE `pro_social_tags_filter_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_tags_filter_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_tasks`
--

DROP TABLE IF EXISTS `pro_social_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `state` tinyint(3) NOT NULL,
  `created` datetime NOT NULL,
  `milestone_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `due` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_tasks`
--

LOCK TABLES `pro_social_tasks` WRITE;
/*!40000 ALTER TABLE `pro_social_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_tasks_milestones`
--

DROP TABLE IF EXISTS `pro_social_tasks_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_tasks_milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `due` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_tasks_milestones`
--

LOCK TABLES `pro_social_tasks_milestones` WRITE;
/*!40000 ALTER TABLE `pro_social_tasks_milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_tasks_milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_themes`
--

DROP TABLE IF EXISTS `pro_social_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `element` varchar(255) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `element` (`element`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_themes`
--

LOCK TABLES `pro_social_themes` WRITE;
/*!40000 ALTER TABLE `pro_social_themes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_themes_overrides`
--

DROP TABLE IF EXISTS `pro_social_themes_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_themes_overrides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_id` text NOT NULL,
  `notes` text NOT NULL,
  `contents` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_themes_overrides`
--

LOCK TABLES `pro_social_themes_overrides` WRITE;
/*!40000 ALTER TABLE `pro_social_themes_overrides` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_themes_overrides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_tmp`
--

DROP TABLE IF EXISTS `pro_social_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_tmp` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` text NOT NULL,
  `key` varchar(200) NOT NULL,
  `value` text NOT NULL,
  `created` datetime NOT NULL,
  `expired` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `node_id` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_tmp`
--

LOCK TABLES `pro_social_tmp` WRITE;
/*!40000 ALTER TABLE `pro_social_tmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_uploader`
--

DROP TABLE IF EXISTS `pro_social_uploader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_uploader` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `name` text NOT NULL,
  `mime` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_uploader`
--

LOCK TABLES `pro_social_uploader` WRITE;
/*!40000 ALTER TABLE `pro_social_uploader` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_uploader` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_users`
--

DROP TABLE IF EXISTS `pro_social_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_users` (
  `user_id` bigint(20) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `params` text NOT NULL,
  `connections` int(11) NOT NULL,
  `permalink` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'joomla',
  `auth` varchar(255) NOT NULL COMMENT 'Used in conjunction with the REST api',
  `completed_fields` int(11) NOT NULL DEFAULT '0',
  `reminder_sent` tinyint(1) DEFAULT '0',
  `require_reset` tinyint(1) DEFAULT '0',
  `block_date` datetime DEFAULT '0000-00-00 00:00:00',
  `block_period` int(11) DEFAULT '0',
  `social_params` longtext NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `state` (`state`),
  KEY `alias` (`alias`),
  KEY `connections` (`connections`),
  KEY `permalink` (`permalink`),
  KEY `idx_types` (`user_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_users`
--

LOCK TABLES `pro_social_users` WRITE;
/*!40000 ALTER TABLE `pro_social_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_videos`
--

DROP TABLE IF EXISTS `pro_social_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary key for this table',
  `title` varchar(255) NOT NULL COMMENT 'Title of the video',
  `description` text NOT NULL COMMENT 'The description of the video',
  `user_id` int(11) NOT NULL COMMENT 'The user id that created this video',
  `uid` int(11) NOT NULL COMMENT 'This video may belong to another node other than the user.',
  `type` varchar(255) NOT NULL COMMENT 'This video may belong to another node other than the user.',
  `post_as` varchar(64) DEFAULT 'user',
  `created` datetime NOT NULL,
  `state` tinyint(3) NOT NULL,
  `featured` tinyint(3) NOT NULL,
  `category_id` int(11) NOT NULL,
  `hits` int(11) NOT NULL COMMENT 'Total hits received for this video',
  `duration` varchar(255) NOT NULL COMMENT 'Duration of the video',
  `size` int(11) NOT NULL COMMENT 'The file size of the video',
  `params` text NOT NULL COMMENT 'Store video params',
  `storage` varchar(255) NOT NULL COMMENT 'Storage for videos',
  `path` text NOT NULL,
  `original` text NOT NULL,
  `file_title` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `thumbnail` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`,`user_id`,`state`,`featured`,`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_videos`
--

LOCK TABLES `pro_social_videos` WRITE;
/*!40000 ALTER TABLE `pro_social_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_videos_categories`
--

DROP TABLE IF EXISTS `pro_social_videos_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_videos_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `state` tinyint(3) NOT NULL,
  `default` tinyint(3) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL COMMENT 'The user id that created this category',
  `created` datetime NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `state` (`state`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_videos_categories`
--

LOCK TABLES `pro_social_videos_categories` WRITE;
/*!40000 ALTER TABLE `pro_social_videos_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_videos_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_social_videos_categories_access`
--

DROP TABLE IF EXISTS `pro_social_videos_categories_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_social_videos_categories_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`,`profile_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_social_videos_categories_access`
--

LOCK TABLES `pro_social_videos_categories_access` WRITE;
/*!40000 ALTER TABLE `pro_social_videos_categories_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_social_videos_categories_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_tags`
--

DROP TABLE IF EXISTS `pro_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `urls` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tag_idx` (`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_language` (`language`),
  KEY `idx_path` (`path`(100)),
  KEY `idx_alias` (`alias`(100))
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_tags`
--

LOCK TABLES `pro_tags` WRITE;
/*!40000 ALTER TABLE `pro_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_template_styles`
--

DROP TABLE IF EXISTS `pro_template_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_template_styles`
--

LOCK TABLES `pro_template_styles` WRITE;
/*!40000 ALTER TABLE `pro_template_styles` DISABLE KEYS */;
INSERT INTO `pro_template_styles` VALUES (4,'beez3',0,'0','Beez3 - Default','{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"logo\":\"images\\/joomla_black.gif\",\"sitetitle\":\"Joomla!\",\"sitedescription\":\"Open Source Content Management\",\"navposition\":\"left\",\"templatecolor\":\"personal\",\"html5\":\"0\"}'),(5,'hathor',1,'0','Hathor - Default','{\"showSiteName\":\"0\",\"colourChoice\":\"\",\"boldText\":\"0\"}'),(7,'protostar',0,'0','protostar - Default','{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}'),(8,'isis',1,'1','isis - Default','{\"templateColor\":\"\",\"logoFile\":\"\"}'),(14,'purity_iii',0,'0','Purity III - Default','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"link_titles\":\"\",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"enable_logoimage_sm\":\"0\",\"logoimage_sm\":\"\",\"mainlayout\":\"default-content-left\",\"sublayout\":\"\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":\"\",\"snippet_close_head\":\"\",\"snippet_open_body\":\"\",\"snippet_close_body\":\"\",\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_easyblog\":[\"634\"],\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"theme_extras_com_joomprofile\":[\"765\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"]}'),(15,'purity_iii',0,'0','Purity III - Features Intro 1','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"mainlayout\":\"features-intro-1\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_easyblog\":[\"634\"],\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"mm_config_needupdate\":\"\",\"link_titles\":null,\"theme_extras_com_joomprofile\":[\"765\"]}'),(16,'purity_iii',0,'0','Purity III - Blog','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"mainlayout\":\"blog\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"mm_config_needupdate\":\"\",\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easyblog\":[\"634\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"link_titles\":null,\"theme_extras_com_joomprofile\":[\"765\"]}'),(17,'purity_iii',0,'0','Purity III - Porfolio','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"mainlayout\":\"portfolio\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"mm_config_needupdate\":\"\",\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easyblog\":[\"634\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"link_titles\":null,\"theme_extras_com_joomprofile\":[\"765\"]}'),(18,'purity_iii',0,'1','Purity III - Corporate','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"mainlayout\":\"corporate\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_easyblog\":[\"634\"],\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"mm_config_needupdate\":\"\",\"link_titles\":null,\"theme_extras_com_joomprofile\":[\"765\"]}'),(19,'purity_iii',0,'0','Purity III - Magazine','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"mainlayout\":\"magazine\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"mm_config_needupdate\":\"\",\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easyblog\":[\"634\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"link_titles\":null,\"theme_extras_com_joomprofile\":[\"765\"]}'),(20,'purity_iii',0,'0','Purity III - Product Style 2','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"mainlayout\":\"blog\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"mm_config_needupdate\":\"\",\"theme_extras_com_easyblog\":[\"634\"],\"link_titles\":null,\"theme_extras_com_joomprofile\":[\"765\"]}'),(21,'purity_iii',0,'0','Purity III - Sidebar Content','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"mainlayout\":\"default-content-right\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"mm_config_needupdate\":\"\",\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easyblog\":[\"634\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"link_titles\":null,\"theme_extras_com_joomprofile\":[\"765\"]}'),(23,'purity_iii',0,'0','Purity III - Features Intro 2','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"mainlayout\":\"features-intro-2\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"mm_config_needupdate\":\"\",\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easyblog\":[\"634\"],\"link_titles\":null,\"theme_extras_com_joomprofile\":[\"765\"]}'),(24,'purity_iii',0,'0','Purity III - Docs','{\"tpl_article_info_datetime_format\":\"l, d F Y\",\"t3_template\":\"1\",\"devmode\":\"0\",\"themermode\":\"1\",\"legacy_css\":\"1\",\"responsive\":\"1\",\"non_responsive_width\":\"970px\",\"build_rtl\":\"0\",\"t3-assets\":\"t3-assets\",\"t3-rmvlogo\":\"1\",\"minify\":\"1\",\"minify_js\":\"1\",\"minify_js_tool\":\"jsmin\",\"minify_exclude\":\"components\\/com_community\\/assets\\/release\\/js\\/loader.js,media\\/jui\\/js\\/jquery.min.js, js\\/script.js,error.css \",\"link_titles\":null,\"theme\":\"\",\"logotype\":\"image\",\"sitename\":\"Purity III\",\"slogan\":\"The last template you will ever need.\",\"logoimage\":\"\",\"enable_logoimage_sm\":\"0\",\"logoimage_sm\":\"\",\"mainlayout\":\"docs\",\"sublayout\":\"\",\"mm_type\":\"mainmenu\",\"navigation_trigger\":\"hover\",\"navigation_type\":\"megamenu\",\"navigation_animation\":\"slide\",\"navigation_animation_duration\":\"200\",\"mm_config\":\"{\\\"mainmenu\\\":{\\\"item-435\\\":{\\\"sub\\\":{\\\"width\\\":850,\\\"rows\\\":[[{\\\"item\\\":743,\\\"width\\\":3},{\\\"item\\\":540,\\\"width\\\":3},{\\\"position\\\":112,\\\"width\\\":6}]]}},\\\"item-743\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":567,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-540\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":744,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-546\\\":{\\\"sub\\\":{\\\"width\\\":620,\\\"rows\\\":[[{\\\"item\\\":741,\\\"width\\\":4},{\\\"position\\\":221,\\\"width\\\":8}]]}},\\\"item-741\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":738,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-545\\\":{\\\"sub\\\":{\\\"width\\\":700,\\\"rows\\\":[[{\\\"item\\\":548,\\\"width\\\":4},{\\\"item\\\":742,\\\"width\\\":4},{\\\"position\\\":16,\\\"width\\\":4}]]},\\\"alignsub\\\":\\\"left\\\"},\\\"item-548\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":553,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-742\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":550,\\\"width\\\":12}]]},\\\"group\\\":1},\\\"item-571\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":693,\\\"width\\\":12}]]}},\\\"item-693\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":716,\\\"width\\\":12}]]}},\\\"item-599\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":718,\\\"width\\\":12}]]}},\\\"item-634\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":715,\\\"width\\\":12}]]}},\\\"item-707\\\":{\\\"sub\\\":{\\\"rows\\\":[[{\\\"item\\\":745,\\\"width\\\":12}]]}}}}\",\"navigation_collapse_enable\":\"1\",\"addon_offcanvas_enable\":\"1\",\"addon_offcanvas_effect\":\"off-canvas-effect-4\",\"snippet_open_head\":null,\"snippet_close_head\":null,\"snippet_open_body\":null,\"snippet_close_body\":null,\"snippet_debug\":\"0\",\"theme_extras_com_community\":[\"599\",\"718\",\"719\"],\"theme_extras_com_easyblog\":[\"634\"],\"theme_extras_com_easydiscuss\":[\"651\"],\"theme_extras_com_easysocial\":[\"693\",\"715\"],\"theme_extras_com_joomprofile\":[\"765\"],\"theme_extras_com_kunena\":[\"588\",\"589\",\"590\",\"591\",\"592\",\"593\",\"594\",\"595\",\"596\",\"597\"],\"theme_extras_com_mijoshop\":[\"707\",\"745\",\"1050\",\"710\",\"713\",\"712\",\"711\"],\"theme_extras_layout_glossary\":[\"724\"],\"mm_config_needupdate\":\"\"}');
/*!40000 ALTER TABLE `pro_template_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_ucm_base`
--

DROP TABLE IF EXISTS `pro_ucm_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_ucm_base` (
  `ucm_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL,
  PRIMARY KEY (`ucm_id`),
  KEY `idx_ucm_item_id` (`ucm_item_id`),
  KEY `idx_ucm_type_id` (`ucm_type_id`),
  KEY `idx_ucm_language_id` (`ucm_language_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_ucm_base`
--

LOCK TABLES `pro_ucm_base` WRITE;
/*!40000 ALTER TABLE `pro_ucm_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_ucm_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_ucm_content`
--

DROP TABLE IF EXISTS `pro_ucm_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `core_body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_urls` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_metadesc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_language` (`core_language`),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`),
  KEY `idx_alias` (`core_alias`(100)),
  KEY `idx_title` (`core_title`(100)),
  KEY `idx_content_type` (`core_type_alias`(100))
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Contains core content data in name spaced fields';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_ucm_content`
--

LOCK TABLES `pro_ucm_content` WRITE;
/*!40000 ALTER TABLE `pro_ucm_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_ucm_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_ucm_history`
--

DROP TABLE IF EXISTS `pro_ucm_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_ucm_history` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep',
  PRIMARY KEY (`version_id`),
  KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  KEY `idx_save_date` (`save_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_ucm_history`
--

LOCK TABLES `pro_ucm_history` WRITE;
/*!40000 ALTER TABLE `pro_ucm_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_ucm_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_update_sites`
--

DROP TABLE IF EXISTS `pro_update_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Update Sites';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_update_sites`
--

LOCK TABLES `pro_update_sites` WRITE;
/*!40000 ALTER TABLE `pro_update_sites` DISABLE KEYS */;
INSERT INTO `pro_update_sites` VALUES (1,'Joomla! Core','collection','https://update.joomla.org/core/list.xml',1,1491107258,''),(2,'Joomla! Extension Directory','collection','https://update.joomla.org/jed/list.xml',0,0,''),(4,'','collection','http://update.joomlart.com/service/tracking/list.xml',1,1491107258,''),(5,'Joomla! Update Component Update Site','extension','https://update.joomla.org/core/extensions/com_joomlaupdate.xml',1,1491107258,''),(6,'Accredited Joomla! Translations','collection','https://update.joomla.org/language/translationlist_3.xml',1,1491107258,''),(7,'Kunena 5.0 Update Site','collection','https://update.kunena.org/5.0/list.xml',1,1491107260,''),(9,'JA Extension Manager','extension','http://update.joomlart.com/service/tracking/j16/com_com_jaextmanager.xml',1,1491107261,''),(10,'','extension','http://update.joomlart.com/service/tracking/j31/purity_iii.xml',1,1491107262,''),(11,'','extension','http://update.joomlart.com/service/tracking/j16/plg_system_t3.xml',1,1491107264,''),(12,'Accredited Joomla! Translations','collection','http://update.joomla.org/language/translationlist_3.xml',1,1491107265,''),(13,'WebInstaller Update Site','extension','http://appscdn.joomla.org/webapps/jedapps/webinstaller.xml',1,1491107265,''),(14,'JCE Editor Package','collection','https://www.joomlacontenteditor.net/index.php?option=com_updates&view=update&format=xml&file=pkg_jce.xml',1,1491107267,''),(15,'FOF 3.x','extension','http://cdn.akeebabackup.com/updates/fof3.xml',1,1491107268,''),(16,'Akeeba Backup Core','extension','http://cdn.akeebabackup.com/updates/pkgakeebacore.xml',1,1491107268,'');
/*!40000 ALTER TABLE `pro_update_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_update_sites_extensions`
--

DROP TABLE IF EXISTS `pro_update_sites_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Links extensions to update sites';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_update_sites_extensions`
--

LOCK TABLES `pro_update_sites_extensions` WRITE;
/*!40000 ALTER TABLE `pro_update_sites_extensions` DISABLE KEYS */;
INSERT INTO `pro_update_sites_extensions` VALUES (1,700),(2,700),(3,600),(4,10001),(4,10004),(4,10103),(5,28),(6,802),(7,10126),(9,10103),(10,10004),(11,10001),(12,10308),(13,10309),(14,10317),(15,10318),(16,10323);
/*!40000 ALTER TABLE `pro_update_sites_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_updates`
--

DROP TABLE IF EXISTS `pro_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `folder` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `detailsurl` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `infourl` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_query` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB AUTO_INCREMENT=413 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Available Updates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_updates`
--

LOCK TABLES `pro_updates` WRITE;
/*!40000 ALTER TABLE `pro_updates` DISABLE KEYS */;
INSERT INTO `pro_updates` VALUES (1,4,0,'','','','module','',0,'','','http://update.joomlart.com/service/tracking/j16/.xml','',''),(2,4,0,'JA Amazon S3 for joomla 16','','com_com_jaamazons3','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/com_com_jaamazons3.xml','',''),(3,4,0,'JA Extenstion Manager Component j16','','com_com_jaextmanager','file','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/com_com_jaextmanager.xml','',''),(4,4,0,'JA Amazon S3 for joomla 2.5 & 3.x','','com_jaamazons3','component','',1,'2.5.7','','http://update.joomlart.com/service/tracking/j16/com_jaamazons3.xml','',''),(5,4,0,'JA Comment Package for Joomla 2.5 & 3.3','','com_jacomment','component','',1,'2.5.4','','http://update.joomlart.com/service/tracking/j16/com_jacomment.xml','https://www.joomlart.com/update-steps',''),(6,4,0,'JA Google Storage Package for J2.5 & J3.0','','com_jagooglestorage','component','',1,'1.0.0','','http://update.joomlart.com/service/tracking/j16/com_jagooglestorage.xml','',''),(7,4,0,'JA Job Board Package For J25','','com_jajobboard','component','',1,'1.0.6','','http://update.joomlart.com/service/tracking/j16/com_jajobboard.xml','',''),(8,4,0,'JA K2 Filter Package for J25 & J3.x','','com_jak2filter','component','',1,'1.2.8','','http://update.joomlart.com/service/tracking/j16/com_jak2filter.xml','https://www.joomlart.com/update-steps',''),(9,4,0,'JA K2 Filter Package for J25 & J30','','com_jak2fiter','component','',1,'1.0.4','','http://update.joomlart.com/service/tracking/j16/com_jak2fiter.xml','',''),(10,4,0,'JA Megafilter Component','','com_jamegafilter','component','',1,'1.0.7','','http://update.joomlart.com/service/tracking/j16/com_jamegafilter.xml','https://www.joomlart.com/update-steps',''),(11,4,0,'JA Showcase component for Joomla 1.7','','com_jashowcase','component','',1,'1.1.0','','http://update.joomlart.com/service/tracking/j16/com_jashowcase.xml','',''),(12,4,0,'JA Voice Package for Joomla 2.5 & 3.x','','com_javoice','component','',1,'1.1.0','','http://update.joomlart.com/service/tracking/j16/com_javoice.xml','',''),(13,4,0,'JA Appolio Theme for EasyBlog','','easyblog_theme_appolio','custom','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_appolio.xml','',''),(14,4,0,'JA Biz Theme for EasyBlog','','easyblog_theme_biz','custom','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_biz.xml','',''),(15,4,0,'JA Bookshop Theme for EasyBlog','','easyblog_theme_bookshop','custom','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_bookshop.xml','',''),(16,4,0,'Theme Community Plus for Easyblog J25 & J30','','easyblog_theme_community_plus','custom','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_community_plus.xml','',''),(17,4,0,'JA Decor Theme for EasyBlog','','easyblog_theme_decor','custom','',0,'1.1.1','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_decor.xml','',''),(18,4,0,'Theme Fixel for Easyblog J25 & J3x','','easyblog_theme_fixel','custom','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_fixel.xml','',''),(19,4,0,'Theme Magz for Easyblog J25 & J34','','easyblog_theme_magz','custom','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_magz.xml','',''),(20,4,0,'JA Muzic Theme for EasyBlog','','easyblog_theme_muzic','custom','',0,'1.1.1','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_muzic.xml','',''),(21,4,0,'JA Obelisk Theme for EasyBlog','','easyblog_theme_obelisk','custom','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_obelisk.xml','',''),(22,4,0,'JA Sugite Theme for EasyBlog','','easyblog_theme_sugite','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/easyblog_theme_sugite.xml','',''),(23,4,0,'JA Anion template for Joomla 3.x','','ja_anion','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_anion.xml','',''),(24,4,0,'JA Appolio Template','','ja_appolio','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j16/ja_appolio.xml','',''),(25,4,0,'JA Argo Template for J3x','','ja_argo','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j16/ja_argo.xml','',''),(26,4,0,'JA Beranis Template','','ja_beranis','template','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j16/ja_beranis.xml','',''),(27,4,0,'JA Bistro Template for Joomla 3.x','','ja_bistro','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_bistro.xml','',''),(28,4,0,'JA Blazes Template for J25 & J3x','','ja_blazes','template','',0,'2.5.6','','http://update.joomlart.com/service/tracking/j16/ja_blazes.xml','',''),(29,4,0,'JA Bookshop Template','','ja_bookshop','template','',0,'1.1.6','','http://update.joomlart.com/service/tracking/j16/ja_bookshop.xml','https://www.joomlart.com/update-steps',''),(30,4,0,'JA Brisk Template for J25 & J3x','','ja_brisk','template','',0,'1.1.4','','http://update.joomlart.com/service/tracking/j16/ja_brisk.xml','',''),(31,4,0,'JA Business Template for Joomla 3.x','','ja_business','template','',0,'2.5.6','','http://update.joomlart.com/service/tracking/j16/ja_business.xml','',''),(32,4,0,'JA Cloris Template for Joomla 3.x','','ja_cloris','template','',0,'2.5.4','','http://update.joomlart.com/service/tracking/j16/ja_cloris.xml','',''),(33,4,0,'JA Community PLus Template for Joomla 3.x','','ja_community_plus','template','',0,'2.5.4','','http://update.joomlart.com/service/tracking/j16/ja_community_plus.xml','',''),(34,4,0,'JA Decor Template','','ja_decor','template','',0,'1.1.7','','http://update.joomlart.com/service/tracking/j16/ja_decor.xml','https://www.joomlart.com/update-steps',''),(35,4,0,'JA Droid Template for Joomla 3.x','','ja_droid','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_droid.xml','',''),(36,4,0,'JA Edenite Template for J25 & J34','','ja_edenite','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_edenite.xml','https://www.joomlart.com/update-steps',''),(37,4,0,'JA Elastica Template for J25 & J3x','','ja_elastica','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_elastica.xml','https://www.joomlart.com/update-steps',''),(38,4,0,'JA Erio Template for Joomla 2.5 & 3.x','','ja_erio','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_erio.xml','',''),(39,4,0,'Ja Events Template for Joomla 2.5','','ja_events','template','',0,'2.5.6','','http://update.joomlart.com/service/tracking/j16/ja_events.xml','',''),(40,4,0,'JA Fubix Template for J25 & J3x','','ja_fubix','template','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j16/ja_fubix.xml','',''),(41,4,0,'JA Graphite Template for Joomla 3x','','ja_graphite','template','',0,'2.5.7','','http://update.joomlart.com/service/tracking/j16/ja_graphite.xml','',''),(42,4,0,'JA Hawkstore Template','','ja_hawkstore','template','',0,'1.1.1','','http://update.joomlart.com/service/tracking/j16/ja_hawkstore.xml','',''),(43,4,0,'JA Ironis Template for Joomla 2.5 & 3.x','','ja_ironis','template','',0,'2.5.6','','http://update.joomlart.com/service/tracking/j16/ja_ironis.xml','',''),(44,4,0,'JA Jason template','','ja_jason','template','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/ja_jason.xml','',''),(45,4,0,'JA Kranos Template for J2.5 & J3.x','','ja_kranos','template','',0,'2.5.7','','http://update.joomlart.com/service/tracking/j16/ja_kranos.xml','',''),(46,4,0,'JA Lens Template for Joomla 2.5 & 3.x','','ja_lens','template','',0,'1.0.7','','http://update.joomlart.com/service/tracking/j16/ja_lens.xml','',''),(47,4,0,'Ja Lime Template for Joomla 3x','','ja_lime','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_lime.xml','',''),(48,4,0,'JA Magz Template for J25 & J34','','ja_magz','template','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j16/ja_magz.xml','',''),(49,4,0,'JA Medicare Template','','ja_medicare','template','',0,'1.1.7','','http://update.joomlart.com/service/tracking/j16/ja_medicare.xml','',''),(50,4,0,'JA Mendozite Template for J25 & J32','','ja_mendozite','template','',0,'1.0.8','','http://update.joomlart.com/service/tracking/j16/ja_mendozite.xml','',''),(51,4,0,'JA Mero Template for J25 & J3x','','ja_mero','template','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j16/ja_mero.xml','',''),(52,4,0,'JA Mers Template for J25 & J3x','','ja_mers','template','',0,'1.0.8','','http://update.joomlart.com/service/tracking/j16/ja_mers.xml','',''),(53,4,0,'JA Methys Template for Joomla 3x','','ja_methys','template','',0,'2.5.7','','http://update.joomlart.com/service/tracking/j16/ja_methys.xml','',''),(54,4,0,'Ja Minisite Template for Joomla 3.4','','ja_minisite','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_minisite.xml','',''),(55,4,0,'JA Mitius Template','','ja_mitius','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j16/ja_mitius.xml','https://www.joomlart.com/update-steps',''),(56,4,0,'JA Mixmaz Template','','ja_mixmaz','template','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/ja_mixmaz.xml','',''),(57,4,0,'JA Nex Template for J25 & J30','','ja_nex','template','',0,'2.5.9','','http://update.joomlart.com/service/tracking/j16/ja_nex.xml','https://www.joomlart.com/update-steps',''),(58,4,0,'JA Nex T3 Template','','ja_nex_t3','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j16/ja_nex_t3.xml','https://www.joomlart.com/update-steps',''),(59,4,0,'JA Norite Template for J2.5 & J31','','ja_norite','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_norite.xml','',''),(60,4,0,'JA Nuevo template','','ja_nuevo','template','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/ja_nuevo.xml','https://www.joomlart.com/update-steps',''),(61,4,0,'JA Obelisk Template','','ja_obelisk','template','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j16/ja_obelisk.xml','https://www.joomlart.com/update-steps',''),(62,4,0,'JA Onepage Template','','ja_onepage','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j16/ja_onepage.xml','',''),(63,4,0,'JA ores template for Joomla 3.x','','ja_ores','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_ores.xml','',''),(64,4,0,'JA Orisite Template  for J25 & J3x','','ja_orisite','template','',0,'1.1.7','','http://update.joomlart.com/service/tracking/j16/ja_orisite.xml','',''),(65,4,0,'JA Playmag Template','','ja_playmag','template','',0,'1.1.6','','http://update.joomlart.com/service/tracking/j16/ja_playmag.xml','https://www.joomlart.com/update-steps',''),(66,4,0,'JA Portfolio Real Estate template for Joomla 1.6.x','','ja_portfolio','file','',0,'1.0.0 beta','','http://update.joomlart.com/service/tracking/j16/ja_portfolio.xml','',''),(67,4,0,'JA Portfolio Template for Joomla 3.x','','ja_portfolio_real_estate','template','',0,'2.5.6','','http://update.joomlart.com/service/tracking/j16/ja_portfolio_real_estate.xml','',''),(68,4,0,'JA Puresite Template for J25 & J3x','','ja_puresite','template','',0,'1.0.8','','http://update.joomlart.com/service/tracking/j16/ja_puresite.xml','',''),(69,4,0,'JA Purity II template for Joomla 2.5 & 3.2','','ja_purity_ii','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_purity_ii.xml','',''),(70,4,0,'JA Pyro Template for Joomla 3.x','','ja_pyro','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_pyro.xml','',''),(71,4,0,'JA Rasite Template for J34','','ja_rasite','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_rasite.xml','',''),(72,4,0,'JA Rave Template for Joomla 3.x','','ja_rave','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/ja_rave.xml','',''),(73,4,0,'JA Smashboard Template','','ja_smashboard','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j16/ja_smashboard.xml','',''),(74,4,0,'JA Social Template for Joomla 2.5','','ja_social','template','',0,'2.5.8','','http://update.joomlart.com/service/tracking/j16/ja_social.xml','https://www.joomlart.com/update-steps',''),(75,4,0,'JA Social T3 Template for J25 & J3x','','ja_social_ii','template','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j16/ja_social_ii.xml','',''),(76,4,0,'JA Social T3 Template for J25 & J3x','','ja_social_t3','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j16/ja_social_t3.xml','',''),(77,4,0,'JA Sugite Template','','ja_sugite','template','',0,'1.1.6','','http://update.joomlart.com/service/tracking/j16/ja_sugite.xml','',''),(78,4,0,'JA System Pager Plugin for J25 & J3x','','ja_system_japager','plugin','ja_system_japager',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/ja_system_japager.xml','https://www.joomlart.com/update-steps',''),(79,4,0,'JA T3V2 Blank Template','','ja_t3_blank','template','',0,'2.5.8','','http://update.joomlart.com/service/tracking/j16/ja_t3_blank.xml','https://www.joomlart.com/update-steps',''),(80,4,0,'JA T3 Blank template for joomla 1.6','','ja_t3_blank_j16','template','',0,'1.0.0 Beta','','http://update.joomlart.com/service/tracking/j16/ja_t3_blank_j16.xml','',''),(81,4,0,'JA Blank Template for T3v3','','ja_t3v3_blank','template','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/ja_t3v3_blank.xml','',''),(82,4,0,'JA Teline III  Template for Joomla 1.6','','ja_teline_iii','file','',0,'1.0.0 Beta','','http://update.joomlart.com/service/tracking/j16/ja_teline_iii.xml','',''),(83,4,0,'JA Teline IV Template for J2.5 and J3.2','','ja_teline_iv','template','',0,'2.5.4','','http://update.joomlart.com/service/tracking/j16/ja_teline_iv.xml','',''),(84,4,0,'JA Teline IV T3 Template','','ja_teline_iv_t3','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j16/ja_teline_iv_t3.xml','https://www.joomlart.com/update-steps',''),(85,4,0,'JA Tiris Template for J25 & J3x','','ja_tiris','template','',0,'2.5.9','','http://update.joomlart.com/service/tracking/j16/ja_tiris.xml','',''),(86,4,0,'JA Travel Template for Joomla 3x','','ja_travel','template','',0,'2.5.6','','http://update.joomlart.com/service/tracking/j16/ja_travel.xml','',''),(87,4,0,'JA University Template for J25 & J32','','ja_university','template','',0,'1.0.6','','http://update.joomlart.com/service/tracking/j16/ja_university.xml','',''),(88,4,0,'JA University T3 template','','ja_university_t3','template','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/ja_university_t3.xml','',''),(89,4,0,'JA Vintas Template for J25 & J31','','ja_vintas','template','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/ja_vintas.xml','',''),(90,4,0,'JA Wall Template for J25 & J3x','','ja_wall','template','',0,'1.2.2','','http://update.joomlart.com/service/tracking/j16/ja_wall.xml','https://www.joomlart.com/update-steps',''),(91,4,0,'JA ZiteTemplate','','ja_zite','template','',0,'1.0.6','','http://update.joomlart.com/service/tracking/j16/ja_zite.xml','',''),(92,4,0,'JA Bookmark plugin for Joomla 1.6.x','','jabookmark','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jabookmark.xml','',''),(93,4,0,'JA Comment plugin for Joomla 1.6.x','','jacomment','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jacomment.xml','',''),(94,4,0,'JA Comment Off Plugin for Joomla 1.6','','jacommentoff','file','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/jacommentoff.xml','',''),(95,4,0,'JA Comment On Plugin for Joomla 1.6','','jacommenton','file','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/jacommenton.xml','',''),(96,4,0,'JA Content Extra Fields for Joomla 1.6','','jacontentextrafields','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jacontentextrafields.xml','',''),(97,4,0,'JA Disqus Debate Echo plugin for Joomla 1.6.x','','jadisqus_debate_echo','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jadisqus_debate_echo.xml','',''),(98,4,0,'JA System Google Map plugin for Joomla 1.6.x','','jagooglemap','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jagooglemap.xml','',''),(99,4,0,'JA Google Translate plugin for Joomla 1.6.x','','jagoogletranslate','plugin','jagoogletranslate',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jagoogletranslate.xml','',''),(100,4,0,'JA Highslide plugin for Joomla 1.6.x','','jahighslide','plugin','jahighslide',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jahighslide.xml','',''),(101,4,0,'JA K2 Search Plugin for Joomla 2.5','','jak2_filter','plugin','jak2_filter',0,'1.0.0 Alpha','','http://update.joomlart.com/service/tracking/j16/jak2_filter.xml','',''),(102,4,0,'JA K2 Extra Fields Plugin for Joomla 2.5','','jak2_indexing','plugin','jak2_indexing',0,'1.0.0 Alpha','','http://update.joomlart.com/service/tracking/j16/jak2_indexing.xml','',''),(103,4,0,'JA Load module Plugin for Joomla 2.5','','jaloadmodule','plugin','jaloadmodule',0,'2.5.1','','http://update.joomlart.com/service/tracking/j16/jaloadmodule.xml','',''),(104,4,0,'JA System Nrain plugin for Joomla 1.6.x','','janrain','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/janrain.xml','',''),(105,4,0,'JA Popup plugin for Joomla 1.6','','japopup','file','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/japopup.xml','',''),(106,4,0,'JA System Social plugin for Joomla 1.7','','jasocial','file','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/jasocial.xml','',''),(107,4,0,'JA T3 System plugin for Joomla 1.6','','jat3','plugin','jat3',0,'1.0.0 Beta','','http://update.joomlart.com/service/tracking/j16/jat3.xml','',''),(108,4,0,'JA Tabs plugin for Joomla 1.6.x','','jatabs','plugin','jatabs',0,'2.5.6','','http://update.joomlart.com/service/tracking/j16/jatabs.xml','',''),(109,4,0,'JA Typo plugin For Joomla 1.6','','jatypo','plugin','jatypo',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jatypo.xml','',''),(110,4,0,'Jomsocial Theme 3.x for JA Social','','jomsocial_theme_social','custom','',0,'4.1.x','','http://update.joomlart.com/service/tracking/j16/jomsocial_theme_social.xml','',''),(111,4,0,'JA Jomsocial theme for Joomla 2.5','','jomsocial_theme_social_j16','file','',0,'2.5.1','','http://update.joomlart.com/service/tracking/j16/jomsocial_theme_social_j16.xml','',''),(112,4,0,'JA Jomsocial theme for Joomla 2.5','','jomsocial_theme_social_j16_26','custom','',0,'2.5.4','','http://update.joomlart.com/service/tracking/j16/jomsocial_theme_social_j16_26.xml','',''),(113,4,0,'JShopping Template for Ja Orisite','','jshopping_theme_orisite','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jshopping_theme_orisite.xml','',''),(114,4,0,'JA Tiris Jshopping theme for J25 & J3x','','jshopping_theme_tiris','custom','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/jshopping_theme_tiris.xml','',''),(115,4,0,'Theme for Jshopping j17','','jshopping_theme_tiris_j17','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/jshopping_theme_tiris_j17.xml','',''),(116,4,0,'JA Kranos kunena theme for Joomla 3.x','','kunena_theme_kranos_j17','custom','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/kunena_theme_kranos_j17.xml','',''),(117,4,0,'Kunena Template for JA Mendozite','','kunena_theme_mendozite','custom','',0,'1.0.6','','http://update.joomlart.com/service/tracking/j16/kunena_theme_mendozite.xml','',''),(118,4,0,'JA Mitius Kunena Theme for Joomla 25 ','','kunena_theme_mitius','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/kunena_theme_mitius.xml','',''),(119,4,0,'Kunena theme for JA Nex J2.5','','kunena_theme_nex_j17','custom','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/kunena_theme_nex_j17.xml','',''),(120,4,0,'Kunena theme for JA Nex T3','','kunena_theme_nex_t3','custom','',0,'1.0.7','','http://update.joomlart.com/service/tracking/j16/kunena_theme_nex_t3.xml','',''),(121,4,0,'Kunena Template for Ja Orisite','','kunena_theme_orisite','custom','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/kunena_theme_orisite.xml','',''),(122,4,0,'Kunena theme for ja PlayMag','','kunena_theme_playmag','custom','',0,'1.1.6','','http://update.joomlart.com/service/tracking/j16/kunena_theme_playmag.xml','',''),(123,4,0,'Kunena theme for JA Social T3','','kunena_theme_social','custom','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j16/kunena_theme_social.xml','',''),(124,4,0,'Kunena theme for Joomla 2.5','','kunena_theme_social_j16','custom','',0,'2.5.1','','http://update.joomlart.com/service/tracking/j16/kunena_theme_social_j16.xml','',''),(125,4,0,'Kunena theme for ja Techzone','','kunena_theme_techzone','custom','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j16/kunena_theme_techzone.xml','',''),(126,4,0,'JA Tiris kunena theme for Joomla 2.5','','kunena_theme_tiris_j16','custom','',0,'2.5.3','','http://update.joomlart.com/service/tracking/j16/kunena_theme_tiris_j16.xml','',''),(127,4,0,'JA Bookshop Theme for Mijoshop V2','','mijoshop_theme_bookshop','custom','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/mijoshop_theme_bookshop.xml','',''),(128,4,0,'JA Decor Theme for Mijoshop','','mijoshop_theme_decor','custom','',0,'1.0.5','','http://update.joomlart.com/service/tracking/j16/mijoshop_theme_decor.xml','',''),(129,4,0,'JA Decor Theme for Mijoshop V3','','mijoshop_theme_decor_v3','custom','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j16/mijoshop_theme_decor_v3.xml','',''),(130,4,0,'JA ACM Module','','mod_ja_acm','module','',0,'2.1.2','','http://update.joomlart.com/service/tracking/j16/mod_ja_acm.xml','https://www.joomlart.com/update-steps',''),(131,4,0,'JA Jobs Tags module for Joomla 2.5','','mod_ja_jobs_tags','module','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/mod_ja_jobs_tags.xml','',''),(132,4,0,'JA Accordion Module for J25 & J34','','mod_jaaccordion','module','',0,'2.6.0','','http://update.joomlart.com/service/tracking/j16/mod_jaaccordion.xml','',''),(133,4,0,'JA Animation module for Joomla 2.5 & 3.2','','mod_jaanimation','module','',0,'2.5.3','','http://update.joomlart.com/service/tracking/j16/mod_jaanimation.xml','',''),(134,4,0,'JA Bulletin Module for J3.x','','mod_jabulletin','module','',0,'2.6.0','','http://update.joomlart.com/service/tracking/j16/mod_jabulletin.xml','',''),(135,4,0,'JA Latest Comment Module for Joomla 2.5 & 3.3','','mod_jaclatest_comments','module','',0,'2.5.4','','http://update.joomlart.com/service/tracking/j16/mod_jaclatest_comments.xml','',''),(136,4,0,'JA Content Popup Module for J25 & J34','','mod_jacontentpopup','module','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j16/mod_jacontentpopup.xml','https://www.joomlart.com/update-steps',''),(137,4,0,'JA Content Scroll module for Joomla 1.6','','mod_jacontentscroll','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/mod_jacontentscroll.xml','',''),(138,4,0,'JA Contenslider module for Joomla 1.6','','mod_jacontentslide','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/mod_jacontentslide.xml','',''),(139,4,0,'JA Content Slider Module for J25 & J34','','mod_jacontentslider','module','',0,'2.7.2','','http://update.joomlart.com/service/tracking/j16/mod_jacontentslider.xml','https://www.joomlart.com/update-steps',''),(140,4,0,'JA CountDown Module for Joomla 2.5 & 3.4','','mod_jacountdown','module','',0,'1.0.7','','http://update.joomlart.com/service/tracking/j16/mod_jacountdown.xml','https://www.joomlart.com/update-steps',''),(141,4,0,'JA Facebook Activity Module for J25 & J30','','mod_jafacebookactivity','module','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/mod_jafacebookactivity.xml','',''),(142,4,0,'JA Facebook Like Box Module for Joonla 25 & 34','','mod_jafacebooklikebox','module','',0,'2.6.1','','http://update.joomlart.com/service/tracking/j16/mod_jafacebooklikebox.xml','https://www.joomlart.com/update-steps',''),(143,4,0,'JA Featured Employer module for Joomla 2.5','','mod_jafeatured_employer','module','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/mod_jafeatured_employer.xml','',''),(144,4,0,'JA Filter Jobs module for Joomla 2.5','','mod_jafilter_jobs','module','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/mod_jafilter_jobs.xml','',''),(145,4,0,'JA flowlist module for Joomla 2.5 & 3.0','','mod_jaflowlist','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/mod_jaflowlist.xml','',''),(146,4,0,'JA Google chart 2','','mod_jagooglechart_2','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/mod_jagooglechart_2.xml','https://www.joomlart.com/update-steps',''),(147,4,0,'JAEC Halloween Module for Joomla 2.5 & 3','','mod_jahalloween','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/mod_jahalloween.xml','',''),(148,4,0,'JA Image Hotspot Module for Joomla 2.5 & 3.4','','mod_jaimagehotspot','module','',0,'1.1.1','','http://update.joomlart.com/service/tracking/j16/mod_jaimagehotspot.xml','https://www.joomlart.com/update-steps',''),(149,4,0,'JA static module for Joomla 2.5','','mod_jajb_statistic','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/mod_jajb_statistic.xml','',''),(150,4,0,'JA Jobboard Menu module for Joomla 2.5','','mod_jajobboard_menu','module','',0,'1.0.5','','http://update.joomlart.com/service/tracking/j16/mod_jajobboard_menu.xml','',''),(151,4,0,'JA Jobs Counter module for Joomla 2.5','','mod_jajobs_counter','module','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/mod_jajobs_counter.xml','',''),(152,4,0,'JA Jobs Map module for Joomla 2.5','','mod_jajobs_map','module','',0,'1.0.5','','http://update.joomlart.com/service/tracking/j16/mod_jajobs_map.xml','',''),(153,4,0,'JA K2 Fillter Module for Joomla 2.5','','mod_jak2_filter','module','',0,'1.0.0 Alpha','','http://update.joomlart.com/service/tracking/j16/mod_jak2_filter.xml','',''),(154,4,0,'JA K2 Filter Module for J25 & J3.x','','mod_jak2filter','module','',0,'1.2.8','','http://update.joomlart.com/service/tracking/j16/mod_jak2filter.xml','https://www.joomlart.com/update-steps',''),(155,4,0,'JA K2 Timeline','','mod_jak2timeline','module','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j16/mod_jak2timeline.xml','',''),(156,4,0,'JA Latest Resumes module for Joomla 2.5','','mod_jalatest_resumes','module','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/mod_jalatest_resumes.xml','',''),(157,4,0,'JA List Employer module for Joomla 2.5','','mod_jalist_employers','module','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/mod_jalist_employers.xml','',''),(158,4,0,'JA List Jobs module for Joomla 2.5','','mod_jalist_jobs','module','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j16/mod_jalist_jobs.xml','',''),(159,4,0,'JA List Resumes module for Joomla 2.5','','mod_jalist_resumes','module','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j16/mod_jalist_resumes.xml','',''),(160,4,0,'JA Login module for J25 & J3x','','mod_jalogin','module','',0,'2.6.7','','http://update.joomlart.com/service/tracking/j16/mod_jalogin.xml','https://www.joomlart.com/update-steps',''),(161,4,0,'JA Masshead Module for J25 & J34','','mod_jamasshead','module','',0,'2.6.1','','http://update.joomlart.com/service/tracking/j16/mod_jamasshead.xml','https://www.joomlart.com/update-steps',''),(162,4,0,'JA News Featured Module for J25 & J34','','mod_janews_featured','module','',0,'2.6.1','','http://update.joomlart.com/service/tracking/j16/mod_janews_featured.xml','',''),(163,4,0,'JA Newsflash module for Joomla 1.6.x','','mod_janewsflash','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/mod_janewsflash.xml','',''),(164,4,0,'JA Newsmoo module for Joomla 1.6.x','','mod_janewsmoo','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/mod_janewsmoo.xml','',''),(165,4,0,'JA News Pro module for Joomla 1.6 ','','mod_janewspro','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/mod_janewspro.xml','',''),(166,4,0,'JA Newsticker Module for J3x','','mod_janewsticker','module','',0,'2.6.2','','http://update.joomlart.com/service/tracking/j16/mod_janewsticker.xml','https://www.joomlart.com/update-steps',''),(167,4,0,'JA Quick Contact Module for J3.x','','mod_jaquickcontact','module','',0,'2.6.1','','http://update.joomlart.com/service/tracking/j16/mod_jaquickcontact.xml','https://www.joomlart.com/update-steps',''),(168,4,0,'JA Recent Viewed Jobs module for Joomla 2.5','','mod_jarecent_viewed_jobs','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/mod_jarecent_viewed_jobs.xml','',''),(169,4,0,'JA SideNews Module for J25 & J34','','mod_jasidenews','module','',0,'2.6.7','','http://update.joomlart.com/service/tracking/j16/mod_jasidenews.xml','https://www.joomlart.com/update-steps',''),(170,4,0,'JA Slideshow Module for Joomla 2.5 & 3.x','','mod_jaslideshow','module','',0,'2.7.5','','http://update.joomlart.com/service/tracking/j16/mod_jaslideshow.xml','https://www.joomlart.com/update-steps',''),(171,4,0,'JA Slideshow Lite Module for J25 & J3.4','','mod_jaslideshowlite','module','',0,'1.2.3','','http://update.joomlart.com/service/tracking/j16/mod_jaslideshowlite.xml','https://www.joomlart.com/update-steps',''),(172,4,0,'JA Soccerway Module for J25 & J33','','mod_jasoccerway','module','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/mod_jasoccerway.xml','',''),(173,4,0,'JA Social Locker module','','mod_jasocial_locker','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/mod_jasocial_locker.xml','',''),(174,4,0,'JA Tab module for Joomla 2.5','','mod_jatabs','module','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j16/mod_jatabs.xml','',''),(175,4,0,'JA Toppanel Module for Joomla 2.5 & Joomla 3.4','','mod_jatoppanel','module','',0,'2.5.8','','http://update.joomlart.com/service/tracking/j16/mod_jatoppanel.xml','',''),(176,4,0,'JA Twitter Module for J25 & J3.4','','mod_jatwitter','module','',0,'2.6.5','','http://update.joomlart.com/service/tracking/j16/mod_jatwitter.xml','https://www.joomlart.com/update-steps',''),(177,4,0,'JA List of Voices Module for J2.5 & J3.x','','mod_javlist_voices','module','',0,'1.1.0','','http://update.joomlart.com/service/tracking/j16/mod_javlist_voices.xml','',''),(178,4,0,'JA VMProducts Module','','mod_javmproducts','module','',0,'1.0.5','','http://update.joomlart.com/service/tracking/j16/mod_javmproducts.xml','',''),(179,4,0,'JA Voice  Work Flow Module for J2.5 & J3.x','','mod_javwork_flow','module','',0,'1.1.0','','http://update.joomlart.com/service/tracking/j16/mod_javwork_flow.xml','',''),(180,4,0,'JA Amazon S3 Button Plugin for joomla 2.5 & 3.x','','jaamazons3','plugin','button',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/plg_button_jaamazons3.xml','',''),(181,4,0,'JA AVTracklist Button plugin for J2.5 & J3.3','','jaavtracklist','plugin','button',0,'1.0.1','','http://update.joomlart.com/service/tracking/j16/plg_button_jaavtracklist.xml','',''),(182,4,0,'JA Comment Off Plugin for Joomla 2.5 & 3.3','','jacommentoff','plugin','button',0,'2.5.3','','http://update.joomlart.com/service/tracking/j16/plg_button_jacommentoff.xml','https://www.joomlart.com/update-steps',''),(183,4,0,'JA Comment On Plugin for Joomla 2.5 & 3.3','','jacommenton','plugin','button',0,'2.5.2','','http://update.joomlart.com/service/tracking/j16/plg_button_jacommenton.xml','',''),(184,4,0,'JA Amazon S3 System plugin for joomla 2.5 & 3.x','','plg_jaamazons3','plugin','plg_jaamazons3',0,'2.5.7','','http://update.joomlart.com/service/tracking/j16/plg_jaamazons3.xml','',''),(185,4,0,'JA AVTracklist plugin for J2.5 & J3.x','','plg_jaavtracklist','plugin','plg_jaavtracklist',0,'1.0.4','','http://update.joomlart.com/service/tracking/j16/plg_jaavtracklist.xml','',''),(186,4,0,'JA Bookmark plugin for J3.x','','plg_jabookmark','plugin','plg_jabookmark',0,'2.6.2','','http://update.joomlart.com/service/tracking/j16/plg_jabookmark.xml','https://www.joomlart.com/update-steps',''),(187,4,0,'JA Comment Plugin for Joomla 2.5 & 3.3','','plg_jacomment','plugin','plg_jacomment',0,'2.5.4','','http://update.joomlart.com/service/tracking/j16/plg_jacomment.xml','https://www.joomlart.com/update-steps',''),(188,4,0,'JA Disqus Debate Echo plugin for J3x','','debate_echo','plugin','jadisqus',0,'2.6.3','','http://update.joomlart.com/service/tracking/j16/plg_jadisqus_debate_echo.xml','',''),(189,4,0,'JA Google Storage Plugin for j25 & j30','','plg_jagooglestorage','plugin','plg_jagooglestorage',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_jagooglestorage.xml','',''),(190,4,0,'JA Translate plugin for Joomla 1.6.x','','plg_jagoogletranslate','file','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_jagoogletranslate.xml','',''),(191,4,0,'JA Megafilter VirtueMart Plugin','','virtuemart','plugin','jamegafilter',0,'1.0.7','','http://update.joomlart.com/service/tracking/j16/plg_jamegafilter_virtuemart.xml','https://www.joomlart.com/update-steps',''),(192,4,0,'JA Thumbnail Plugin for J25 & J3','','plg_jathumbnail','plugin','plg_jathumbnail',0,'2.5.9','','http://update.joomlart.com/service/tracking/j16/plg_jathumbnail.xml','https://www.joomlart.com/update-steps',''),(193,4,0,'JA Tooltips plugin for Joomla 1.6.x','','plg_jatooltips','plugin','plg_jatooltips',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_jatooltips.xml','',''),(194,4,0,'JA Typo Button Plugin for J25 & J3x','','plg_jatypobutton','plugin','plg_jatypobutton',0,'2.6.0','','http://update.joomlart.com/service/tracking/j16/plg_jatypobutton.xml','',''),(195,4,0,'JA K2 Filter Plg for J25 & J3.x','','jak2filter','plugin','k2',0,'1.2.1','','http://update.joomlart.com/service/tracking/j16/plg_k2_jak2filter.xml','https://www.joomlart.com/update-steps',''),(196,4,0,'JA K2 Timeline Plugin','','jak2timeline','plugin','k2',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_k2_jak2timeline.xml','',''),(197,4,0,'Multi Captcha Engine Plugin for J3.x','','captcha_engine','plugin','multiple',0,'2.5.3','','http://update.joomlart.com/service/tracking/j16/plg_multiple_captcha_engine.xml','',''),(198,4,0,'JA JobBoard Payment Plugin Authorize for Joomla 2.5','','plg_payment_jajb_authorize_25','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_payment_jajb_authorize_25.xml','',''),(199,4,0,'JA JobBoard Payment Plugin MoneyBooker for Joomla 2.5','','plg_payment_jajb_moneybooker_25','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_payment_jajb_moneybooker_25.xml','',''),(200,4,0,'JA JobBoard Payment Plugin Paypal for Joomla 2.5','','plg_payment_jajb_paypal_25','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_payment_jajb_paypal_25.xml','',''),(201,4,0,'JA JobBoard Payment Plugin BankWire for Joomla 2.5','','plg_payment_jajb_wirebank_25','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_payment_jajb_wirebank_25.xml','',''),(202,4,0,'JA Search Comment Plugin for Joomla J2.5 & 3.0','','jacomment','plugin','search',0,'2.5.2','','http://update.joomlart.com/service/tracking/j16/plg_search_jacomment.xml','',''),(203,4,0,'JA Search Jobs plugin for Joomla 2.5','','jajob','plugin','search',0,'1.0.0 stable','','http://update.joomlart.com/service/tracking/j16/plg_search_jajob.xml','',''),(204,4,0,'JA System Comment Plugin for Joomla 2.5 & 3.3','','jacomment','plugin','system',0,'2.5.4','','http://update.joomlart.com/service/tracking/j16/plg_system_jacomment.xml','',''),(205,4,0,'JA Content Extra Fields for Joomla 2.5','','jacontentextrafields','plugin','system',0,'2.5.1','','http://update.joomlart.com/service/tracking/j16/plg_system_jacontentextrafields.xml','',''),(206,4,0,'JA System Google Map plugin for Joomla 2.5 & J3.x','','jagooglemap','plugin','system',0,'2.6.4','','http://update.joomlart.com/service/tracking/j16/plg_system_jagooglemap.xml','https://www.joomlart.com/update-steps',''),(207,4,0,'JAEC PLG System Jobboad Jomsocial Synchonization','','jajb_jomsocial','plugin','system',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/plg_system_jajb_jomsocial.xml','',''),(208,4,0,'JA System Lazyload Plugin for J25 & J3x','','jalazyload','plugin','system',0,'1.0.7','','http://update.joomlart.com/service/tracking/j16/plg_system_jalazyload.xml','https://www.joomlart.com/update-steps',''),(209,4,0,'JA Megafilter Plugin','','jamegafilter','plugin','system',0,'1.0.0 Beta 1','','http://update.joomlart.com/service/tracking/j16/plg_system_jamegafilter.xml','',''),(210,4,0,'JA System Nrain Plugin for Joomla 2.5 & 3.3','','janrain','plugin','system',0,'2.5.4','','http://update.joomlart.com/service/tracking/j16/plg_system_janrain.xml','',''),(211,4,0,'JA System Pager Plugin for J25 & J3x','','japager','plugin','system',0,'1.0.5','','http://update.joomlart.com/service/tracking/j16/plg_system_japager.xml','https://www.joomlart.com/update-steps',''),(212,4,0,'JA Popup Plugin for Joomla 25 & 34','','japopup','plugin','system',0,'2.6.3','','http://update.joomlart.com/service/tracking/j16/plg_system_japopup.xml','https://www.joomlart.com/update-steps',''),(213,4,0,'JA System Social Plugin for Joomla 3.x','','jasocial','plugin','system',0,'2.5.5','','http://update.joomlart.com/service/tracking/j16/plg_system_jasocial.xml','',''),(214,4,0,'JA System Social Feed Plugin for Joomla 2.5 & 3.x','','jasocial_feed','plugin','system',0,'1.3.0','','http://update.joomlart.com/service/tracking/j16/plg_system_jasocial_feed.xml','https://www.joomlart.com/update-steps',''),(215,4,0,'JA T3v2 System Plugin for J3.x','','jat3','plugin','system',0,'2.7.2','','http://update.joomlart.com/service/tracking/j16/plg_system_jat3.xml','https://www.joomlart.com/update-steps',''),(216,4,0,'JA T3v3 System Plugin','','jat3v3','plugin','system',0,'1.0.3','','http://update.joomlart.com/service/tracking/j16/plg_system_jat3v3.xml','',''),(217,4,0,'JA Tabs Plugin for J3.x','','jatabs','plugin','system',0,'2.6.6','','http://update.joomlart.com/service/tracking/j16/plg_system_jatabs.xml','',''),(218,4,0,'JA Typo Plugin for Joomla 2.5 & J34','','jatypo','plugin','system',0,'2.5.7','','http://update.joomlart.com/service/tracking/j16/plg_system_jatypo.xml','',''),(219,4,0,'T3 B3 Blank Template','','t3_bs3_blank','template','',0,'2.1.4','','http://update.joomlart.com/service/tracking/j16/t3_bs3_blank.xml','',''),(220,4,0,'JA Teline III Template for Joomla 2.5','','teline_iii','template','',0,'2.5.3','','http://update.joomlart.com/service/tracking/j16/teline_iii.xml','',''),(221,4,0,'Thirdparty Extensions Compatibility Bundle','','thirdparty_exts_compatibility','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j16/thirdparty_exts_compatibility.xml','',''),(222,4,0,'T3 Blank Template','','t3_blank','template','',0,'2.2.1','','http://update.joomlart.com/service/tracking/j16/tpl_t3_blank.xml','https://www.joomlart.com/update-steps',''),(223,4,0,'Uber Template','','uber','template','',0,'2.1.5','','http://update.joomlart.com/service/tracking/j16/uber.xml','https://www.joomlart.com/update-steps',''),(224,4,0,'Backend Template','','backend_template_package','template','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j30/backend_template_package.xml','',''),(225,4,0,'Backend Template','','backend_template_pkg','template','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j30/backend_template_pkg.xml','',''),(226,4,0,'JA Restaurant Template','','ja_restaurant','template','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j30/ja_restaurant.xml','https://www.joomlart.com/update-steps',''),(227,4,0,'T3 BS3 Blank Template','','t3_bs3_blank','template','',0,'2.2.1','','http://update.joomlart.com/service/tracking/j30/tpl_t3_bs3_blank.xml','',''),(228,4,0,'JA Builder Component','','com_jabuilder','component','',1,'1.0.1','','http://update.joomlart.com/service/tracking/j31/com_jabuilder.xml','https://www.joomlart.com/update-steps',''),(229,4,0,'JA K2 v3 Filter package for J33','','com_jak2v3filter','component','',1,'3.0.0 preview ','','http://update.joomlart.com/service/tracking/j31/com_jak2v3filter.xml','',''),(230,4,0,'JA Multilingual Component for Joomla 2.5 & 3.4','','com_jalang','component','',1,'1.1.0','','http://update.joomlart.com/service/tracking/j31/com_jalang.xml','https://www.joomlart.com/update-steps',''),(231,4,0,'JA Intranet Theme for EasyBlog','','easyblog_theme_intranet','custom','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/easyblog_theme_intranet.xml','',''),(232,4,0,'JA Resume Theme for EasyBlog','','easyblog_theme_resume','custom','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/easyblog_theme_resume.xml','',''),(233,4,0,'JA Sugite Theme for EasyBlog','','easyblog_theme_sugite','custom','',0,'1.1.1','','http://update.joomlart.com/service/tracking/j31/easyblog_theme_sugite.xml','',''),(234,4,0,'JA Intranet Theme for EasySocialv1 ','','easysocial1_support_intranet','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/easysocial1_support_intranet.xml','',''),(235,4,0,'JA Social II Support EasySocial1','','easysocial1_support_social_ii','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/easysocial1_support_social_ii.xml','',''),(236,4,0,'JA Alumni Template','','ja_alumni','template','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/ja_alumni.xml','https://www.joomlart.com/update-steps',''),(237,4,0,'JA Biz Template','','ja_biz','template','',0,'1.1.6','','http://update.joomlart.com/service/tracking/j31/ja_biz.xml','',''),(238,4,0,'JA Brickstore Template','','ja_brickstore','template','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/ja_brickstore.xml','',''),(239,4,0,'JA Builder Template','','ja_builder','template','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/ja_builder.xml','https://www.joomlart.com/update-steps',''),(240,4,0,'JA Builder Package','','ja_builder_pkg','package','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/ja_builder_pkg.xml','https://www.joomlart.com/update-steps',''),(241,4,0,'JA Cago template','','ja_cago','template','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/ja_cago.xml','',''),(242,4,0,'JA Cagox template','','ja_cagox','template','',0,'1.0.6','','http://update.joomlart.com/service/tracking/j31/ja_cagox.xml','https://www.joomlart.com/update-steps',''),(243,4,0,'JA Charity template','','ja_charity','template','',0,'1.0.5','','http://update.joomlart.com/service/tracking/j31/ja_charity.xml','',''),(244,4,0,'JA Directory Template','','ja_directory','template','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j31/ja_directory.xml','',''),(245,4,0,'JA Edenite Template for J25 & J34','','ja_edenite','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j31/ja_edenite.xml','',''),(246,4,0,'JA Elicyon Template','','ja_elicyon','template','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/ja_elicyon.xml','',''),(247,4,0,'JA Events II template','','ja_events_ii','template','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j31/ja_events_ii.xml','',''),(248,4,0,'JA Fixel Template','','ja_fixel','template','',0,'1.1.5','','http://update.joomlart.com/service/tracking/j31/ja_fixel.xml','',''),(249,4,0,'JA Healthcare Template','','ja_healthcare','template','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/ja_healthcare.xml','',''),(250,4,0,'JA Hotel Template','','ja_hotel','template','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j31/ja_hotel.xml','',''),(251,4,0,'JA Intranet Template','','ja_intranet','template','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/ja_intranet.xml','',''),(252,4,0,'JA Magz II Template','','ja_magz_ii','template','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/ja_magz_ii.xml','',''),(253,4,0,'JA Megafilter Template','','ja_megafilter','template','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/ja_megafilter.xml','https://www.joomlart.com/update-steps',''),(254,4,0,'JA Megastore Template','','ja_megastore','template','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/ja_megastore.xml','',''),(255,4,0,'JA Mono Template','','ja_mono','template','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j31/ja_mono.xml','',''),(256,4,0,'JA Moviemax Template','','ja_moviemax','template','',0,'1.1.2','','http://update.joomlart.com/service/tracking/j31/ja_moviemax.xml','',''),(257,4,0,'JA Muzic Template','','ja_muzic','template','',0,'1.1.3','','http://update.joomlart.com/service/tracking/j31/ja_muzic.xml','',''),(258,4,0,'JA Oslo Template','','ja_oslo','template','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/ja_oslo.xml','',''),(259,4,0,'JA Platon Template','','ja_platon','template','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j31/ja_platon.xml','',''),(260,4,0,'JA Playstore Template','','ja_playstore','template','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j31/ja_playstore.xml','',''),(261,4,0,'JA Rave Template for Joomla 3.x','','ja_rave','template','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j31/ja_rave.xml','',''),(262,4,0,'JA Rent template','','ja_rent','template','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/ja_rent.xml','',''),(263,4,0,'JA Resume Template','','ja_resume','template','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/ja_resume.xml','',''),(264,4,0,'JA Simpli Template','','ja_simpli','template','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/ja_simpli.xml','https://www.joomlart.com/update-steps',''),(265,4,0,'JA Social II template','','ja_social_ii','template','',0,'1.0.6','','http://update.joomlart.com/service/tracking/j31/ja_social_ii.xml','https://www.joomlart.com/update-steps',''),(266,4,0,'JA Techzone Template','','ja_techzone','template','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/ja_techzone.xml','',''),(267,4,0,'JA Teline V Template','','ja_teline_v','template','',0,'1.1.0','','http://update.joomlart.com/service/tracking/j31/ja_teline_v.xml','',''),(268,4,0,'JA University Template for J25 & J32','','ja_university','template','',0,'1.0.7','','http://update.joomlart.com/service/tracking/j31/ja_university.xml','',''),(269,4,0,'JA University T3 template','','ja_university_t3','template','',0,'1.1.5','','http://update.joomlart.com/service/tracking/j31/ja_university_t3.xml','',''),(270,4,0,'JA Vintas Template for J25 & J3x','','ja_vintas','template','',0,'1.0.5','','http://update.joomlart.com/service/tracking/j31/ja_vintas.xml','',''),(271,4,0,'JA Wall Template for J25 & J34','','ja_wall','template','',0,'1.2.1','','http://update.joomlart.com/service/tracking/j31/ja_wall.xml','',''),(272,4,0,'Jomsocial theme for Platon','','jomsocial_theme_platon','custom','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/jomsocial_theme_platon.xml','',''),(273,4,0,'Theme Fixel for JShopping J25 & J30','','jshopping_theme_fixel','custom','',0,'1.0.6','','http://update.joomlart.com/service/tracking/j31/jshopping_theme_fixel.xml','',''),(274,4,0,'JA Tiris Jshopping theme for J3x','','jshopping_theme_tiris_j3x','custom','',0,'2.5.6','','http://update.joomlart.com/service/tracking/j31/jshopping_theme_tiris_j3x.xml','',''),(275,4,0,'JA Mitius Kunena Theme for Joomla 3x','','kunena_theme_mitius','custom','',0,'1.0.5','','http://update.joomlart.com/service/tracking/j31/kunena_theme_mitius.xml','',''),(276,4,0,'JA Tiris Kunena Theme for Joomla 3x','','kunena_theme_mitius_j31','custom','',0,'2.5.4','','http://update.joomlart.com/service/tracking/j31/kunena_theme_mitius_j31.xml','',''),(277,4,0,'Kunena Theme MovieMax','','kunena_theme_moviemax','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/kunena_theme_moviemax.xml','',''),(278,4,0,'Kunena Theme Platon','','kunena_theme_platon','custom','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/kunena_theme_platon.xml','',''),(279,4,0,'Kunena Theme Playstore','','kunena_theme_playstore','custom','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/kunena_theme_playstore.xml','',''),(280,4,0,'JA Tiris Kunena Theme for Joomla 3x','','kunena_theme_tiris_j3x','custom','',0,'2.5.5','','http://update.joomlart.com/service/tracking/j31/kunena_theme_tiris_j3x.xml','',''),(281,4,0,'Mijoshop Modules Accordion','','mijoshop_mod_accordion','custom','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/mijoshop_mod_accordion.xml','',''),(282,4,0,'Mijoshop V3 Modules Accordion','','mijoshop_mod_accordion_v3','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/mijoshop_mod_accordion_v3.xml','',''),(283,4,0,'Mijoshop Modules Slider','','mijoshop_mod_slider','custom','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/mijoshop_mod_slider.xml','',''),(284,4,0,'Mijoshop V3 Modules Slider','','mijoshop_mod_slider_v3','custom','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/mijoshop_mod_slider_v3.xml','',''),(285,4,0,'JA Bookshop Theme for Mijoshop V3','','mijoshop_theme_bookshop_v3','custom','',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/mijoshop_theme_bookshop_v3.xml','',''),(286,4,0,'JA Google Analytics Frontend','','mod_ja_ga','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/mod_ja_ga.xml','',''),(287,4,0,'JA Latest  Article Module','','mod_jaarticles_latest','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/mod_jaarticles_latest.xml','',''),(288,4,0,'JA Builder Admin Menu Module','','mod_jabuilder_admin_menu','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/mod_jabuilder_admin_menu.xml','https://www.joomlart.com/update-steps',''),(289,4,0,'JA Builder Quickicons Module','','mod_jabuilder_quickicons','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/mod_jabuilder_quickicons.xml','https://www.joomlart.com/update-steps',''),(290,4,0,'JA Google Analytics','','mod_jagoogle_analytics','module','',0,'1.0.4','','http://update.joomlart.com/service/tracking/j31/mod_jagoogle_analytics.xml','',''),(291,4,0,'JA Google Chart Module','','mod_jagooglechart','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/mod_jagooglechart.xml','',''),(292,4,0,'JA Halloween Game for Joomla 3.x','','mod_jahalloweengame','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/mod_jahalloweengame.xml','',''),(293,4,0,'JA K2 v3 Filter Module for J33','','mod_jak2v3filter','module','',0,'3.0.0 preview ','','http://update.joomlart.com/service/tracking/j31/mod_jak2v3filter.xml','',''),(294,4,0,'JA Masthead Module ','','mod_jamasthead','module','',0,'1.0.3','','http://update.joomlart.com/service/tracking/j31/mod_jamasthead.xml','https://www.joomlart.com/update-steps',''),(295,4,0,'JA Megafilter Module','','mod_jamegafilter','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/mod_jamegafilter.xml','https://www.joomlart.com/update-steps',''),(296,4,0,'JA Promo Bar module','','mod_japromobar','module','',0,'1.0.5','','http://update.joomlart.com/service/tracking/j31/mod_japromobar.xml','https://www.joomlart.com/update-steps',''),(297,4,0,'Ja Yahoo Finance','','mod_jayahoo_finance','module','',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/mod_jayahoo_finance.xml','',''),(298,4,0,'Ja Yahoo Weather','','mod_jayahoo_weather','module','',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/mod_jayahoo_weather.xml','',''),(299,4,0,'Plugin Ajax JA Content Type','','jacontenttype','plugin','ajax',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/plg_ajax_jacontenttype.xml','https://www.joomlart.com/update-steps',''),(300,4,0,'JA K2 Data Migration plugin','','plg_jak2tocomcontentmigration','plugin','plg_jak2tocomcontent',0,'1.0.0 beta','','http://update.joomlart.com/service/tracking/j31/plg_jak2tocomcontentmigration.xml','',''),(301,4,0,'Plgin JA K2 import to Joomla Content','','plg_jak2tocontent','plugin','plg_jak2tocontent',0,'1.0.0 beta','','http://update.joomlart.com/service/tracking/j31/plg_jak2tocontent.xml','',''),(302,4,0,'JA Megafilter Joomla extra fields plugin','','content','plugin','jamegafilter',0,'1.0.0 beta','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_content.xml','https://www.joomlart.com/update-steps',''),(303,4,0,'JA Megafilter DOCman Plugin','','docman','plugin','jamegafilter',0,'1.0.2','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_docman.xml','https://www.joomlart.com/update-steps',''),(304,4,0,'JA Megafilter Eshop Plugin','','eshop','plugin','jamegafilter',0,'1.0.6','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_eshop.xml','https://www.joomlart.com/update-steps',''),(305,4,0,'JA Megafilter Hikashop Plugin','','hikashop','plugin','jamegafilter',0,'1.0.6','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_hikashop.xml','https://www.joomlart.com/update-steps',''),(306,4,0,'JA Megafilter J2store Plugin','','j2store','plugin','jamegafilter',0,'1.0.4','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_j2store.xml','https://www.joomlart.com/update-steps',''),(307,4,0,'JA Megafilter for Hikashop plg','','ja_hikashop','plugin','jamegafilter',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_ja_hikashop.xml','',''),(308,4,0,'JA Megafitler Jshopping plugin','','jshopping','plugin','jamegafilter',0,'1.0.5','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_jshopping.xml','https://www.joomlart.com/update-steps',''),(309,4,0,'JA Megafilter K2 Plugin','','k2','plugin','jamegafilter',0,'1.0.5','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_k2.xml','https://www.joomlart.com/update-steps',''),(310,4,0,'JA Megafilter Mijoshop Plugin','','mijoshop','plugin','jamegafilter',0,'1.0.3','','http://update.joomlart.com/service/tracking/j31/plg_jamegafilter_mijoshop.xml','https://www.joomlart.com/update-steps',''),(311,4,0,'JA K2 Extrafields','','jak2extrafields','plugin','k2',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/plg_k2_jak2extrafields.xml','',''),(312,4,0,'JA K2 v3 Filter Plugin for J33','','jak2v3filter','plugin','k2',0,'3.0.0 preview ','','http://update.joomlart.com/service/tracking/j31/plg_k2_jak2v3filter.xml','',''),(313,4,0,'JA System Designit Plugin','','designit','plugin','system',0,'1.0.0','','http://update.joomlart.com/service/tracking/j31/plg_system_designit.xml','https://www.joomlart.com/update-steps',''),(314,4,0,'JA Builder System Plugin','','jabuilder','plugin','system',0,'1.0.1','','http://update.joomlart.com/service/tracking/j31/plg_system_jabuilder.xml','https://www.joomlart.com/update-steps',''),(315,4,0,'Plugin JA Content Type','','jacontenttype','plugin','system',0,'1.0.5','','http://update.joomlart.com/service/tracking/j31/plg_system_jacontenttype.xml','https://www.joomlart.com/update-steps',''),(316,4,0,'T3 BS3 Blank Template','','t3_bs3_blank','template','',0,'2.2.1','','http://update.joomlart.com/service/tracking/j31/tpl_t3_bs3_blank.xml','https://www.joomlart.com/update-steps',''),(317,4,0,'Sample package for Uber App','','uber_app','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_app.xml','',''),(318,4,0,'Sample package for Bookstore','','uber_bookstore','sample_package','',0,'2.1.3','','http://update.joomlart.com/service/tracking/j31/uber_bookstore.xml','',''),(319,4,0,'Sample package for Uber Business','','uber_business','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_business.xml','',''),(320,4,0,'Sample package for Uber Charity','','uber_charity','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_charity.xml','',''),(321,4,0,'Sample package for Uber Church','','uber_church','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_church.xml','',''),(322,4,0,'Sample package for Uber Construction','','uber_construction','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_construction.xml','',''),(323,4,0,'Sample package for Uber Corporate','','uber_corporate','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_corporate.xml','',''),(324,4,0,'Sample package for Uber Gym','','uber_gym','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_gym.xml','',''),(325,4,0,'Sample package for Uber Home','','uber_home','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_home.xml','',''),(326,4,0,'Sample package for Landing page','','uber_landing','sample_package','',0,'2.1.0','','http://update.joomlart.com/service/tracking/j31/uber_landing.xml','',''),(327,4,0,'Sample package for Uber Lawyer','','uber_lawyer','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_lawyer.xml','',''),(328,4,0,'Sample package for Uber Medicare','','uber_medicare','sample_package','',0,'2.1.0','','http://update.joomlart.com/service/tracking/j31/uber_medicare.xml','',''),(329,4,0,'Sample package for Uber Music','','uber_music','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_music.xml','',''),(330,4,0,'Sample package for Uber Restaurant','','uber_restaurant','sample_package','',0,'2.0.3','','http://update.joomlart.com/service/tracking/j31/uber_restaurant.xml','',''),(331,4,0,'Sample package for Uber Spa','','uber_spa','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_spa.xml','',''),(332,4,0,'Sample package for Uber University','','uber_university','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_university.xml','',''),(333,4,0,'Sample package for Uber Wedding','','uber_wedding','sample_package','',0,'2.0.2','','http://update.joomlart.com/service/tracking/j31/uber_wedding.xml','',''),(334,6,0,'Armenian','','pkg_hy-AM','package','',0,'3.4.4.1','','https://update.joomla.org/language/details3/hy-AM_details.xml','',''),(335,6,0,'Malay','','pkg_ms-MY','package','',0,'3.4.1.2','','https://update.joomla.org/language/details3/ms-MY_details.xml','',''),(336,6,0,'Romanian','','pkg_ro-RO','package','',0,'3.6.0.1','','https://update.joomla.org/language/details3/ro-RO_details.xml','',''),(337,6,0,'Flemish','','pkg_nl-BE','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/nl-BE_details.xml','',''),(338,6,0,'Chinese Traditional','','pkg_zh-TW','package','',0,'3.6.3.1','','https://update.joomla.org/language/details3/zh-TW_details.xml','',''),(339,6,0,'French','','pkg_fr-FR','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/fr-FR_details.xml','',''),(340,6,0,'Galician','','pkg_gl-ES','package','',0,'3.3.1.2','','https://update.joomla.org/language/details3/gl-ES_details.xml','',''),(341,6,0,'Georgian','','pkg_ka-GE','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/ka-GE_details.xml','',''),(342,6,0,'Greek','','pkg_el-GR','package','',0,'3.6.3.2','','https://update.joomla.org/language/details3/el-GR_details.xml','',''),(343,6,0,'Japanese','','pkg_ja-JP','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/ja-JP_details.xml','',''),(344,6,0,'Hebrew','','pkg_he-IL','package','',0,'3.1.1.1','','https://update.joomla.org/language/details3/he-IL_details.xml','',''),(345,6,0,'Hungarian','','pkg_hu-HU','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/hu-HU_details.xml','',''),(346,6,0,'Afrikaans','','pkg_af-ZA','package','',0,'3.6.3.1','','https://update.joomla.org/language/details3/af-ZA_details.xml','',''),(347,6,0,'Arabic Unitag','','pkg_ar-AA','package','',0,'3.6.5.2','','https://update.joomla.org/language/details3/ar-AA_details.xml','',''),(348,6,0,'Belarusian','','pkg_be-BY','package','',0,'3.2.1.1','','https://update.joomla.org/language/details3/be-BY_details.xml','',''),(349,6,0,'Bulgarian','','pkg_bg-BG','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/bg-BG_details.xml','',''),(350,6,0,'Catalan','','pkg_ca-ES','package','',0,'3.6.5.2','','https://update.joomla.org/language/details3/ca-ES_details.xml','',''),(351,6,0,'Croatian','','pkg_hr-HR','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/hr-HR_details.xml','',''),(352,6,0,'Czech','','pkg_cs-CZ','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/cs-CZ_details.xml','',''),(353,6,0,'Danish','','pkg_da-DK','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/da-DK_details.xml','',''),(354,6,0,'Dutch','','pkg_nl-NL','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/nl-NL_details.xml','',''),(355,6,0,'Estonian','','pkg_et-EE','package','',0,'3.6.0.1','','https://update.joomla.org/language/details3/et-EE_details.xml','',''),(356,6,0,'Italian','','pkg_it-IT','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/it-IT_details.xml','',''),(357,6,0,'Khmer','','pkg_km-KH','package','',0,'3.4.5.1','','https://update.joomla.org/language/details3/km-KH_details.xml','',''),(358,6,0,'Korean','','pkg_ko-KR','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/ko-KR_details.xml','',''),(359,6,0,'Latvian','','pkg_lv-LV','package','',0,'3.6.2.2','','https://update.joomla.org/language/details3/lv-LV_details.xml','',''),(360,6,0,'Macedonian','','pkg_mk-MK','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/mk-MK_details.xml','',''),(361,6,0,'Norwegian Bokmal','','pkg_nb-NO','package','',0,'3.5.1.1','','https://update.joomla.org/language/details3/nb-NO_details.xml','',''),(362,6,0,'Norwegian Nynorsk','','pkg_nn-NO','package','',0,'3.4.2.1','','https://update.joomla.org/language/details3/nn-NO_details.xml','',''),(363,6,0,'Persian','','pkg_fa-IR','package','',0,'3.6.5.3','','https://update.joomla.org/language/details3/fa-IR_details.xml','',''),(364,6,0,'Polish','','pkg_pl-PL','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/pl-PL_details.xml','',''),(365,6,0,'Portuguese','','pkg_pt-PT','package','',0,'3.6.4.3','','https://update.joomla.org/language/details3/pt-PT_details.xml','',''),(366,6,0,'Russian','','pkg_ru-RU','package','',0,'3.6.2.2','','https://update.joomla.org/language/details3/ru-RU_details.xml','',''),(367,6,0,'English AU','','pkg_en-AU','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/en-AU_details.xml','',''),(368,6,0,'Slovak','','pkg_sk-SK','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/sk-SK_details.xml','',''),(369,6,0,'English US','','pkg_en-US','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/en-US_details.xml','',''),(370,6,0,'Swedish','','pkg_sv-SE','package','',0,'3.6.3.1','','https://update.joomla.org/language/details3/sv-SE_details.xml','',''),(371,6,0,'Syriac','','pkg_sy-IQ','package','',0,'3.4.5.1','','https://update.joomla.org/language/details3/sy-IQ_details.xml','',''),(372,6,0,'Tamil','','pkg_ta-IN','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/ta-IN_details.xml','',''),(373,6,0,'Thai','','pkg_th-TH','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/th-TH_details.xml','',''),(374,6,0,'Turkish','','pkg_tr-TR','package','',0,'3.6.2.1','','https://update.joomla.org/language/details3/tr-TR_details.xml','',''),(375,6,0,'Ukrainian','','pkg_uk-UA','package','',0,'3.6.3.1','','https://update.joomla.org/language/details3/uk-UA_details.xml','',''),(376,6,0,'Uyghur','','pkg_ug-CN','package','',0,'3.3.0.1','','https://update.joomla.org/language/details3/ug-CN_details.xml','',''),(377,6,0,'Albanian','','pkg_sq-AL','package','',0,'3.1.1.1','','https://update.joomla.org/language/details3/sq-AL_details.xml','',''),(378,6,0,'Basque','','pkg_eu-ES','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/eu-ES_details.xml','',''),(379,6,0,'Hindi','','pkg_hi-IN','package','',0,'3.3.6.2','','https://update.joomla.org/language/details3/hi-IN_details.xml','',''),(380,6,0,'German DE','','pkg_de-DE','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/de-DE_details.xml','',''),(381,6,0,'Portuguese Brazil','','pkg_pt-BR','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/pt-BR_details.xml','',''),(382,6,0,'Serbian Latin','','pkg_sr-YU','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/sr-YU_details.xml','',''),(383,6,0,'Spanish','','pkg_es-ES','package','',0,'3.6.3.1','','https://update.joomla.org/language/details3/es-ES_details.xml','',''),(384,6,0,'Bosnian','','pkg_bs-BA','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/bs-BA_details.xml','',''),(385,6,0,'Serbian Cyrillic','','pkg_sr-RS','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/sr-RS_details.xml','',''),(386,6,0,'Vietnamese','','pkg_vi-VN','package','',0,'3.2.1.1','','https://update.joomla.org/language/details3/vi-VN_details.xml','',''),(387,6,0,'Bahasa Indonesia','','pkg_id-ID','package','',0,'3.6.2.1','','https://update.joomla.org/language/details3/id-ID_details.xml','',''),(388,6,0,'Finnish','','pkg_fi-FI','package','',0,'3.6.2.1','','https://update.joomla.org/language/details3/fi-FI_details.xml','',''),(389,6,0,'Swahili','','pkg_sw-KE','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/sw-KE_details.xml','',''),(390,6,0,'Montenegrin','','pkg_srp-ME','package','',0,'3.3.1.1','','https://update.joomla.org/language/details3/srp-ME_details.xml','',''),(391,6,0,'English CA','','pkg_en-CA','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/en-CA_details.xml','',''),(392,6,0,'French CA','','pkg_fr-CA','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/fr-CA_details.xml','',''),(393,6,0,'Welsh','','pkg_cy-GB','package','',0,'3.3.0.2','','https://update.joomla.org/language/details3/cy-GB_details.xml','',''),(394,6,0,'Sinhala','','pkg_si-LK','package','',0,'3.3.1.1','','https://update.joomla.org/language/details3/si-LK_details.xml','',''),(395,6,0,'Dari Persian','','pkg_prs-AF','package','',0,'3.4.4.2','','https://update.joomla.org/language/details3/prs-AF_details.xml','',''),(396,6,0,'Turkmen','','pkg_tk-TM','package','',0,'3.5.0.2','','https://update.joomla.org/language/details3/tk-TM_details.xml','',''),(397,6,0,'Irish','','pkg_ga-IE','package','',0,'3.6.4.1','','https://update.joomla.org/language/details3/ga-IE_details.xml','',''),(398,6,0,'Dzongkha','','pkg_dz-BT','package','',0,'3.6.2.1','','https://update.joomla.org/language/details3/dz-BT_details.xml','',''),(399,6,0,'Slovenian','','pkg_sl-SI','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/sl-SI_details.xml','',''),(400,6,0,'Spanish CO','','pkg_es-CO','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/es-CO_details.xml','',''),(401,6,0,'German CH','','pkg_de-CH','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/de-CH_details.xml','',''),(402,6,0,'German AT','','pkg_de-AT','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/de-AT_details.xml','',''),(403,6,0,'German LI','','pkg_de-LI','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/de-LI_details.xml','',''),(404,6,0,'German LU','','pkg_de-LU','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/de-LU_details.xml','',''),(405,6,0,'English NZ','','pkg_en-NZ','package','',0,'3.6.5.1','','https://update.joomla.org/language/details3/en-NZ_details.xml','',''),(406,7,0,'Kunena Language Pack','Language Pack for Kunena Forum','pkg_kunena_languages','package','',0,'5.0.7','','https://update.kunena.org/5.0/pkg_kunena_languages.xml','',''),(407,7,0,'Kunena Latest Module','','mod_kunenalatest','module','',0,'5.0.2','','https://update.kunena.org/5.0/mod_kunenalatest.xml','',''),(408,7,0,'Kunena Login Module','','mod_kunenalogin','module','',0,'5.0.2','','https://update.kunena.org/5.0/mod_kunenalogin.xml','',''),(409,7,0,'Kunena Search Module','','mod_kunenasearch','module','',0,'5.0.2','','https://update.kunena.org/5.0/mod_kunenasearch.xml','',''),(410,7,0,'Kunena Statistics Module','','mod_kunenastats','module','',0,'5.0.2','','https://update.kunena.org/5.0/mod_kunenastats.xml','',''),(411,7,0,'Content - Kunena Discuss','','kunenadiscuss','plugin','content',0,'5.0.2','','https://update.kunena.org/5.0/plg_content_kunenadiscuss.xml','',''),(412,7,0,'Search - Kunena','','kunena','plugin','search',0,'5.0.2','','https://update.kunena.org/5.0/plg_search_kunena.xml','','');
/*!40000 ALTER TABLE `pro_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_user_keys`
--

DROP TABLE IF EXISTS `pro_user_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_user_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `series` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uastring` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `series` (`series`),
  UNIQUE KEY `series_2` (`series`),
  UNIQUE KEY `series_3` (`series`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_user_keys`
--

LOCK TABLES `pro_user_keys` WRITE;
/*!40000 ALTER TABLE `pro_user_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_user_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_user_notes`
--

DROP TABLE IF EXISTS `pro_user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_user_notes`
--

LOCK TABLES `pro_user_notes` WRITE;
/*!40000 ALTER TABLE `pro_user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_user_profiles`
--

DROP TABLE IF EXISTS `pro_user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Simple user profile storage table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_user_profiles`
--

LOCK TABLES `pro_user_profiles` WRITE;
/*!40000 ALTER TABLE `pro_user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `pro_user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_user_usergroup_map`
--

DROP TABLE IF EXISTS `pro_user_usergroup_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_user_usergroup_map`
--

LOCK TABLES `pro_user_usergroup_map` WRITE;
/*!40000 ALTER TABLE `pro_user_usergroup_map` DISABLE KEYS */;
INSERT INTO `pro_user_usergroup_map` VALUES (42,8);
/*!40000 ALTER TABLE `pro_user_usergroup_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_usergroups`
--

DROP TABLE IF EXISTS `pro_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_usergroups`
--

LOCK TABLES `pro_usergroups` WRITE;
/*!40000 ALTER TABLE `pro_usergroups` DISABLE KEYS */;
INSERT INTO `pro_usergroups` VALUES (1,0,1,22,'Public'),(2,1,8,19,'Registered'),(3,2,9,16,'Author'),(4,3,10,13,'Editor'),(5,4,11,12,'Publisher'),(6,1,4,7,'Manager'),(7,6,5,6,'Administrator'),(8,1,20,21,'Super Users'),(10,3,14,15,'Shop Suppliers (Example)'),(12,2,17,18,'Customer Group (Example)'),(13,1,2,3,'Guest');
/*!40000 ALTER TABLE `pro_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_users`
--

DROP TABLE IF EXISTS `pro_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  `requireReset` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Require user to reset password on next login',
  PRIMARY KEY (`id`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `idx_name` (`name`(100))
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_users`
--

LOCK TABLES `pro_users` WRITE;
/*!40000 ALTER TABLE `pro_users` DISABLE KEYS */;
INSERT INTO `pro_users` VALUES (42,'Super User','mawenqiang','mawenqiang1985@sina.com','$2y$10$RlKVhkDuFbeEfQ3mDjQcveBe6SH.tbVoO.8GF6diEz8p5Mm4Y0t2.',0,1,'2017-02-15 09:55:17','2017-04-02 04:24:34','0','','0000-00-00 00:00:00',0,'','',0);
/*!40000 ALTER TABLE `pro_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_utf8_conversion`
--

DROP TABLE IF EXISTS `pro_utf8_conversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_utf8_conversion` (
  `converted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_utf8_conversion`
--

LOCK TABLES `pro_utf8_conversion` WRITE;
/*!40000 ALTER TABLE `pro_utf8_conversion` DISABLE KEYS */;
INSERT INTO `pro_utf8_conversion` VALUES (2);
/*!40000 ALTER TABLE `pro_utf8_conversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_viewlevels`
--

DROP TABLE IF EXISTS `pro_viewlevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_viewlevels`
--

LOCK TABLES `pro_viewlevels` WRITE;
/*!40000 ALTER TABLE `pro_viewlevels` DISABLE KEYS */;
INSERT INTO `pro_viewlevels` VALUES (1,'Public',0,'[1]'),(2,'Registered',1,'[6,2,8]'),(3,'Special',2,'[6,3,8]'),(4,'Customer Access Level (Example)',3,'[6,3,12]'),(5,'Guest',0,'[13]');
/*!40000 ALTER TABLE `pro_viewlevels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro_wf_profiles`
--

DROP TABLE IF EXISTS `pro_wf_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro_wf_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `users` text NOT NULL,
  `types` text NOT NULL,
  `components` text NOT NULL,
  `area` tinyint(3) NOT NULL,
  `device` varchar(255) NOT NULL,
  `rows` text NOT NULL,
  `plugins` text NOT NULL,
  `published` tinyint(3) NOT NULL,
  `ordering` int(11) NOT NULL,
  `checked_out` tinyint(3) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro_wf_profiles`
--

LOCK TABLES `pro_wf_profiles` WRITE;
/*!40000 ALTER TABLE `pro_wf_profiles` DISABLE KEYS */;
INSERT INTO `pro_wf_profiles` VALUES (1,'Default','Default Profile for all users','','3,4,10,5,6,8,7','',0,'desktop,tablet,phone','help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,blockquote,formatselect,styleselect,removeformat,cleanup;fontselect,fontsizeselect,fontcolor,spacer,clipboard,indent,outdent,lists,sub,sup,textcase,charmap,hr;directionality,fullscreen,print,searchreplace,spacer,table,style,xhtmlxtras;visualaid,visualchars,visualblocks,nonbreaking,anchor,unlink,link,imgmanager,spellchecker,article','formatselect,styleselect,cleanup,fontselect,fontsizeselect,fontcolor,clipboard,lists,textcase,charmap,hr,directionality,fullscreen,print,searchreplace,table,style,xhtmlxtras,visualchars,visualblocks,nonbreaking,anchor,link,imgmanager,spellchecker,article,spellchecker,article,browser,contextmenu,inlinepopups,media,preview,source',1,1,0,'0000-00-00 00:00:00',''),(2,'Front End','Sample Front-end Profile','','3,4,10,5','',1,'desktop,tablet,phone','help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,formatselect,styleselect;clipboard,searchreplace,indent,outdent,lists,cleanup,charmap,removeformat,hr,sub,sup,textcase,nonbreaking,visualchars,visualblocks;fullscreen,print,visualaid,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article','charmap,contextmenu,inlinepopups,help,clipboard,searchreplace,fullscreen,preview,print,style,textcase,nonbreaking,visualchars,visualblocks,xhtmlxtras,imgmanager,anchor,link,spellchecker,article,lists,formatselect,styleselect,hr',0,2,0,'0000-00-00 00:00:00',''),(3,'Blogger','Simple Blogging Profile','','3,4,10,5,6,8,7','',0,'desktop,tablet,phone','bold,italic,strikethrough,lists,blockquote,spacer,justifyleft,justifycenter,justifyright,spacer,link,unlink,imgmanager,article,spellchecker,fullscreen,kitchensink;formatselect,styleselect,underline,justifyfull,clipboard,removeformat,charmap,indent,outdent,undo,redo,help','link,imgmanager,article,spellchecker,fullscreen,kitchensink,clipboard,contextmenu,inlinepopups,lists,formatselect,styleselect,textpattern',0,3,0,'0000-00-00 00:00:00','{\"editor\":{\"toggle\":\"0\"}}'),(4,'Mobile','Sample Mobile Profile','','3,4,10,5,6,8,7','',0,'tablet,phone','undo,redo,spacer,bold,italic,underline,formatselect,spacer,justifyleft,justifycenter,justifyfull,justifyright,spacer,fullscreen,kitchensink;styleselect,lists,spellchecker,article,link,unlink','fullscreen,kitchensink,spellchecker,article,link,inlinepopups,lists,formatselect,styleselect,textpattern',0,4,0,'0000-00-00 00:00:00','{\"editor\":{\"toolbar_theme\":\"mobile\",\"resizing\":\"0\",\"resize_horizontal\":\"0\",\"resizing_use_cookie\":\"0\",\"toggle\":\"0\",\"links\":{\"popups\":{\"default\":\"\",\"jcemediabox\":{\"enable\":\"0\"},\"window\":{\"enable\":\"0\"}}}}}'),(5,'Markdown','Sample Markdown Profile','','6,7,3,4,5,8','',0,'desktop,tablet,phone','fullscreen,justifyleft,justifycenter,justifyfull,justifyright,link,unlink,imgmanager,styleselect','fullscreen,link,imgmanager,styleselect,inlinepopups,media,textpattern',0,5,0,'0000-00-00 00:00:00','{\"editor\":{\"toolbar_theme\":\"mobile\"}}');
/*!40000 ALTER TABLE `pro_wf_profiles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-02 12:37:03
